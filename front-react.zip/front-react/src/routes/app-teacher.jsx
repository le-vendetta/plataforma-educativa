import {
    Dashboard as DashboardPage,
    GradeGroupManager,
    Programs,
    Program,
    AppliedPrograms,
    Course,
    Session,
    Settings as _Settings,
} from "../front/views/Teacher";
import {
    Dashboard,
    Settings,
    School, FolderSpecial
} from "@material-ui/icons";

const appRoutesTeacher = (names) => [
    {
        path: "/home",
        sidebarName: "Inicio",
        navbarName: "Bienvenido",
        icon: "/assets/images/icons/teacher-home.png",
        component: DashboardPage
    },
    {
        path: "/gestion-groups",
        sidebarName: 'Gestion de grupos',
        navbarName: 'Gestion de grupos',
        icon: "/assets/images/icons/teacher-groups.png",
        component: GradeGroupManager
    },
    {
        path: "/programas",
        sidebarName: 'Programas',
        navbarName: 'Programas',
        icon: "/assets/images/icons/teacher-courses.png",
        component: Programs
    },
    {
        path: "/programa/:slug",
        navbarName: 'Programa',
        visible:false,
        component: Program
    },
    {
        path: "/programas-aplicados",
        component: AppliedPrograms,
        navbarName: "Programas aplicados",
        visible: false,
    },
    {
        path: "/curso/:slug",
        navbarName: '',
        visible: false,
        component:Course
    },
    {
        path: "/clase/:session",
        navbarName: 'Session activa',
        visible: false,
        component:Session
    },
    // {
    //     path: "/ajustes",
    //     sidebarName: names.settings,
    //     navbarName: names.settings,
    //     icon: Settings,
    //     component: _Settings
    // },

    {redirect: true, path: "/*", to: "/", navbarName: "Redirect"}
];

export default appRoutesTeacher;
