import {
    Courses,
    Dashboard as DashboardPage,
    GradeGroupManager ,
}from "../front/views/Admin";

const appRoutesAdmin = (names) => [
    {
        path: "/home",
        sidebarName: "Home",
        navbarName: "Dashboard",
        icon: "assets/images/icons/teacher-home.png",
        component: DashboardPage
    },
    {
        path: "/cursos",
        sidebarName: names.courses,
        navbarName: names.courses,
        icon: "assets/images/icons/teacher-courses.png",
        component: Courses
    },
    {
        path: "/gestion-grados-y-grupos",
        sidebarName: "Grados y grupos",
        navbarName: "Gestion de grados y grupos",
        icon: "../assets/images/icons/teacher-groups.png",
        component: GradeGroupManager
    },

    {redirect: true, path: "/*", to: "/", navbarName: "Redirect"}
];

export default appRoutesAdmin;
