import App from "../front/layouts/App/App.jsx";

const indexRoutes = [{path: "/", component: App}];

export default indexRoutes;
