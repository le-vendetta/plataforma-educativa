import {
    Dashboard,
    Courses,
    Achievements,
    Settings as _Settings,
    Lesson,
    Course,
} from "../front/views/Student";

import {
    Dashboard as dd,
    Settings,
    School, FolderSpecial
} from "@material-ui/icons";

const appRoutesStudent = (names) => [
    {
        path: "/home",
        sidebarName: "Usuario",
        navbarName: "Dashboard",
        icon: "/assets/images/icons/teacher-home.png",
        component: Dashboard
    },
    {
        path: "/cursos",
        sidebarName: "Avance",
        navbarName: "Avance",
        icon: "/assets/images/icons/student-achievements.png",
        component: Courses
    },
    {
        path: "/curso/:course/leccion/:lesson",
        visible: false,
        component:Lesson
    },
    {
        path: "/curso/:slug",
        visible: false,
        component:Course
    },

    {
        path: "/logros",
        sidebarName: names.achievements,
        navbarName: names.achievements,
        icon: "/assets/images/icons/student-advance.png",
        component: Achievements
    },
    {
        path: "/ajustes",
        sidebarName: names.settings,
        navbarName: names.settings,
        icon: Settings,
        component: _Settings,
        visible: false,
    },

    {redirect: true, path: "/*", to: "/", navbarName: "Redirect"}
];

export default appRoutesStudent;
