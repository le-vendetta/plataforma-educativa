import React from "react";
import PropTypes from "prop-types";
import {Menu} from "@material-ui/icons";
import {
    withStyles,
    AppBar,
    Toolbar,
    IconButton,
    Hidden,
    Button
} from "material-ui";

import headerStyle from "../../../variables/styles/headerStyle.jsx";

import HeaderLinks from "./HeaderLinks";
import {Link} from "react-router-dom";



function HeaderMenu({...props}) {

    const {classes} = props;

    return (
        <AppBar className={[classes.appBar,classes.appBarKids].join(' ')}>
            <Toolbar>
                <div>{/* student menu */}
                    <Button className={classes.title} component={Link} to={process.env.PUBLIC_URL + '/'}>
                         <img src={process.env.PUBLIC_URL + "/assets/images/header-logo.png"} alt="" className={classes.titleimg}/>
                    </Button>
                </div>
                <Hidden smDown implementation="css" >
                    <HeaderLinks/>
                </Hidden>
                <Hidden mdUp>
                    <IconButton
                        className={classes.appResponsive}
                        color="inherit"
                        aria-label="open drawer"
                        onClick={props.handleDrawerToggle}
                    ><Menu/></IconButton>
                </Hidden>
            </Toolbar>
        </AppBar>
    );
}

HeaderMenu.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(headerStyle)(HeaderMenu);
