import React from "react";
import headerLinksStyle from "../../../variables/styles/headerLinksStyle";
import {
    withStyles,
    Button,
} from "material-ui";
import {Link, withRouter} from "react-router-dom";
import {translate} from "react-i18next";

class HeaderMenu extends React.Component {
    render() {
        const {classes, t} = this.props;

        return (
          <div  style={{ float       : 'left',
              marginLeft  : 'auto',
              marginRight : 'auto',
              display: "inline-block", flex:1,}}>
              <Button color="transparent" className={classes.buttonLink} component={Link} to={process.env.PUBLIC_URL + '/home'}>USUARIO</Button>
              <Button color="transparent" className={classes.buttonLink} component={Link} to={process.env.PUBLIC_URL + '/logros'}>Logros</Button>
              <Button color="transparent" className={classes.buttonLink} component={Link} to={process.env.PUBLIC_URL + '/cursos'}>Avance</Button>
          </div>
        );
    }

}
export default withStyles(headerLinksStyle)(withRouter(translate("translations")(HeaderMenu)));
