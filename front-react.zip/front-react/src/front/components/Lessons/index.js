import React, {Component} from 'react';
import {
    Icon, Tooltip,
    Typography, withStyles
} from "material-ui";

import Loading from "../Loading/index";
import {Link} from "react-router-dom";
import {connect} from "react-redux";
import {getLessons} from "../../../app/rdx/actions/coursesActions";
import courseStyle from "../../../variables/styles/courses";

class Lessons extends Component {
    constructor() {
        super();
        this.getLessons = this.getLessons.bind(this);
        this.state = {lessons: false};
    }

    componentDidMount() {
        this.props.getLessons(this.props.course.id);
        this.getLessons();
    }

    componentWillReceiveProps(props) {
        if (this.state.lessons.length <= 0 || this.props.course.id !== props.course.id) {
            this.getLessons(props.lessons);
        }
    }

    getLessons(lessons) {
        const {classes} = this.props;
        let less = [];
        if (lessons) {
            lessons.forEach((lesson, idx) => {
                less.push(
                  <li key={idx}>
                  <div className="lesson-player left">
                    <Tooltip title={lesson.viewed ? 'Ya viste esta leccion' : 'No se ha completado la lección'} placement="top" classes={{tooltip: classes.tooltip}}>
                      <Icon className={lesson.viewed ? 'done-icon-lesson icon-lesson available' : 'to-do-icon-lesson icon-lesson disabled'}>done</Icon>
                    </Tooltip>
                    <Typography className="flex-item">LECCIÓN {idx+1}: {lesson.name}</Typography>
                    </div>
                    <div className="lesson-player right">
                      <Link className="lesson-player"  to={process.env.PUBLIC_URL + '/curso/' + this.props.course.slug + '/leccion/' + lesson.slug}>
                        <Icon className={ lesson.viewed ? 'to-play-lesson available': 'to-replay-lesson disabled'}>{ lesson.viewed ? 'replay': 'play_arrow'}</Icon>
                        <Typography className={ lesson.viewed ? 'available': 'disabled'}>{ lesson.viewed ? 'Reiniciar': 'Iniciar'}</Typography>
                      </Link>
                    </div>
                  </li>
                );

            });
        }

        this.setState({lessons: less});
    }

    render() {
        return <div><ul className="list-lessons">{!this.props.lessons ? <Loading/> : this.state.lessons}</ul></div>;
    }
}

const stateToProps = ({lessons}) => ({lessons});
const dispatchToProps = (dispatch) => ({
    getLessons: (course) => dispatch(getLessons(course)),
});

const conn = connect(stateToProps, dispatchToProps);


export default withStyles(courseStyle)(conn(Lessons));
