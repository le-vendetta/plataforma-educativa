import React from 'react';
import {
    Dialog,
    DialogContent,
    withStyles, DialogTitle, DialogActions, Button, TextField, MenuItem
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';

import {connect} from "react-redux";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import Toast from "../../../../app/core/helpers/Toast";
import {setUsers} from "../../../../app/rdx/actions/usersActions";
import {store} from "../../../../app/rdx/store";

class AddStudents extends React.Component {
    constructor(){
        super();
        this.state = {
            grade_group:-1
        };
    }

    handleClose(){
        this.setState({grade_group:-1});
        this.props.onClose();
    };

    render() {
        const {open,classes,gradeGroups} = this.props;
        const {grade_group} = this.state;
        return (
            <div>
                <Dialog
                    open={open}
                    fullWidth
                    maxWidth={'sm'}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogTitle id="form-dialog-title">Agregar alumnos</DialogTitle>
                    <DialogContent className={classes.paddingTop}>
                        <TextField select fullWidth label="Grado y grupo" value={grade_group} className={classes.input}  onChange={(e)=>this.setGradeGroup(e)}>
                            <MenuItem key={null} value={-1}>Elige una opcion</MenuItem>
                            {gradeGroups.map(option => (
                                <MenuItem key={option.id} value={option.id}>
                                    {option.grade_name}
                                    {option.group_name}
                                </MenuItem>
                            ))}
                        </TextField>

                        {grade_group !== -1 &&<div className={[classes.draggableBig,classes.center].join(' ')} onDrop={(e)=>this.onDrop(e)} onDragOver={(e) =>this.dragOver(e)}>
                            <strong className={classes.draggableTextBig}>Arrastra aqui tus archivos xls,csv,xlsx</strong>
                        </div>}

                        <Button fullWidth href={window.storage+'formats/Formato.xlsx'}>Bajar plantilla</Button>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => this.handleClose()} color="primary">
                            Cerrar
                        </Button>

                    </DialogActions>
                </Dialog>
            </div>
        );
    }

    setGradeGroup(e){
        console.log(e,e.target,e.target.value)
        this.setState({grade_group:e.target.value});
    }

    dragOver(e){
        e.preventDefault();
        e.stopPropagation();
    }

    onDrop(ev){
        ev.preventDefault();

        let file    = ev.dataTransfer.files[0];

        if(file ){
            let ext     = file && file.name.split('.');
            let permit  = ['xls','xlsx','csv'];
            ext = ext[ext.length-1];

            if(permit.indexOf(ext)>-1){
                let api     = new ApiHelper();
                let token   = localStorage.getItem('token');

                api.post('users/students/excel',{file,grade_group:this.state.grade_group},token).then(({data}) => {
                    let users = store.getState().users;

                    data.users.forEach((val) => {
                       let exist = users.findIndex((v) => v.id === val.id);
                       if(exist >-1){
                           users[exist] = val;
                       }else{
                           users.push(val);
                       }
                    });

                    this.props.setUsers(JSON.parse(JSON.stringify(users)));

                    Toast('Alumnos subidos correctamente');

                    this.handleClose();
                });
            }else{
                Toast('La extension del archivo no es valida (XLS,CSV,XLSX)','error');
            }
        }else{
            Toast('Algo salio mal, vuelve a intentarlo','error');
        }
    }
}

const stateToProps = ({users}) => ({users});
const dispatchToProps = (dispatch) => ({//custom props
    setUsers: (data) => dispatch(setUsers(data)),
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(AddStudents));