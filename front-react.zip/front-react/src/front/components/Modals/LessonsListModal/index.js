import React from 'react';
import {
    Button,
    Dialog, DialogActions,
    DialogContent,
    DialogTitle,
    withStyles,
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';
import {connect} from "react-redux";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import {withRouter} from "react-router-dom";
import Lessons from "../../Sessions/Lessons";

class LessonListModal extends React.Component {
    constructor(){
        super();
        this.state = {lessons:[]}
        this.api = new ApiHelper();
        this.token = localStorage.getItem('token');
    }

    componentDidMount(){
        this.getLessons(this.props.session.id);
    }

    componentWillReceiveProps(props){
        if(this.props.session.lesson_id !== props.session.lesson_id){
            let s_lessons   = this.state.lessons;
            let lessons     = [];

            s_lessons.forEach(lesson=>{
                lesson.current = lesson.id === props.session.lesson_id;
               lessons.push(lesson);
            });

            this.setState({lessons});
        }
    }

    handleClose(){
        this.props.onClose();
    };

    render() {
        const {lessons}         = this.state;
        const {session,open}    = this.props;

        return (
            <div>
                <Dialog
                    maxWidth={'md'}
                    fullWidth
                    open={open}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogTitle id="form-dialog-title">¿Cual sera la siguiente leccion?</DialogTitle>
                    <DialogContent>
                        <Lessons lessons={lessons} session={session} onReload={(lesson) => this.props.onReload(lesson)}/>
                    </DialogContent>
                    <DialogActions>

                        <Button onClick={() => this.endClass(session.id)} color="primary">
                            Terminar esta clase
                        </Button>
                    </DialogActions>
                </Dialog>

            </div>
        );
    }

    getLessons(session){
        this.api.get('session/'+session+'/lessons', this.token).then(({data}) => {
            let {lessons} = data;
            this.setState({lessons})
        });
    }

    endClass(session){
        let question = window.confirm("¿Estas seguro de terminar esta clase?");
        if(question){
            this.api.put('session/'+session,{},this.token).then(({data}) => {
                this.props.history.push(process.env.PUBLIC_URL + '/home');
            });
        }
    }
}

const stateToProps = null;
const dispatchToProps = null;

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(withRouter(LessonListModal)));