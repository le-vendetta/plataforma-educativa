import React from 'react';
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    withStyles, TableCell, Tooltip, IconButton
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';
import {getLessons,removeLessons} from "../../../../app/rdx/actions/coursesActions";

import {connect} from "react-redux";
import Edit from '@material-ui/icons/Edit';
import SortTable from '../../Tables/SortTable/index';
import Loading from "../../Loading/index";

const columnData = [
    { id: 'id', numeric: true, disablePadding: true, label: '#' },
    { id: 'name', numeric: false, disablePadding: false, label: 'Nombre' },
    { id: 'type_slug', numeric: false, disablePadding: false, label: 'Tipo' },
    { id: 'actions', numeric: false, disablePadding: false, label: 'Acciones',sortable:false },
];
class LessonsModal extends React.Component {
    constructor(){
        super();
        this.state = {
            course:{},lessons:[],
        };
    }


    handleClose(){
        this.props.onClose();
    };

    componentWillReceiveProps(props){
        if(props.course && Object.keys(props.course).length > 0 && props.course.id !== this.props.course.id){
            this.setState({course:props.course});
            this.props.getLessons(props.course.id);
        }

        if(JSON.stringify(props.lessons) !== JSON.stringify(this.state.lessons)){
            this.setState({lessons:props.lessons});
        }
    }

    render() {
        const {open} = this.props;

        const {lessons,course} = this.state;

        return (
            <div>
                <Dialog
                    maxWidth={'md'}
                    open={open}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogTitle id="form-dialog-title">Lecciones del curso #{course.id}</DialogTitle>
                    <DialogContent>
                        {lessons ? <SortTable enableCheck={true} rowsPerPage={5}
                                              headerStructure={columnData}
                                              items={lessons}
                                              id={'id'}
                                              onDelete={(ids) => this.removeItems(ids)}
                                   rowStructure={(lesson) => {
                                       return <React.Fragment>
                                           <TableCell component="td" scope="row" padding="none" numeric>
                                               {lesson.id}
                                           </TableCell>
                                           <TableCell>{lesson.name}</TableCell>
                                           <TableCell>{lesson.type_name}</TableCell>
                                           <TableCell>
                                               <Tooltip title="Editar" placement="top">
                                                   <IconButton aria-label="Editar" color={'primary'} onClick={(event)=>this.openEditLesson(event,lesson.id)}>
                                                       <Edit />
                                                   </IconButton>
                                               </Tooltip>

                                           </TableCell>

                                       </React.Fragment>
                                   }}
                        />:<Loading/> }
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => this.handleClose()} color="primary">
                            Cerrar
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }

    openEditLesson(e,lesson){
        e.preventDefault();
        e.stopPropagation();
        this.props.onEditLesson(lesson);
    }

    removeItems(items){
        let cc = window.confirm('De verdad quieres eliminar estos cursos?');
        if(cc){
            this.props.removeLessons(items);
        }
    }

}

const stateToProps = ({lessons}) => ({lessons});
const dispatchToProps = (dispatch) => ({//custom props
    getLessons: (course) => dispatch(getLessons(course)),
    removeLessons: (lessons) => dispatch(removeLessons(lessons)),

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(LessonsModal));