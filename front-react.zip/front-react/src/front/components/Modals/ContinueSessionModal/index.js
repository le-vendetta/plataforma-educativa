import React from 'react';
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    withStyles, Tooltip, List, ListItem, ListItemText, ListItemSecondaryAction
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';

import {connect} from "react-redux";
import ArrowForward from '@material-ui/icons/ArrowForward';
import PauseCircleOutline from '@material-ui/icons/PauseCircleOutline';
import Replay from '@material-ui/icons/Replay';
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import PlayArrow from '@material-ui/icons/PlayArrow';
import {withRouter} from "react-router-dom";

class ContinueSessionModal extends React.Component {
    constructor(){
        super();
        this.state = {
            sessions:[],
        };

        this.api = new ApiHelper();
        this.token = localStorage.getItem('token');
    }


    handleClose(){
        this.props.onClose();
    };

    componentDidMount(){
        this.getSessions();
    }

    render() {
        const {open} = this.props;
        const {sessions} = this.state;
        const {classes, t} = this.props;
        return (
            <div>
                <Dialog
                    fullWidth
                    maxWidth={'md'}
                    open={open}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title">
                    <DialogTitle className={classes.card} id="form-dialog-title">Mis clases</DialogTitle>
                    <DialogContent className={classes.card}>
                        <List className="listItemClassesTeacher">
                            {sessions.map((session,idx) => {
                                return  <ListItem divider key={idx}>
                                    <ListItemText primary={`#${session.id} ${session.course_info.name}`}
                                                  secondary={`Leccion: ${session.lesson_info.name} ${session.lesson_info.deleted_at ? '(Leccion eliminada)' : ''}`}/>
                                    <ListItemSecondaryAction>
                                        {session.grade_group.grade_name}
                                        {session.grade_group.group_name}

                                        <div>
                                            {session.status && <Button className={classes.iconColor} onClick={()=>this.goToSession(session)}>
                                                <Tooltip title="Ir a la clase" placement="top">
                                                    <PlayArrow/>
                                                </Tooltip>
                                            </Button>}
                                            {session.status&& <Button className={classes.iconColor} onClick={()=>this.stopSession(session)}>
                                                <Tooltip title="Detener la clase" placement="top">
                                                    <PauseCircleOutline/>
                                                </Tooltip>
                                            </Button>}
                                            {!session.status && !session.lesson_info.deleted_at && <Button  className={classes.iconColor} onClick={()=>this.replaySession(session)}>
                                                <Tooltip title="Reactivar la clase"  placement="top">
                                                    <Replay/>
                                                </Tooltip>
                                            </Button>
                                            }
                                        </div>
                                    </ListItemSecondaryAction>
                                </ListItem>
                            })}
                        </List>
                    </DialogContent>
                    <DialogActions className={classes.card +' '+ classes.btnClose}>
                        <Button onClick={() => this.handleClose()} color="primary">
                            Cerrar
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }

    goToSession(session){
        this.props.history.push(process.env.PUBLIC_URL + '/clase/'+session.id);
    }

    stopSession(session){
        this.statusSession(session.id)
    }

    replaySession(session){
        this.statusSession(session.id,true)
    }

    statusSession(session,reload = false){
        let question = window.confirm("¿Estas seguro de "+(reload?'reestablecer':'detener')+" esta clase?");
        if(question){
            let sessions = [];
            let ss       = this.state.sessions;

            this.api.put('session/'+session,{},this.token).then(({data}) => {
                ss.forEach(s =>{
                    s.status = session === s.id?!s.status:s.status;
                    sessions.push(s);
                });

                this.setState({sessions});
            });
        }
    }

    getSessions(){
        this.api.get('sessions/', this.token).then(({data}) => {
            let {sessions} = data;
            this.setState({sessions})
        });
    }

}

const stateToProps = null;
const dispatchToProps = null;

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(withRouter(ContinueSessionModal)));
