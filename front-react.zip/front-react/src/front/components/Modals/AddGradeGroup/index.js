import React from 'react';
import {
    Dialog,
    DialogContent,
    withStyles, DialogTitle, DialogActions, Button, TextField, MenuItem
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';

import {connect} from "react-redux";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import Toast from "../../../../app/core/helpers/Toast";
import {setGradeGroups} from "../../../../app/rdx/actions/gradeGroupsActions";
import AutoComplete from "../../AutoComplete/index";
import {store} from "../../../../app/rdx/store";

class AddGradeGroup extends React.Component {
    constructor(){
        super();
        this.state = {grade_group:{grade_name:'',group_name:'',category_id:-1},form_valid:false};
        this.api    = new ApiHelper();
        this.token  = localStorage.getItem('token');
    }

    componentWillMount(){
        this.getGrades();
        this.getGroups();
    }

    handleClose(){
        this.setState({grade_group:{grade_name:'',group_name:'',category_id:-1,id:false},form_valid:false});
        this.props.onClose();
    };

    componentWillReceiveProps(props){
        if(props.grade_group && props.grade_group.id !== this.props.grade_group.id){
            this.setState({grade_group:JSON.parse(JSON.stringify(props.grade_group))},()=>this.checkFormValid());
        }
    }


    render() {
        const {open,classes,categories} = this.props;
        const {grade_group,form_valid,grades,groups} = this.state;

        return (
            <div>
                <Dialog
                    open={open}
                    fullWidth
                    maxWidth={'sm'}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogTitle id="form-dialog-title">Agregar grado y grupo</DialogTitle>
                    <DialogContent className={classes.paddingTop}>
                        <div className={classes.inputContainer}>
                            <AutoComplete label="Nombre del grado" className={classes.input} value={grade_group.grade_name} items={grades} onChange={value=>this.onChange('grade_name',value)}/>
                        </div>

                        <div className={classes.inputContainer}>
                            <AutoComplete label="Nombre del grupo" className={classes.input} value={grade_group.group_name} items={groups} onChange={value=>this.onChange('group_name',value)}/>
                        </div>
                        <TextField select fullWidth label="Habilidad" value={grade_group.category_id} className={classes.input}  onChange={(e)=>this.onChange('category_id',e.target.value)}>
                            <MenuItem key={null} value={-1}>Elige una opcion</MenuItem>
                            {categories.map(option => (
                                <MenuItem key={option.id} value={option.id}>
                                    {option.title}
                                </MenuItem>
                            ))}
                        </TextField>

                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => this.saveGradeGroup()} disabled={!form_valid} color="primary">
                            Guardar
                        </Button>
                        <Button onClick={() => this.handleClose()} color="primary">
                            Cerrar
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }

    saveGradeGroup(){
        const {grade_group} = this.state;
        if(grade_group.id){
            this.updateGradeGroup(grade_group);
        }else{
            this.addGradeGroup(grade_group);
        }

    }

    addGradeGroup(grade_group){
        let api     = new ApiHelper();
        let token   = localStorage.getItem('token');

        api.post('grade-group/',{grade_name:grade_group.grade_name,group_name:grade_group.group_name,category:grade_group.category_id},token).then(({data}) => {
            let grade_groups = store.getState().grade_groups;

            grade_groups.push(data.grade_group);

            this.props.setGradeGroups(grade_groups);

            Toast('Grado y grupo creado correctamente');

            this.handleClose();
        });
    }

    updateGradeGroup(grade_group){
        let api     = new ApiHelper();
        let token   = localStorage.getItem('token');

        api.post('grade-group/'+grade_group.id,{grade_name:grade_group.grade_name,group_name:grade_group.group_name,category:grade_group.category_id},token).then(({data}) => {
            let grade_group  = data.grade_group;
            let grade_groups = store.getState().grade_groups;
            let idx = grade_groups.findIndex((val) => ( val.id === parseInt(grade_group.id)));
            if(idx > -1){
                let original_grade = grade_groups[idx].grade_name;
                let original_group = grade_groups[idx].group_name;

                grade_groups.forEach((val,id) => {
                    console.log(val.grade_name,)
                    if(val.grade_name === original_grade){
                        grade_groups[id].grade_name = grade_group.grade_name;
                    }

                    if(val.group_name === original_group){
                        grade_groups[id].group_name = grade_group.group_name;
                    }
                });

                grade_groups[idx] = grade_group
            }

            this.props.setGradeGroups(JSON.parse(JSON.stringify(grade_groups)));

            Toast('Cambios guardados correctamente');

            this.handleClose();
        });
    }

    onChange(key,value){
        let {grade_group} = this.state;

        grade_group[key] = value;
        this.setState(grade_group,()=>this.checkFormValid());
    }

    checkFormValid(){
        const {grade_group} = this.state;

        this.setState({form_valid: grade_group.category_id !== -1 && grade_group.grade_name.trim().length >= 5 && grade_group.group_name.trim().length >= 1}) ;
    }

    getGrades(){
        this.api.get('grades/',this.token).then(({data}) => {
            let {grades} = data;
            let result   = [];
            grades.forEach((val) => {
                let grade = result.findIndex(gg=>(gg.label === val.name));
                if(grade < 0){
                    result.push({label:val.name});
                }
            });
            this.setState({grades:result});
        });
    }

    getGroups(){
        this.api.get('groups/',this.token).then(({data}) => {
            let {groups} = data;
            let result   = [];
            groups.forEach((val) => {
                let grade = result.findIndex(gg=>(gg.label === val.name));
                if(grade < 0){
                    result.push({label:val.name});
                }
            });
            this.setState({groups:result});

        });
    }

}

const stateToProps = ({users}) => ({users});
const dispatchToProps = (dispatch) => ({//custom props
    setGradeGroups : (data) => dispatch(setGradeGroups(data))
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(AddGradeGroup));