import React from 'react';
import {
    Dialog,
    DialogContent,
    withStyles, IconButton, AppBar, Toolbar, Typography
} from 'material-ui';
import Close from '@material-ui/icons/Close';
import modalStyle from '../../../../variables/styles/modalStyle';

import {connect} from "react-redux";
import EditLesson from "../../EditLesson/index";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";


class EditLessonModal extends React.Component {
    constructor(){
        super();
        this.state = {
           lesson:false
        };
    }

    componentWillMount(){
        let api     = new ApiHelper();
        let token   = localStorage.getItem('token');

        api.get('lessons/'+this.props.lesson, token).then(({data}) => {
            let lesson = data.lesson;
            this.setState({lesson})
        });
    }

    handleClose(){
        this.props.onClose();
    };

    render() {
        const {open,classes} = this.props;
        const {lesson} = this.state;

        return (
            <div>
                <Dialog
                    fullScreen
                    open={open}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <AppBar className={classes.appBar}>
                        <Toolbar>
                            <IconButton color="inherit" onClick={() => this.handleClose()} aria-label="Close">
                                <Close />
                            </IconButton>
                            <Typography variant="title" color="inherit" className={classes.flex}>
                                Editar leccion {lesson.name}
                            </Typography>

                        </Toolbar>
                    </AppBar>
                    <DialogContent className={classes.paddingTop}>
                        {lesson && <EditLesson lesson={lesson}/>}
                    </DialogContent>

                </Dialog>
            </div>
        );
    }

}

const stateToProps = ({lessons}) => ({lessons});
const dispatchToProps = (dispatch) => ({//custom props

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(EditLessonModal));