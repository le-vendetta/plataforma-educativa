import React from 'react';
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    withStyles,
    TextField,
    MenuItem,
    FormControl,
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';
import {connect} from "react-redux";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import {Col, Row} from "react-flexbox-grid";
import {withRouter} from "react-router-dom";
import Lessons from "../../Sessions/Lessons";

class NewSessionModal extends React.Component {
    constructor(){
        super();
        this.state = {
            grade_groups:[],
            courses:[],
            grade_group:0,
            course:0,
            available:null,
            session:{},
            lessons:[],
            list_visible:false
        };

        this.api = new ApiHelper();
        this.token = localStorage.getItem('token');
    }

    componentDidMount(){
        this.api.get('grade-groups', this.token).then(({data}) => {
            let grade_groups = data.grade_groups;
            this.setState({grade_groups});
        });

        this.api.get('courses-sessions', this.token).then(({data}) => {
            let courses = data.courses;
            this.setState({courses});
        });
    }

    handleClose(){
        this.props.onClose();
    };

    render() {
        const {open} = this.props;
        const {list_visible,available,lessons,session} = this.state;

        return (
            <div>
                <Dialog
                    maxWidth={'md'}
                    fullWidth
                    open={open}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogTitle id="form-dialog-title">{list_visible?'En que leccion quieres empezar':'Nueva clase'}</DialogTitle>
                    <DialogContent>
                        {list_visible?<Lessons lessons={lessons} session={session}/>:this.getForm()}
                    </DialogContent>
                    {!list_visible && <DialogActions>
                        <Button onClick={() => this.handleClose()} color="primary" >
                            Cerrar
                        </Button>

                        <Button onClick={() => this.makeSession()} color="primary" disabled={!available }>
                            Iniciar clase
                        </Button>
                    </DialogActions>}
                </Dialog>
            </div>
        );
    }

    makeSession(){
        const {course,grade_group} = this.state;
        this.api.post('session',{course,grade_group}, this.token).then(({data}) => {
            let {session} = data;
            this.setState({session});
            this.getLessons(session);
        });//this.props.onClose();

    }

    getLessons(session){
        this.api.get('session/'+session.id+'/lessons', this.token).then(({data}) => {
            let {lessons} = data;
            this.setState({lessons,list_visible:true})
        });
    }

    catchChange(key,elm){
        let {target} = elm;
        if(key === 'course'){
            this.setState({course:target.value},()=>{
                this.checkAvailable();
            });
        }

        if(key === 'grade_group'){
            this.setState({grade_group:target.value},()=>{
                this.checkAvailable();
            });
        }

    }

    checkAvailable(){
        let {course,grade_group} = this.state;

        if(course !== 0 && grade_group !== 0){
            this.api.get('sessions/available/'+course+'/'+grade_group, this.token).then(({data}) => {
                let available = data.available;
                this.setState({available});
            });
        }
    }


    getForm(){
        const {grade_groups,courses,available,grade_group,course} = this.state;
        return <Row>
            <Col md={6}>
                <FormControl fullWidth>
                    <TextField select label="Grado y grupo" value={grade_group} onChange={(e)=>this.catchChange('grade_group',e)}>
                        <MenuItem value={0}>
                            Elige una opción
                        </MenuItem>
                        {grade_groups.map(option => (
                            <MenuItem key={option.id} value={option.id}>
                                {option.grade_name} {option.group_name}
                            </MenuItem>
                        ))}
                    </TextField>
                </FormControl>

            </Col>
            <Col md={6}>
                <FormControl fullWidth>
                    <TextField select label="Curso" value={course} onChange={(e)=>this.catchChange('course',e)}>
                        <MenuItem value={0}>
                            Elige una opción
                        </MenuItem>
                        {courses.map(option => (
                            <MenuItem key={option.id} value={option.id}>
                                {option.name}
                            </MenuItem>
                        ))}
                    </TextField>
                </FormControl>

            </Col>

            <Col md={12}>
                {available === false && <small>Ya tienes una clase asignada con estos datos, reanuda la clase</small>}
            </Col>
        </Row>
    }
}

const stateToProps = null;
const dispatchToProps = null;

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(withRouter(NewSessionModal)));