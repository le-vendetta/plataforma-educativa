import React from 'react';
import {
    Button, TextField,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle, MenuItem,
    withStyles
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';

class EmbebModal extends React.Component {
    constructor(){
        super();
        this.state = {url:''};
    }

    handleClose(){
        this.props.onClose();
    };


    render() {
        const {open,classes} = this.props;

        const {url} = this.state;
        return (
            <div>
                <Dialog
                    open={open}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogContent>
                        <TextField autoFocus label="Url del video o audio" fullWidth className={classes.input} value={url} onChange={(e)=>this.catchChange(e)}/>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => this.handleClose()} color="primary">
                            Cancelar
                        </Button>
                        <Button onClick={() => this.sendUrl()} color="primary">
                            Guardar
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
    sendUrl(){
        this.props.onUrl(this.state.url+'');
        this.setState({url:''});
        this.props.onClose();
    }
    catchChange(event){
        this.setState({url:event.target.value});
    }

}


export default withStyles(modalStyle)(EmbebModal);