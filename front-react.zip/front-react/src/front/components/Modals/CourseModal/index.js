import React from 'react';
import {
    Button, TextField,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle, MenuItem,
    withStyles
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';
import {getCourseCategories,updateCourse,newCourse} from "../../../../app/rdx/actions/coursesActions";

import {connect} from "react-redux";

const types = [{value:'live',label:'En vivo'},{value:'open',label:'Abierta'}];

class CourseModal extends React.Component {
    constructor(){
        super();
        this.state = {course:{}};
    }

    componentDidMount(){
        this.props.getCourseCategories();
    }

    handleClose(){
        this.props.onClose();
    };

    componentWillReceiveProps(props){
        if(props.course && Object.keys(props.course).length > 0 && props.course.id !== this.props.course.id){
            let course = {...props.course};
            course.image = ' ';
            this.setState({course});
        }
    }

    render() {
        const {open,classes,course_categories} = this.props;

        const {course} = this.state;
        return (
            <div>
                <Dialog
                    open={open}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogTitle id="form-dialog-title">{course.id?`Editar curso #${course.id}`:'Crear curso'}</DialogTitle>
                    <DialogContent>
                        <TextField autoFocus label="Nombre" fullWidth className={classes.input} value={course.name || ''} onChange={(e)=>this.catchChange('name',e)}/>
                        <TextField label="Descripcion" fullWidth className={classes.input} multiline
                                   rowsMax="4" value={course.description || ''} onChange={(e)=>this.catchChange('description',e)}/>

                        <TextField select label="Tipo" value={course.course_type || -1} className={classes.input+' '+classes.percent48+' '+classes.marginR2}  onChange={(e)=>this.catchChange('course_type',e)}>
                            <MenuItem key={null} value={-1}>Elige una opcion</MenuItem>
                            {types.map(option => (
                                <MenuItem key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </TextField>

                        <TextField select label="Categoria" value={course.category_id || -1} className={classes.input+' '+classes.percent48} onChange={(e)=>this.catchChange('category_id',e)}>
                            <MenuItem key={null} value={-1}>Elige una opcion</MenuItem>

                            {course_categories && course_categories.map(option => (
                                <MenuItem key={option.id} value={option.id}>
                                    {option.title}
                                </MenuItem>
                            ))}
                        </TextField>

                        <input
                            id="file"
                            type="file"
                            onChange={(e)=>this.catchChange('image',e,true)} accept="image/*"
                            style={{
                                width: 0,
                                height: 0,
                                opacity: 0,
                                overflow: 'hidden',
                                position: 'absolute',
                                zIndex: 1,
                            }}
                        />
                        <Button component="label" htmlFor="file">
                            Imagen
                        </Button>


                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => this.handleClose()} color="primary">
                            Cancelar
                        </Button>
                        <Button onClick={() => this.saveCourse()} color="primary">
                            Guardar
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }

    catchChange(name,event,file = false){
        let target =  event.target;
        let {course} = {...this.state};
        if(!file){
            course[name] = target.value;
        }else{
            course[name] = target.files[0];
        }
        this.setState({course});
    }

    saveCourse(){
        let {course} = this.state;

        if(course.id){

            this.props.updateCourse(course);
        }else{
            this.props.newCourse(course);
        }

        this.props.onSubmit(course);
    }
}

const stateToProps = ({course_categories}) => ({course_categories});
const dispatchToProps = (dispatch) => ({//custom props
    getCourseCategories: () => dispatch(getCourseCategories()),
    updateCourse: (data) => dispatch(updateCourse(data)),
    newCourse: (data) => dispatch(newCourse(data)),

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(CourseModal));