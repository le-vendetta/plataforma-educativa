import React from 'react';
import {
    Dialog,
    DialogContent,
    withStyles, IconButton, AppBar, Toolbar, Typography
} from 'material-ui';
import Close from '@material-ui/icons/Close';
import modalStyle from '../../../../variables/styles/modalStyle';

import {connect} from "react-redux";
import NewLesson from "../../NewLesson/index";


class NewLessonModal extends React.Component {
    constructor(){
        super();
        this.state = {
           lesson:{}
        };
    }

    handleClose(){
        this.props.onClose();
    };

    render() {
        const {open,classes,course} = this.props;

        return (
            <div>
                <Dialog
                    fullScreen
                    open={open}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <AppBar className={classes.appBar}>
                        <Toolbar>
                            <IconButton color="inherit" onClick={() => this.handleClose()} aria-label="Close">
                                <Close />
                            </IconButton>
                            <Typography variant="title" color="inherit" className={classes.flex}>
                                Agregar leccion al curso: {course.name}
                            </Typography>

                        </Toolbar>
                    </AppBar>
                    <DialogContent className={classes.paddingTop}>
                        <NewLesson lesson={{}} course={course}/>
                    </DialogContent>

                </Dialog>
            </div>
        );
    }

}

const stateToProps = ({lessons}) => ({lessons});
const dispatchToProps = (dispatch) => ({//custom props

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(NewLessonModal));