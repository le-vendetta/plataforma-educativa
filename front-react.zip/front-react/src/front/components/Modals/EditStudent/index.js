import React from 'react';
import {
    Dialog,
    DialogContent,
    withStyles, DialogTitle, TextField, DialogActions, Button,Divider
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';

import {connect} from "react-redux";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import Toast from "../../../../app/core/helpers/Toast";


class EditStudent extends React.Component {
    constructor(){
        super();
        this.state = {
            user:{},
            form_valid:false
        };

        this.api = new ApiHelper();
    }

    handleClose(){
        let {user} = this.state;
        this.props.onClose(user);
    };
    componentWillReceiveProps(props){
        if(this.state.user.id !== props.user.id || (Object.keys(props.user).length > 0 && Object.keys(this.state.user).length === 0)){
            this.setState({user:props.user},()=>this.checkForm());
        }
    }
    render() {
        const {open,classes} = this.props;
        const {user,form_valid} = this.state;

        return (
            <div>
                <Dialog
                    open={open}
                    fullWidth
                    maxWidth={'sm'}
                    onClose={() => this.handleClose()}
                    aria-labelledby="form-dialog-title"
                >
                    <DialogTitle id="form-dialog-title">Editar alumno</DialogTitle>
                    <DialogContent className={classes.paddingTop}>
                        <TextField fullWidth label="Nickname" value={user.nickname} className={classes.input}  onChange={(e)=>this.change('nickname',e.target.value)}/>
                        <TextField fullWidth label="Nombre" value={user.name} className={classes.input}  onChange={(e)=>this.change('name',e.target.value)}/>
                        <TextField fullWidth label="Apellidos" value={user.last_name} className={classes.input}  onChange={(e)=>this.change('last_name',e.target.value)}/>
                        <TextField fullWidth label="Correo" value={user.email} className={classes.input}  onChange={(e)=>this.change('email',e.target.value)}/>
                        <Divider style={{marginTop:50, marginBottom:20}}/>
                        <TextField type="password" fullWidth label="Contraseña" value={user.password} className={classes.input}  onChange={(e)=>this.change('password',e.target.value)}/>
                        <TextField type="password" fullWidth label="Repetir Contraseña" value={user.password_confirmation} className={classes.input}  onChange={(e)=>this.change('password_confirmation',e.target.value)}/>

                    </DialogContent>
                    <DialogActions>
                        <Button onClick={() => this.handleClose()} color="primary">
                            Cerrar
                        </Button>
                        <Button onClick={() => this.saveStudent()} color="primary" disabled={!form_valid}>
                            Aceptar
                        </Button>
                    </DialogActions>

                </Dialog>
            </div>
        );
    }

    change(key,value){
        let user = {...this.state.user};

        user[key] = value;

        this.setState({user},()=>{
            this.checkForm();
        });
    }


    saveStudent(){
        let token   = localStorage.getItem('token');
        let {user} = this.state;
        let {nickname,name,last_name,email,password} = user;

        this.api.put('users/students/'+user.id,{nickname,name,last_name,email,password},token).then(({data})=>{

            this.handleClose();

            Toast("Alumno guardado correctamente");
        });

    }

    checkForm(){
        let {user} = this.state;
        if(user.nickname.length > 2 && user.name.length > 2 && user.last_name.length > 2 && user.email.length > 2){
            if(this.validateEmail(user.email)){
                if(user.password){
                    if(user.password.length > 5 && user.password === user.password_confirmation){
                        this.setState({form_valid:true});
                    }
                }else{
                    this.setState({form_valid:true});
                }
            }
        }
    }

    validateEmail(email) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    }
}

const stateToProps = ({lessons}) => ({lessons});
const dispatchToProps = (dispatch) => ({//custom props

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(EditStudent));