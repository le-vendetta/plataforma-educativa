import React from "react";
import {
    withStyles,
    Card,
    CardContent,
    CardHeader,
    CardActions, Avatar
} from "material-ui";
import PropTypes from "prop-types";
import cx from "classnames";

import regularCardStyle from "../../../variables/styles/regularCardStyle";

function ImageCard({...props}) {
    const {
        classes,
        headerColor,
        plainCard,
        cardTitle,
        cardSubtitle,
        content,
        footer,
        disabled,
    } = props;
    const plainCardClasses = cx({
        [" " + classes.cardPlain]: plainCard
    });
    const cardPlainHeaderClasses = cx({
        [" " + classes.cardPlainHeader]: plainCard
    });
    let avatar = props.avatar?<Avatar src={props.avatar} className={classes.imageHeader+(disabled?' blur':'')}/>:'';
    return (
        <Card className={classes.card + plainCardClasses}>
            <CardHeader
                classes={{
                    root:
                    classes.cardImageHeader +
                    " " +
                    classes[(disabled?'gray':headerColor) + "CardHeader"] +
                    cardPlainHeaderClasses,
                    subheader: classes.cardSubtitle,
                }}
                avatar={avatar}
                title={cardTitle}
            />
            <CardContent>
                <strong>{cardSubtitle}</strong>

                {content}
                </CardContent>
            {footer !== undefined ? (
                <CardActions className={classes.cardActions}>{footer}</CardActions>
            ) : null}
        </Card>
    );
}

ImageCard.defaultProps = {
    headerColor: "purple"
};

ImageCard.propTypes = {
    plainCard: PropTypes.bool,
    classes: PropTypes.object.isRequired,
    headerColor: PropTypes.oneOf(["orange", "green", "red", "blue", "purple", "gray"]),
    cardTitle: PropTypes.node,
    cardSubtitle: PropTypes.node,
    content: PropTypes.node,
    footer: PropTypes.node
};

export default withStyles(regularCardStyle)(ImageCard);
