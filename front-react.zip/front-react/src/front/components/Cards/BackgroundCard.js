import React from "react";
import {Card, withStyles} from "material-ui";
import cardStyle from "./../../../variables/styles/cardStyle";
class BackgroundCard extends React.Component{
    render(){
        let {background,classes,className} = this.props;

        if(!background){
            background = process.env.PUBLIC_URL + "/assets/images/bg-slides-white.png";
        }

        return(
            <Card style={{backgroundImage: `url(${background})`}} className={[classes.cardWitBackground,className].join(' ')}>
                {this.props.children}
            </Card>
        );
    }
}

export default withStyles(cardStyle)(BackgroundCard);