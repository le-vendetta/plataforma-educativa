import React, {Component} from 'react';

import {connect} from "react-redux";
import {Carousel} from "react-responsive-carousel";
import 'react-responsive-carousel/lib/styles/carousel.css';

import slider from "../../../variables/styles/slider";
import {withStyles} from "material-ui";

import 'ory-editor-plugins-parallax-background/lib/index.css'

import divider from 'ory-editor-plugins-divider';
import native from 'ory-editor-plugins-default-native';

/* -------------------- custom plugins -------------------------- */
import form from '../../../editor-plugins/container-plugins/form/index';
import separator from '../../../editor-plugins/content-plugins/separator/index';
import frame from '../../../editor-plugins/container-plugins/frame/index';
import imageFrame from '../../../editor-plugins/container-plugins/imageFrame/index';

import { HTMLRenderer } from 'ory-editor-renderer';

// Define which plugins we want to use. We only have slate and parallax available, so load those.
const plugins = {
    content: [divider,
        separator,
        frame,
        imageFrame,
        form],
    native
};


class Slider extends Component {
    constructor() {
        super();
        this.state = {sliders:[]};

    }

    componentDidMount(){
        this.setState({sliders: JSON.parse(this.props.lesson.content)});
    }

    componentWillReceiveProps(props){
        if(props.selected !== this.props.selected && this.state.sliders.length-1 === props.selected){
            if(typeof this.props.onEnd === 'function'){
                this.props.onEnd();
            }
        }

    }

    render() {
        const {classes,course,user,selected} = this.props;

        const {sliders} = this.state;

        return selected !== null && <Carousel infiniteLoop={false}
                         swipeable={course.course_type === 'open' || user.role_key !== 'student' }
                         showArrows={course.course_type === 'open' || user.role_key !== 'student' }
                         showStatus={true}
                         showThumbs={false}
                         showIndicators={false}
                         className={classes.slider}
                         selectedItem={selected}
                         onChange={(index)=>this.changeStep(index)}>
                    {sliders.map((lesson,idx) => {
                        return  <div className={classes.sliderItem} key={idx}>
                                    <HTMLRenderer state={lesson.content} plugins={plugins} />
                                </div>
                    })}
                </Carousel>
            ;
    }

    changeStep(index){
        if(index !== this.props.selected){
            if(typeof this.props.onChange === 'function'){
                this.props.onChange(index);
            }
        }
    }
}

const stateToProps = ({lesson,course,user}) => ({lesson,course,user});
const dispatchToProps = null;

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(slider)(conn(Slider));
