import React ,{Component} from 'react';
import {Col, Row} from "react-flexbox-grid";
import {connect} from "react-redux";
import {
    Button,
    Paper, Step, StepButton, Stepper,
    TextField, Tooltip,
    withStyles
} from "material-ui";
import newLessonStyle from '../../../variables/styles/newLessonStyle';
import {saveLesson} from "../../../app/rdx/actions/coursesActions";
import ContentEditor from '../ContentEditor/index';
import {createEmptyState } from 'ory-editor-core';
import ReactSortable from "react-sortablejs";
import Icon from '@material-ui/core/Icon';

class NewLesson extends Component {
    constructor() {
        super();
        this.state = {
            lesson: {
                name: '',
                description:''
            },
            lessonTypes: {},
            textContent: '',
            expanded: 'panel1',
            steps: [{content: createEmptyState()}],
            step: 0,
            refs: [],
            is_valid:false,
            send:false
        };

        this.textRef = null;
    }

    componentWillReceiveProps(props) {
        if (Object.keys(props.lesson).length > 0 && this.props.lesson.id !== props.lesson.id) {
            this.setState({lesson: props.lesson});

            if (props.lesson.type_slug === 'sliders') {
                let content = JSON.parse(props.lesson.content);
                let steps = [];
                content.forEach(val => {
                    steps.push(val);
                });
                this.setState({steps})
            }

            if (props.lesson.type_slug === 'text') {
                this.setState({textContent: props.lesson.content})
            }
        }
    }


    render() {
        const {classes} = this.props;
        const {steps, step, lesson,is_valid,send} = this.state;
        return <Row>
            <Col md={12}>
                <Paper>
                    <Col md={12}>
                        <Row >
                            <Col md={10}>
                                <Col md={12} className={classes.editor}>
                                    <Row end="xs">
                                        <Col md={3}>
                                            #{step+1}
                                        </Col>
                                    </Row>
                                    <ContentEditor items={steps} itemVisible={step} onChange={(editor) => this.onEditorChange(editor)} send={send}/>
                                </Col>
                            </Col>
                            <Col md={2}>
                                <Col md={12}>
                                    <Row center="xs" middle="xs">
                                        <Col md={12}>
                                            <Button onClick={() => this.addSlider()} color="primary" fullWidth={true}>Añadir slider</Button>
                                        </Col>
                                    </Row>
                                    <div style={{background:'#ccc', paddingTop:10,paddingBottom:10,minHeight:"58vh",maxHeight:"58vh",overflow:"scroll"}}>
                                        <ReactSortable
                                            onChange={(order, sortable, evt) => this.changeOrder(order, sortable, evt)}
                                        >
                                        {steps.map((content, idx) => (
                                            <Row center="xs" middle="xs" key={idx} data-id={idx} className={classes.relative}>
                                                <Col md={10} className={classes.sortableItem+' '+(idx === step?classes.sortableItemHover:'')} onClick={()=>this.changeStep(idx)}>
                                                    <Tooltip title="Eliminar elemento">
                                                        <Icon className={classes.btnRemove} onClick={()=>this.removeItem(idx)}>clear</Icon>
                                                    </Tooltip>

                                                    <div className={classes.sortableItemText}>
                                                        #{idx}
                                                    </div>
                                                </Col>
                                            </Row>
                                        ))}
                                    </ReactSortable>

                                    </div>

                                </Col>
                            </Col>
                        </Row>
                    </Col>

                    <Col md={12} className={classes.details}>
                        <Row bottom='xs'>
                            <Col md={5}>
                                <TextField autoFocus label="Nombre" fullWidth className={classes.input}
                                           value={lesson.name || ''} onChange={(e) => this.catchChange('name', e)}/>
                            </Col>
                            <Col md={5}>
                                <TextField label="Descripcion" fullWidth className={classes.input} multiline
                                           rowsMax="4" value={lesson.description || ''}
                                           onChange={(e) => this.catchChange('description', e)}/>

                            </Col>
                            <Col md={2}>
                                <Row center="xs">
                                    <Button onClick={()=>this.saveLesson()} disabled={!is_valid} color="primary">Guardar</Button>
                                </Row>
                            </Col>
                        </Row>
                    </Col>
                </Paper>
            </Col>
        </Row>
    }

    changeOrder(order,sortable,ev){

        let {steps}   = this.state;
        let result    = [];

        order.forEach((val,idx)=>{
            result[idx] = steps[parseInt(val)];
        });

        this.setState({steps:result,send:true},()=>{
            this.setState({send:false});
        });
    }

    saveLesson(){
        const {lesson,steps} = this.state;
        let data = {
            name: lesson.name,
            description:lesson.description,
            content:JSON.stringify(steps)
        }
        this.props.saveLesson(this.props.course.id,data);
    }

    onEditorChange(editor){
        let {step,steps} = this.state;
        if(steps[step].content.id === editor.id){
            steps[step].content = editor;
            this.setState({steps})
        }

    }

    changeStep(step) {
        this.setState({step: step})
    }

    addSlider() {
        let {steps} = this.state;
        let content = createEmptyState();

        steps.push({content});
        this.setState({steps},()=>{
            this.setState({step: steps.length - 1})

        });
    }

    removeItem(step){
        let {steps} = this.state;
        delete steps[step];
        steps = JSON.parse(JSON.stringify(steps.filter(val => val)));
        this.setState({steps},()=>{
            this.setState({step: steps.length - 1})
        });
    }

    catchChange(name, event) {
        let target = event.target;
        let {lesson} = {...this.state};
        lesson[name] = target.value;
        this.moreChanges(name);
        this.setState({lesson});
        this.checkIsValid();

    }

    checkIsValid(){
        let {lesson} = this.state;
        if(lesson.name.length > 0 && lesson.description.length > 0){
            this.setState({is_valid:true})
        }

    }

    moreChanges(name) {
        if (name === 'lesson_type_id'){
            this.setState({refs:{},textRef:null});
        }
    }

}


const stateToProps = ({lesson_types}) => ({lesson_types});
const dispatchToProps = (dispatch) => ({//custom props
    saveLesson: (course,content) => dispatch(saveLesson(course,content)),

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(newLessonStyle)(conn(NewLesson));
