import Button from "./CustomButtons/Button.jsx";
import BackgroundPaper from "./BackgroundPaper";

import Footer from "./Footer/Footer.jsx";

import Header from "./Header/Header.jsx";
import HeaderLinks from "./Header/HeaderLinks.jsx";

import HeaderMenu from "./HeaderMenu/index";

import Sidebar from "./Sidebar/Sidebar.jsx";

import SnackbarContent from "./Snackbar/SnackbarContent.jsx";

import P from "./Typography/P.jsx";

import A from "./Typography/A.jsx";

import Slider from './Slider/index';

import EditStudent from './Modals/EditStudent';
import AddStudents from './Modals/AddStudents';
import AddGradeGroup from './Modals/AddGradeGroup';

import Loading from "./Loading";
import SortTable from "./Tables/SortTable";

export {

    Button,

    Footer,

    Header,
    HeaderLinks,
    HeaderMenu,
    Sidebar,
    SnackbarContent,
    BackgroundPaper,
    P,
    Slider,
    A,

    EditStudent,
    AddStudents,
    AddGradeGroup,


    Loading,
    SortTable,
};
