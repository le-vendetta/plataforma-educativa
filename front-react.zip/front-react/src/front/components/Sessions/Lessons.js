import React from 'react';
import {
    withStyles,
    Tooltip,
    ListItem,
    ListItemText,
    ListItemSecondaryAction, List
} from 'material-ui';
import listStyle from '../../../variables/styles/list';
import {connect} from "react-redux";

import {Col, Row} from "react-flexbox-grid";
import Done from '@material-ui/icons/Done';
import {withRouter} from "react-router-dom";
import ApiHelper from "../../../app/core/helpers/ApiHelper";

class Lessons extends React.Component {

    constructor(){
        super();
        this.api = new ApiHelper();
        this.token = localStorage.getItem('token');
    }

    render() {
        const {lessons} = this.props;
        return (
            <Row>
                <Col md={12}>
                    {lessons && <List >
                        {lessons.map((lesson,idx) => {
                            return  <ListItem divider button key={idx} onClick={()=> this.setThisLesson(lesson.id,lesson.current)}>
                                <ListItemText primary={`#${lesson.id} ${lesson.name}`} secondary={`${lesson.description}`}/>
                                <ListItemSecondaryAction>
                                    {lesson.current && <Tooltip title="Curso actual" placement="top"><Done/></Tooltip>}
                                    {lesson.type_name}
                                </ListItemSecondaryAction>
                            </ListItem>
                        })}
                    </List>}
                </Col>
            </Row>
        );
    }


    setThisLesson(lesson,is_current){
        const {session} = this.props;
        if(is_current){
            this.props.history.push(process.env.PUBLIC_URL + '/clase/'+session.id);
        }else{
            this.api.put('session/'+session.id+'/lesson',{lesson},this.token).then(({data}) => {
                if(this.props.location.pathname === process.env.PUBLIC_URL + '/clase/'+session.id){
                    this.props.onReload(lesson)
                }else{
                    this.props.history.push(process.env.PUBLIC_URL + '/clase/'+session.id);
                }
            });
        }
    }


}

const stateToProps = null;
const dispatchToProps = null;

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(listStyle)(conn(withRouter(Lessons)));