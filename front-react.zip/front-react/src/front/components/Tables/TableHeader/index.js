import {Checkbox, TableCell, TableHead, TableRow, TableSortLabel, Tooltip} from "material-ui";
import React from "react";

class TableHeader extends React.Component {
    createSortHandler = property => event => {
        this.props.onRequestSort(event, property);
    };

    render() {
        const { onSelectAllClick, order, orderBy, numSelected, rowCount,headerStructure } = this.props;
        let enableCheck = this.props.enableCheck !== undefined?this.props.enableCheck:true;
        return (
            <TableHead>
                <TableRow>
                    {enableCheck && <TableCell padding="checkbox">
                        <Checkbox
                            indeterminate={numSelected > 0 && numSelected < rowCount}
                            checked={numSelected === rowCount}
                            onChange={onSelectAllClick}
                        />
                    </TableCell>}
                    {headerStructure.map(column => {
                        let sortable = column.sortable !== undefined?column.sortable:true;
                        return (
                            <TableCell
                                key={column.id}
                                numeric={column.numeric}
                                padding='none'
                                style={{padding:column.disablePadding ? 'none' : '0px 2%'}}
                                sortDirection={orderBy === column.id ? order : false}
                            >
                                {sortable ? <Tooltip
                                    title="Ordenar"
                                    placement={column.numeric ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={orderBy === column.id}
                                        direction={order}
                                        onClick={this.createSortHandler(column.id)}
                                    >
                                        {column.label}
                                    </TableSortLabel>
                                </Tooltip>:column.label}
                            </TableCell>
                        );
                    }, this)}
                </TableRow>
            </TableHead>
        );
    }
}

export default TableHeader;
