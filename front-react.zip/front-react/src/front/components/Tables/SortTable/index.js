import React from 'react';
import {
    withStyles, Table, TableBody, TableRow,
    TableCell, TablePagination, Checkbox
} from 'material-ui';
import modalStyle from '../../../../variables/styles/modalStyle';
import {getLessons} from "../../../../app/rdx/actions/coursesActions";
import {connect} from "react-redux";
import TableHeader from "../TableHeader/index";
import ToolbarTable from '../ToolbarTable/index';

function getSorting(order, orderBy) {
    return order === 'desc'
        ? (a, b) => (b[orderBy] < a[orderBy] ? -1 : 1)
        : (a, b) => (a[orderBy] < b[orderBy] ? -1 : 1);
}

class SortTable extends React.Component {
    constructor(){
        super();
        this.state = {
            order: 'asc',
            orderBy: 'id',
            selected: [],
            page: 0,
            rowsPerPage:10,
            course:{},lessons:[]};
    }

    componentDidMount(){
        this.setState({rowsPerPage:this.props.rowsPerPage !== undefined?this.props.rowsPerPage:10});
    }

    onDelete(){
        if(typeof this.props.onDelete === 'function'){
            this.props.onDelete(JSON.parse(JSON.stringify(this.state.selected)));
            this.setState({selected:[]});
        }
    }
    render() {
        const {items,classes,id,title} = this.props;
        let enableCheck = this.props.enableCheck !== undefined?this.props.enableCheck:true;

        const {order,orderBy,selected,page,rowsPerPage} = this.state;
        const emptyRows = rowsPerPage - Math.min(rowsPerPage, items && items.length - page * rowsPerPage);
        return (
            <div>
                {enableCheck && <ToolbarTable  numSelected={selected.length} title={title} onDelete={()=> this.onDelete()}/>}
                <div className={classes.tableWrapper}>
                    <Table className={classes.table} aria-labelledby="tableTitle" >
                        <TableHeader
                            numSelected={selected.length}
                            order={order}
                            orderBy={orderBy}
                            enableCheck={this.props.enableCheck}
                            onRequestSort={this.handleRequestSort}
                            rowCount={items.length}
                            headerStructure={this.props.headerStructure}
                            onSelectAllClick={this.handleSelectAllClick}
                        />
                        <TableBody style={{backgroundImage:`url(${process.env.PUBLIC_URL + "/assets/images/bg-slides-white.png"})`}}>
                            {items
                                .sort(getSorting(order, orderBy))
                                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                .map(n => {
                                    const isSelected = this.isSelected(n.id);
                                    return (
                                        <TableRow
                                            hover
                                            onClick={event => enableCheck ? this.handleClick(event, n[id]):this.checkOnClick(n[id])}
                                            aria-checked={isSelected}
                                            tabIndex={-1}
                                            key={n[id]}
                                            selected={isSelected}
                                        >
                                            {enableCheck && <TableCell padding="checkbox">
                                                <Checkbox checked={isSelected} />
                                            </TableCell>}
                                            {this.props.rowStructure(n,isSelected)}
                                        </TableRow>
                                    );
                                })}
                            {emptyRows > 0 && (
                                <TableRow style={{ height: 49 * emptyRows }}>
                                    <TableCell colSpan={this.props.headerStructure.length+(enableCheck?1:0)} />
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
                <TablePagination
                    component="div"
                    count={items.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    backIconButtonProps={{
                        'aria-label': 'Previous Page',
                    }}
                    nextIconButtonProps={{
                        'aria-label': 'Next Page',
                    }}
                    onChangePage={this.handleChangePage}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage}
                />
            </div>


        );
    }

    handleChangePage = (event, page) => {
        this.setState({ page });
    };


    handleChangeRowsPerPage = event => {
        this.setState({ rowsPerPage: event.target.value });
    };

    isSelected = id => this.state.selected.indexOf(id) !== -1;

    handleRequestSort = (event, property) => {
        const orderBy = property;
        let order = 'desc';

        if (this.state.orderBy === property && this.state.order === 'desc') {
            order = 'asc';
        }

        this.setState({ order, orderBy });
    };
    handleSelectAllClick = (event, checked) => {
        if (checked) {
            this.setState({ selected: this.props.items.map(n => n.id) });
            return;
        }
        this.setState({ selected: [] });
    };

    handleClick = (event, id) => {
        const { selected } = this.state;
        const selectedIndex = selected.indexOf(id);
        let newSelected = [];
        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, id);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selected.slice(0, selectedIndex),
                selected.slice(selectedIndex + 1),
            );
        }
        this.setState({ selected: newSelected });

        if(typeof this.props.onRowClick === 'function'){
            this.props.onRowClick(id);
        }
    };

    checkOnClick(id){
        if(typeof this.props.onRowClick === 'function'){
            this.props.onRowClick(id);
        }
    }
}

const stateToProps = ({course_categories}) => ({course_categories});
const dispatchToProps = (dispatch) => ({//custom props
    getLessons: (course) => dispatch(getLessons(course)),

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(modalStyle)(conn(SortTable));