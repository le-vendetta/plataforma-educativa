import classNames from "classnames";
import {IconButton, Toolbar, Tooltip, Typography, withStyles} from "material-ui";
import React from "react";
import {Delete} from "mdi-material-ui";

const toolbarStyles = theme => ({
    root: {
        paddingRight: theme.spacing.unit,
    },
    highlight:
        {
            color: theme.palette.secondary.main,
            backgroundColor: 'rgba(255,0,0,.2)',
        },
    spacer: {
        flex: '1 1 100%',
    },
    actions: {
        color: theme.palette.text.secondary,
    },
    title: {
        flex: '0 0 auto',
    },
});

let ToolbarTable = props => {
    const { numSelected, classes,title } = props;

    return (
        (title || numSelected > 0) && <Toolbar
            className={classNames(classes.root, {
                [classes.highlight]: numSelected > 0,
            })}
        >
            <div className={classes.title}>
                {numSelected > 0 ? (
                    <Typography color="inherit" variant="subheading">
                        {numSelected} Seleccionado
                    </Typography>
                ) : (
                    <Typography variant="title" id="tableTitle">
                        {title}
                    </Typography>
                )}
            </div>
            <div className={classes.spacer} />
            <div className={classes.actions}>
                {numSelected > 0 && (
                    <Tooltip title="Delete">
                        <IconButton aria-label="Delete" onClick={() => props.onDelete()}>
                            <Delete />
                        </IconButton>
                    </Tooltip>
                )}
            </div>
        </Toolbar>
    );
};

export default withStyles(toolbarStyles)(ToolbarTable);
