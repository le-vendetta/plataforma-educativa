import React,{Component} from 'react';
// The editor core
import Editor, { Editable, createEmptyState } from 'ory-editor-core';
import 'ory-editor-core/lib/index.css';

import { Trash, DisplayModeToggle, Toolbar } from 'ory-editor-ui'
import 'ory-editor-ui/lib/index.css';

import native from 'ory-editor-plugins-default-native';

/* -------------------- custom plugins -------------------------- */
import form from '../../../editor-plugins/container-plugins/form';
import separator from '../../../editor-plugins/content-plugins/separator';
import frame from '../../../editor-plugins/container-plugins/frame';
import imageFrame from '../../../editor-plugins/container-plugins/imageFrame';


//import { HTMLRenderer } from 'ory-editor-renderer'
//<HTMLRenderer state={content[0]} plugins={plugins} />
require('react-tap-event-plugin')();

const plugins = {
    content: [form,imageFrame,separator,frame],
    native
};


class ContentEditor extends Component{
    state = {content:createEmptyState(),editor:false};
    constructor(props){
        super(props);
        let contents = [];
        props.items.forEach(item => {
            contents.push(item.content);
        });

        const editor = new Editor({
            plugins,
            editables: contents,
            defaultPlugin:form
        });
        editor.trigger.mode.edit();
        this.state = {contents,editor};
    }

    componentWillReceiveProps(props){
        let current = JSON.stringify(this.state.contents);
        let here    = [];

        if(props.items.length >0){

            if(this.state.contents.length !== props.items.length ) {
                let contents = [];
                props.items.forEach(item => {
                    contents.push(item.content);
                });

                let {editor} = this.state;
                editor.trigger.editable.add(contents[contents.length-1])
                this.setState({contents});
                return;
            }

            props.items.forEach(item => {
                here.push(item.content);
            });
            let actual  = JSON.stringify(here);

            if(actual !== current && props.send){
                this.setState({contents:here});
            }

        }

    }

    render(){
        const {editor,contents} = this.state;
        return (
            editor && <div>
                {contents.map((content,idx) => {
                    return <div key={'content' + idx} style={{display: idx === this.props.itemVisible ? 'block' : 'none'}}>
                        <Editable editor={editor} id={content.id} onChange={(editor)=>this.onChange(editor)} />
                    </div>
                })}

                <Trash editor={editor}/>
                <DisplayModeToggle editor={editor}/>
                <Toolbar editor={editor}/>
            </div>
        );
    }

    onChange(editor){
        this.props.onChange(editor)
    }
}


export default ContentEditor;
