import React from "react";
import PropTypes from "prop-types";
import {Menu} from "@material-ui/icons";
import {
    withStyles,
    AppBar,
    Toolbar,
    IconButton,
    Hidden,
    Button
} from "material-ui";
import cx from "classnames";

import headerStyle from "../../../variables/styles/headerStyle.jsx";
import {Link} from "react-router-dom";

import HeaderLinks from "./HeaderLinks";

function replaceAll(target, search, replace) {
    return target.replace(new RegExp(search, 'g'), replace);
}

function Header({...props}) {


    function makeBrand() {
        let found = props.routes.map((prop, key) => {
            let fullPath = process.env.PUBLIC_URL + prop.path;
            let pathName = props.location.pathname.replace(/\/\s*$/, "")
            let location = pathName.split('/').filter(function (e) {
                return e
            });
            let path = fullPath.split('/').filter(function (e) {
                return e
            });
            if (fullPath === pathName) {
                return prop.navbarName;
            } else if (location.length === path.length) {

                if (fullPath.indexOf('/:') > -1) {
                    let matches = 0;
                    let params = 0;
                    let title = '';

                    path.forEach((value, idx) => {
                        if (value.indexOf(':') > -1) {
                            let text = replaceAll(location[idx], '-', ' ');
                            text = text.charAt(0).toUpperCase() + text.slice(1);
                            title = text;

                            params++;
                        } else if (value === location[idx]) {
                            matches++;
                        }
                    });

                    if (matches + params === path.length) {
                        return title;
                    }
                }
            }
            return null;
        });
        return found.filter(function (n) {
            return n != null
        })[0];
    }

    const {classes, color} = props;
    const appBarClasses = cx({
        [" " + classes[color]]: color
    });
    return (
        <AppBar className={classes.appBar + appBarClasses}>
            <Toolbar className={classes.container}>
                <div className={classes.flex}>
                    {/* teacher */}
                    <Button className={classes.title} component={Link} to={process.env.PUBLIC_URL + '/'}>
                         <img src={process.env.PUBLIC_URL + "/assets/images/header-logo.png"} alt="" className={classes.titleimg}/>
                    </Button>
                </div>
                <Hidden smDown implementation="css">
                    <HeaderLinks/>
                </Hidden>
                <Hidden mdUp>
                    <IconButton
                        className={classes.appResponsive}
                        color="inherit"
                        aria-label="open drawer"
                        onClick={props.handleDrawerToggle}
                    >
                        <Menu/>
                    </IconButton>
                </Hidden>
            </Toolbar>
        </AppBar>
    );
}

Header.propTypes = {
    classes: PropTypes.object.isRequired,
    color: PropTypes.oneOf(["primary", "info", "success", "warning", "danger"])
};

export default withStyles(headerStyle)(Header);
