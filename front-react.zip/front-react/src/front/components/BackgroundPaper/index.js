import React from "react";
import {Paper, withStyles} from "material-ui";
import cardStyle from "./../../../variables/styles/cardStyle";
class BackgroundPaper extends React.Component{
    render(){
        let {background,classes,className} = this.props;

        if(!background){
            background = process.env.PUBLIC_URL + "/assets/images/bg-slides-white.png";
        }

        return(
            <Paper style={{backgroundImage: `url(${background})`}} className={[classes.cardWitBackground,className].join(' ')}>
                {this.props.children}
            </Paper>
        );
    }
}

export default withStyles(cardStyle)(BackgroundPaper);