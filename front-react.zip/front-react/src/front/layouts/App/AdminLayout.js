import React from "react";
import PropTypes from "prop-types";

// creates a beautiful scrollbar
import PerfectScrollbar from "perfect-scrollbar";
import "perfect-scrollbar/css/perfect-scrollbar.css";
import {withStyles} from "material-ui";
import {Header, Sidebar} from "../../components";
import layoutStyle from "../../../variables/styles/admin/layout.jsx";
import {connect} from "react-redux";
import {getSpace} from "../../../app/rdx/actions/spacesActions";
import {translate} from "react-i18next";


class TeacherLayout extends React.Component {
    constructor() {
        super();
        this.state = {mobileOpen:false}
    }
    handleDrawerToggle = () => {
        this.setState({mobileOpen: !this.state.mobileOpen});
    };

    componentDidMount(){
        //this.props.getSpace();
        if (navigator.platform.indexOf('Win') > -1) {
            // eslint-disable-next-line
            const ps = new PerfectScrollbar(this.refs.mainPanel);
        }
    }

    componentDidUpdate() {
        this.refs.mainPanel.scrollTop = 0;
    }

    render() {
        const {classes} = this.props;

        return (
            <div className={classes.wrapper} >
                <Sidebar routes={this.props.routes}
                         switchRoutes={this.props.switchRoutes}
                         logoText={this.props.user.nickname}
                         logo={this.props.user.avatar}
                         handleDrawerToggle={this.handleDrawerToggle}
                         image={this.props.bgMenuImage}
                         open={this.state.mobileOpen}
                         location={this.props.location}
                         color={this.props.color}/>
                <div className={classes.mainPanel} ref="mainPanel">
                    <Header
                        routes={this.props.routes}
                        handleDrawerToggle={this.handleDrawerToggle}
                        location={this.props.location}
                    />
                    <div className={classes.content}>
                        <div className={classes.container}>{this.props.switchRoutes}</div>
                    </div>
                </div>
            </div>
        );
    }

}

TeacherLayout.propTypes = {
    classes: PropTypes.object.isRequired
};

const stateToProps = ({user, bgMenuImage, bgImage, errors, achievement}) => ({
    user,
    bgMenuImage,
    bgImage,
    errors,
    achievement
});
const dispatchToProps = (dispatch) => ({
    getSpace: () => dispatch(getSpace()),

});


const conn = connect(stateToProps, dispatchToProps);

export default withStyles(layoutStyle)(conn(translate("translations")(TeacherLayout)));
