import React from "react";
import {Switch, Redirect} from "react-router-dom";
import PrivateRoute from "../../components/PrivateRoute";
import Achievement from "../../components/Achievement";
import Error from "../../components/Error";
// creates a beautiful scrollbar
import "perfect-scrollbar/css/perfect-scrollbar.css";
import Profile from '../../views/General/Profile';
import {Footer} from "../../components";
import appRoutesAdmin from "../../../routes/app-admin.jsx";
import appRoutesStudent from "../../../routes/app-student.jsx";
import appRoutesTeacher from "../../../routes/app-teacher.jsx";
import {connect} from "react-redux";
import {translate} from "react-i18next";
import LangHelper from "../../../app/core/helpers/LangHelper";
import AuthHelper from "../../../app/core/helpers/AuthHelper";
import TeacherLayout from "./TeacherLayout";
import AdminLayout from "./AdminLayout";
import KidsLayout from "./KidsLayout";


class App extends React.Component {

    constructor() {
        super();
        this.state = {
            mobileOpen: false,
            appRoutes:() => ([]),
            student: false,
            teacher: false,
            admin: false
        };

        this.lang = new LangHelper();
        this.auth = new AuthHelper();
    }

    componentDidMount() {
        this.auth.checkUser().then((user) => {
            let routes = {admin: appRoutesAdmin, teacher: appRoutesTeacher, student: appRoutesStudent};
            this.setState({appRoutes:routes[user.role_key],student:user.role_key === 'student',teacher:user.role_key === 'teacher',admin:user.role_key === 'admin'});
        }).catch(() => {
            this.props.history.push(process.env.PUBLIC_URL + "/");
        });
        document.getElementById('imageBg').style.background          = `url(${process.env.PUBLIC_URL + '/assets/images/login-bg.jpg'})`;
    }



    componentWillReceiveProps(props) {
        if (props.bgImage !== false) {
            document.body.style.background = `url(${props.bgImage}) no-repeat center center fixed`;
            document.body.style.backgroundSize = 'cover';
        }
    }

    render() {
        const { t } = this.props;
        const trns = this.lang.menuTranslate(t);

        const switchRoutes = (
            <Switch>
                <PrivateRoute path={`${process.env.PUBLIC_URL}/perfil`} component={Profile}/>

                {this.state.appRoutes(trns).map((prop, key) => {
                    if (prop.redirect)
                        return <Redirect from={prop.path} to={prop.to} key={key}/>;
                    return <PrivateRoute path={`${process.env.PUBLIC_URL + prop.path}`} component={prop.component}
                                         key={key}/>;
                })}

            </Switch>
        );

        return (
            <div>
                {this.state.student &&
                <KidsLayout routes={this.state.appRoutes(trns)} switchRoutes={switchRoutes}
                            color='blue' location={this.props.location}/>}
                {this.state.teacher &&
                    <TeacherLayout routes={this.state.appRoutes(trns)} switchRoutes={switchRoutes}
                                  color='blue' location={this.props.location}/>
                }

                {this.state.admin &&
                    <AdminLayout routes={this.state.appRoutes(trns)} switchRoutes={switchRoutes}
                                  color='blue' location={this.props.location}/>
                }

                {
                    this.props.errors.type === 'message' ?
                        <Error visible={this.props.errors.error}
                               message={this.props.errors.errors.error}/>
                        : ''
                }

                {
                    this.props.achievement !== false ?
                        <Achievement achievement={this.props.achievement}/>
                        : ''
                }
            </div>


        );
    }
}

const stateToProps = ({user, bgImage, errors, achievement}) => ({
    user,
    bgImage,
    errors,
    achievement
});
const dispatchToProps = null;


const conn = connect(stateToProps, dispatchToProps);

export default conn(translate("translations")(App));
