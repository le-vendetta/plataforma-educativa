import React from "react";
import PropTypes from "prop-types";

// creates a beautiful scrollbar
import "perfect-scrollbar/css/perfect-scrollbar.css";
import {withStyles} from "material-ui";
import {HeaderMenu, Sidebar} from "../../components";
import appStyle from "../../../variables/styles/appStyle.jsx";
import {connect} from "react-redux";
import {getSpace} from "../../../app/rdx/actions/spacesActions";
import {getSessions} from "../../../app/rdx/actions/sessionActions";
import {translate} from "react-i18next";
import {withRouter} from "react-router-dom";
import {Hidden} from "material-ui";
import Toast from "../../../app/core/helpers/Toast";

class KidsLayout extends React.Component {
    constructor() {
        super();
        this.state = {mobileOpen:false}
    }

    handleDrawerToggle = () => {
        this.setState({mobileOpen: !this.state.mobileOpen});
    };

    componentWillMount(){
        this.props.getSessions();
    }

    componentWillReceiveProps(props){
        if(props.sessions !== null && props.sessions.length > 0){
            let session = props.sessions[0];
            let route = `/curso/${session.course_info.slug}/leccion/${session.lesson_info.slug}`;
            if(props.sessions !== this.props.sessions || route !== props.location.pathname){
                if(route !== props.location.pathname){
                    this.props.history.push(process.env.PUBLIC_URL+route);
                    Toast('Hay una clase activa, solo puedes ver esta pagina','warning')
                }
            }
        }
    }

    render() {
        const {classes} = this.props;

        return (
            <div >
                <HeaderMenu
                    routes={this.props.routes}
                    handleDrawerToggle={this.handleDrawerToggle}
                    location={this.props.location}
                    color={'success'}
                />
                <Hidden mdUp>
                <Sidebar routes={this.props.routes}
                         switchRoutes={this.props.switchRoutes}
                         logoText={this.props.user.nickname}
                         logo={this.props.user.avatar}
                         handleDrawerToggle={this.handleDrawerToggle}
                         image={this.props.bgMenuImage}
                         open={this.state.mobileOpen}
                         location={this.props.location}
                         color={this.props.color}/>
                </Hidden>
                <div className={classes.content}>
                    <div className={classes.container}>{this.props.switchRoutes}</div>
                </div>
            </div>
        );
    }

}

KidsLayout.propTypes = {
    classes: PropTypes.object.isRequired
};

const stateToProps = ({user, bgMenuImage, bgImage, errors, achievement,sessions}) => ({
    user,
    bgMenuImage,
    bgImage,
    errors,
    achievement,
    sessions
});
const dispatchToProps = (dispatch) => ({
    getSpace: () => dispatch(getSpace()),
    getSessions: () => dispatch(getSessions()),
});


const conn = connect(stateToProps, dispatchToProps);

export default withStyles(appStyle)(withRouter(conn(translate("translations")(KidsLayout))));
