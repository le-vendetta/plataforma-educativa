import React from "react";
import PropTypes from "prop-types";

// creates a beautiful scrollbar
import PerfectScrollbar from "perfect-scrollbar";
import "perfect-scrollbar/css/perfect-scrollbar.css";
import {withStyles, Typography} from "material-ui";
import {Header, Sidebar} from "../../components";
import appStyle from "../../../variables/styles/teacher/layout.jsx";
import {connect} from "react-redux";
import {getSpace} from "../../../app/rdx/actions/spacesActions";
import {translate} from "react-i18next";


class TeacherLayout extends React.Component {
    constructor() {
        super();
        this.state = {mobileOpen:false}
        document.getElementById('imageBg').style.background  = `url(${process.env.PUBLIC_URL + '/assets/images/bg-teacher.png'}) no-repeat center`;
    }
    handleDrawerToggle = () => {
        this.setState({mobileOpen: !this.state.mobileOpen});
    };

    componentDidMount(){
        //this.props.getSpace();
        if (navigator.platform.indexOf('Win') > -1) {
            // eslint-disable-next-line
            const ps = new PerfectScrollbar(this.refs.mainPanel);
        }
    }

    componentDidUpdate() {
        this.refs.mainPanel.scrollTop = 0;
    }
    replaceAll(target, search, replace) {
        return target.replace(new RegExp(search, 'g'), replace);
    }
    makeBrand() {
        let found = this.props.routes.map((prop, key) => {
            let fullPath = process.env.PUBLIC_URL + prop.path;
            let pathName = this.props.location.pathname.replace(/\/\s*$/, "")
            let location = pathName.split('/').filter(function (e) {
                return e
            });
            let path = fullPath.split('/').filter(function (e) {
                return e
            });
            if (fullPath === pathName) {
                return prop.navbarName;
            } else if (location.length === path.length) {

                if (fullPath.indexOf('/:') > -1) {
                    let matches = 0;
                    let params = 0;
                    let title = '';

                    path.forEach((value, idx) => {
                        if (value.indexOf(':') > -1) {
                            let text = this.replaceAll(location[idx], '-', ' ');
                            text = text.charAt(0).toUpperCase() + text.slice(1);
                            title = text;

                            params++;
                        } else if (value === location[idx]) {
                            matches++;
                        }
                    });

                    if (matches + params === path.length) {
                        return title;
                    }
                }
            }
            return null;
        });
        return found.filter(function (n) {
            return n != null
        })[0];
    }
    render() {
        const {classes} = this.props;

        return (

            <div className={classes.wrapper} >
            <Header
                routes={this.props.routes}
                handleDrawerToggle={this.handleDrawerToggle}
                location={this.props.location}
            />
                <Sidebar routes={this.props.routes}
                         switchRoutes={this.props.switchRoutes}
                         logoText={this.props.user.nickname}
                         logo={this.props.user.avatar}
                         handleDrawerToggle={this.handleDrawerToggle}
                         image={this.props.bgMenuImage}
                         open={this.state.mobileOpen}
                         location={this.props.location}
                         color={this.props.color}/>
                <div className={classes.mainPanel} ref="mainPanel">

                    <div className={classes.content}>
                        <div className={classes.container}>
                        {this.makeBrand() > 0 ? " " :  <h3 className={classes.title}>{this.makeBrand()}</h3>}
                            {this.props.switchRoutes}
                         </div>
                    </div>
                </div>
            </div>
        );
    }

}

TeacherLayout.propTypes = {
    classes: PropTypes.object.isRequired
};

const stateToProps = ({user, bgMenuImage, bgImage, errors, achievement}) => ({
    user,
    bgMenuImage,
    bgImage,
    errors,
    achievement
});
const dispatchToProps = (dispatch) => ({
    getSpace: () => dispatch(getSpace()),

});


const conn = connect(stateToProps, dispatchToProps);

export default withStyles(appStyle)(conn(translate("translations")(TeacherLayout)));
