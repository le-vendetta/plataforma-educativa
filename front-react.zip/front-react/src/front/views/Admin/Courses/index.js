import React from 'react';
import {
    withStyles,
    TableCell,
    Paper,
    IconButton, Tooltip, Button,
} from 'material-ui';
import Edit from '@material-ui/icons/Edit';
import List from '@material-ui/icons/List';
import AddCircle from '@material-ui/icons/AddCircle';
import courseStyle from '../../../../variables/styles/courses.jsx';
import CourseModal from '../../../components/Modals/CourseModal';
import LessonsModal from '../../../components/Modals/LessonsModal';
import NewLessonModal from '../../../components/Modals/NewLessonModal';
import EditLessonModal from '../../../components/Modals/EditLessonModal';
import Loading from "../../../components/Loading";
import SortTable from '../../../components/Tables/SortTable';
import CustomButton from "../../../components/CustomButtons/Button";

import {connect} from "react-redux";
import {getCourses, setCourse, setLesson, setLessons,removeCourses} from "../../../../app/rdx/actions/coursesActions";
import {translate} from "react-i18next";


const columnData = [
    { id: 'id', numeric: true, disablePadding: true, label: '#' },
    { id: 'name', numeric: false, disablePadding: false, label: 'Nombre' },
    { id: 'category_name', numeric: false, disablePadding: false, label: 'Categoria' },
    { id: 'course_type', numeric: false, disablePadding: false, label: 'Tipo' },
    { id: 'total_lessons', numeric: true, disablePadding: false, label: 'Lecciones' },
    { id: 'image', numeric: false, disablePadding: false, label: 'Imagen',sortable:false  },
    { id: 'actions', numeric: false, disablePadding: false, label: 'Acciones',sortable:false },
];

class Courses extends React.Component {
    componentDidMount(){
        this.props.getCourses();
    }
    constructor(props) {
        super(props);
        this.state = {
            selected: [],
            course_modal_open:false,
            lessons_modal_open:false,
            new_lessons_modal_open:false,
            edit_lessons_modal_open:false,
            selected_course:{},
            selected_lesson:0,
        };
    }

    render() {
        const {selected_lesson,selected_course} = this.state;
        const { classes,courses } = this.props;
        return (<div>
            <CustomButton color="primary" onClick={()=>this.setState({course_modal_open:true})}>Agregar curso</CustomButton>
                {courses ? <Paper className={classes.root}>


                    <SortTable enableCheck={true} headerStructure={columnData}
                               items={courses}
                               onDelete={(items) => this.removeItems(items)}
                               id={'id'}
                               rowStructure={(course) => {
                                   return <React.Fragment>
                                       <TableCell component="td" scope="row" padding="none" numeric>
                                           {course.id}
                                       </TableCell>
                                       <TableCell>{course.name}</TableCell>
                                       <TableCell>{course.category_name}</TableCell>
                                       <TableCell>{course.course_type === 'open'?'Abierto':'Clase en vivo'}</TableCell>
                                       <TableCell numeric>{course.total_lessons}</TableCell>
                                       <TableCell><img src={course.image} alt={course.name} style={{width:50}}/></TableCell>
                                       <TableCell>
                                           <Tooltip title="Editar" placement="top">
                                               <IconButton aria-label="Editar" color={'primary'} onClick={(event)=>this.openEditCourse(event,course)}>
                                                   <Edit />
                                               </IconButton>
                                           </Tooltip>

                                           <Tooltip title="Lecciones" placement="top">
                                               <IconButton aria-label="Lecciones" color={'primary'}  onClick={(event)=>this.openLessons(event,course)}>
                                                   <List />
                                               </IconButton>
                                           </Tooltip>

                                           <Tooltip title="Agregar leccion" placement="top">
                                               <IconButton aria-label="Agregar leccion" color={'primary'} onClick={(event)=>this.openNewLesson(event,course)}>
                                                   <AddCircle />
                                               </IconButton>
                                           </Tooltip>

                                       </TableCell>

                                   </React.Fragment>
                               }}
                    />

                    <CourseModal open={this.state.course_modal_open} course={this.state.selected_course}
                                 onClose={()=> this.setState({course_modal_open:false})}
                                 onSubmit={(course)=> this.saveCourse(course)}/>

                    <LessonsModal open={this.state.lessons_modal_open} course={this.state.selected_course}
                                  onClose={()=> this.setState({lessons_modal_open:false})} onEditLesson={(lesson)=>this.onEditLesson(lesson)}/>

                    {selected_course && <NewLessonModal open={this.state.new_lessons_modal_open} course={this.state.selected_course}
                                                        onClose={()=> this.setState({new_lessons_modal_open:false,selected_course:false})}/>}

                    {selected_lesson !== 0 && <EditLessonModal open={this.state.edit_lessons_modal_open} lesson={this.state.selected_lesson}
                                                               onClose={()=> this.setState({edit_lessons_modal_open:false,selected_lesson:0})}/>}
                </Paper>:<Loading/>}
        </div>
        );
    }
    onEditLesson(lesson){
        this.setState({edit_lessons_modal_open:true,selected_lesson:lesson});
    }
    saveCourse(course){
        this.setState({course_modal_open:false,selected_course:{}});
    }

    openLessons(event,course){
        event.preventDefault();
        event.stopPropagation();
        this.setState({selected_course:course,lessons_modal_open:true});
    }
    openNewLesson(event,course){
        event.preventDefault();
        event.stopPropagation();
        this.setState({selected_course:course,new_lessons_modal_open:true});
    }

    openEditCourse(event,course){
        event.preventDefault();
        event.stopPropagation();
        this.setState({selected_course:course,course_modal_open:true});
    }

    removeItems(items){
        let cc = window.confirm('De verdad quieres eliminar estos cursos?');
        if(cc){
            this.props.removeCourses(items);
        }
    }

}

const stateToProps = ({courses}) => ({courses});
const dispatchToProps = (dispatch) => ({//custom props
    getCourses: () => dispatch(getCourses()),
    setCourse: (value) => dispatch(setCourse(value)),
    setLessons: (value) => dispatch(setLessons(value)),
    setLesson: (value) => dispatch(setLesson(value)),
    removeCourses: (value) => dispatch(removeCourses(value)),
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(courseStyle)(conn(translate("translations")(Courses)));