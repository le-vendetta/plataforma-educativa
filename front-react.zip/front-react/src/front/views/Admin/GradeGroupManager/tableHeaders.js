export const gradeGroupsHeader = [
    { id: 'id', numeric: true, disablePadding: false, label: '#' },
    { id: 'grade', numeric: false, disablePadding: false, label: 'Grado' },
    { id: 'group', numeric: false, disablePadding: false, label: 'Grupo' },
    { id: 'category', numeric: false, disablePadding: false, label: 'Categoria' },
    { id: 'actions', numeric: false, disablePadding: false, label: 'Acciones',sortable:false },
];

export const usersHeader = [
    { id: 'id', numeric: true, disablePadding: false, label: '#' },
    { id: 'name', numeric: false, disablePadding: false, label: 'Nombre' },
    { id: 'email', numeric: false, disablePadding: false, label: 'Email' },
    { id: 'grade', numeric: false, disablePadding: false, label: 'Grado' },
    { id: 'group', numeric: false, disablePadding: false, label: 'Grupo' },
    { id: 'actions', numeric: false, disablePadding: false, label: 'Acciones',sortable:false },
];

export const studentsHeaderStructure = [
    { id: 'id', numeric: true, disablePadding: false, label: '#' },
    { id: 'name', numeric: false, disablePadding: false, label: 'Nombre' },
    { id: 'email', numeric: false, disablePadding: false, label: 'Limite de usuarios' },
    { id: 'created_at', numeric: false, disablePadding: false, label: 'Asignado en' },
    { id: 'assigned_by', numeric: false, disablePadding: false, label: 'Asignado por' },
    { id: 'actions', numeric: false, disablePadding: false, label: 'Acciones',sortable:false },
];
