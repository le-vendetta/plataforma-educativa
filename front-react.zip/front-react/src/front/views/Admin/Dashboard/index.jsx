import React from "react";
import {
    withStyles,

} from "material-ui";

import dashboardStyle from "../../../../variables/styles/admin/dashboard";
import 'moment/locale/es';
import {connect} from "react-redux";
import {translate} from "react-i18next";
import {Col, Row} from "react-flexbox-grid";


class Dashboard extends React.Component {
    constructor() {
        super();

        this.state = {

        };
    }

    componentWillUnmount(){
        console.log(':D');
    }


    render() {

        return (
            <div>

                <Row>
                    <Col xs={12} sm={12} md={4}>
                        :D
                    </Col>
                </Row>
            </div>
        );
    }


}


const stateToProps = ({sessions,presentation,advances,comparative, user}) => ({sessions,presentation,advances,comparative, user});
const dispatchToProps = (dispatch) => ({//custom props

});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(dashboardStyle)(conn(translate("translations")(Dashboard)));