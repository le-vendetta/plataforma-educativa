import React, {Component} from "react";
import {Row, Col} from "react-flexbox-grid";
import Card, { CardContent} from "material-ui/Card";
import Button from 'material-ui/Button';
import TextField from 'material-ui/TextField';
import AuthHelper from '../../../../app/core/helpers/AuthHelper';
import Loading from "../../../components/Loading/index";
import {Redirect} from "react-router";
import {Grid} from "react-flexbox-grid";
import {connect} from "react-redux";
import {Typography} from "material-ui";

class Login extends Component {
    constructor() {
        super();
        this.state = {email: 'student@student.com', password: '12345678', validForm: false, isLoggedIn: '',user:{}};

        this.auth = new AuthHelper(this.props);

        document.getElementById('imageBg').style.background  = `url(${process.env.PUBLIC_URL + '/assets/images/login-bg.jpg'}) no-repeat center`;

        this.handleChange = this.handleChange.bind(this);
        this.loginNormal = this.loginNormal.bind(this);
    }

    componentDidMount() {
        this.auth.checkUser().then((user) => {
            this.setState({isLoggedIn: true});
        }).catch(() => {
            this.setState({isLoggedIn: false})
        });
        this.validateForm();
    }

    handleChange(ev) {
        let elm = ev.target;

        if (elm.id === "email") {
            this.setState({email: elm.value});
        }

        if (elm.id === "password") {
            this.setState({password: elm.value});
        }

        this.validateForm();
    }

    loginNormal() {
        this.auth.login(this.state.email, this.state.password).then((data) => {
            console.log('L');
        });
    }

    componentWillReceiveProps(props) {
        if (Object.keys(props.user).length > 0 && !this.state.isLoggedIn) {
            this.setState({isLoggedIn: true,user:props.user});
        }
    }

    render() {
        const {user} = this.props;
        if (this.state.isLoggedIn === false) {
            return <Grid fluid>
                <Row middle="xs" center="xs" style={{height: "100vh"}} className="center">
                    <Col md={4}>
                        <Card className={"login"}>
                            <img className="logo responsive-img" src={process.env.PUBLIC_URL + "/assets/images/login-logo.png"}></img>
                            <CardContent className={'login-content'}>
                                <Typography>
                                    {this.props.errors.error}
                                </Typography>
                                <Col md={12} className="default-margin" style={{padding:"0", margin:"10px 0px"}}>
                                    <TextField placeholder="USUARIO" id="email" fullWidth onChange={(ev) => {
                                        this.handleChange(ev)
                                    }} value={this.state.email}/>
                                </Col>
                                <Col md={12} className="default-margin" style={{padding:"0", margin:"10px 0px"}}>
                                    <TextField placeholder="CONTRASEÑA" id="password" fullWidth onChange={this.handleChange}
                                               value={this.state.password}/>
                                </Col>
                                <Row center="xs" className="default-margin">
                                    <Col md={12} >
                                        <Button className="btn-login" size="small" color="secondary" variant="raised" fullWidth
                                                disabled={!this.state.validForm} onClick={this.loginNormal}>
                                            Inicia la Aventura
                                        </Button>
                                    </Col>
                                    {/*<Col md={12} className="default-margin">
                                        ó
                                    </Col>

                                    <Col md={7} className="default-margin">
                                       <FacebookLogin/>
                                    </Col>
                                    <Col md={7} className="default-margin">
                                        <GoogleLoginButton />
                                    </Col>

                                    <Col md={12} className="default-margin-top">
                                        <Link to={`${process.env.PUBLIC_URL}/registro`}
                                              className="default-link">Registrarse</Link>
                                    </Col>

                                    <Col md={12} className="default-margin-top">
                                        <Link to={`${process.env.PUBLIC_URL}/recuperar-contraseña`}
                                              className="default-link">Olvide mi contraseña</Link>
                                    </Col>
                                      */}

                                </Row>
                            </CardContent>
                        </Card>
                    </Col>
                </Row>
            </Grid>

        } else if (this.state.isLoggedIn === true) {
            if(Object.keys(user).length > 0){
                return user.new_user?<Redirect to={{pathname: process.env.PUBLIC_URL + '/cambiar-contraseña'}}/>:<Redirect to={{pathname: process.env.PUBLIC_URL + '/home'}}/>

            }else{
                return <Loading/>;
            }
        } else {
            return <Loading/>
        }

    }

    validateForm() {
        this.setState({validForm: (this.auth.validateEmail(this.state.email) && this.state.password.trim() !== '')});
    }


}

const stateToProps = ({errors, user}) => ({errors: errors.errors ? errors.errors : {}, user});

const conn = connect(stateToProps, null);

export default conn(Login);
