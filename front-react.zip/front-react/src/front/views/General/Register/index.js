import React, {Component} from 'react';
import AuthHelper from '../../../../app/core/helpers/AuthHelper';
import {Col, Grid, Row} from "react-flexbox-grid";
import {
    Button, Card, CardContent, CardHeader, Divider, FormControl, FormHelperText, Input, InputLabel
} from "material-ui";
import {Link} from "react-router-dom";
import Toast from "../../../../app/core/helpers/Toast";
import {withRouter} from "react-router";
import {connect} from "react-redux";

class Register extends Component {
    constructor() {
        super();

        this.auth = new AuthHelper();
        document.body.style.backgroundImage = `url(${process.env.PUBLIC_URL + '/assets/images/login-bg.jpg'})`;
        this.state = {formValid: false, nickname: '', email: '', password: '', rPassword: ''};
        this.handleChange = this.handleChange.bind(this);
        this.validForm = this.validForm.bind(this);
        this.registerUser = this.registerUser.bind(this);
    }

    componentDidMount() {
        if (Object.keys(this.props.user).length !== 0) {
            Toast("Ya tienes una sesion activa", 'error');
            this.props.history.push('home');
        }
        this.validForm(this.state);
    }

    registerUser() {
        const {nickname, email, password, rPassword} = this.state;

        this.auth.register(nickname, email, password, rPassword).then(() => {
            this.props.history.push('/');
        });
    }

    render() {
        return <Grid fluid>
            <Row middle="xs" center="xs" style={{height: "100vh"}} className="center">
                <Col md={3}>
                    <Card>
                        <CardHeader
                            title="Eldventir"
                            subheader="Registrate"
                        />

                        <CardContent>
                            <Col md={12} className="default-margin">
                                <FormControl fullWidth aria-describedby="nickname-error-text"
                                             error={this.props.errors.nickname ? true : false}>
                                    <InputLabel htmlFor="nickname">Nombre</InputLabel>
                                    <Input id="nickname" value={this.state.nickname} onChange={(ev) => {
                                        this.handleChange(ev)
                                    }}/>
                                    <FormHelperText
                                        id="nickname-error-text">{this.props.errors.nickname}</FormHelperText>
                                </FormControl>
                            </Col>

                            <Col md={12} className="default-margin">
                                <FormControl fullWidth aria-describedby="email-error-text"
                                             error={this.props.errors.email ? true : false}>
                                    <InputLabel htmlFor="email">Email</InputLabel>
                                    <Input id="email" value={this.state.email} onChange={(ev) => {
                                        this.handleChange(ev)
                                    }}/>
                                    <FormHelperText id="email-error-text">{this.props.errors.email}</FormHelperText>
                                </FormControl>
                            </Col>

                            <Col md={12} className="default-margin">
                                <FormControl fullWidth aria-describedby="password-error-text"
                                             error={this.props.errors.password ? true : false}>
                                    <InputLabel htmlFor="password">Password</InputLabel>
                                    <Input id="password" value={this.state.password} onChange={(ev) => {
                                        this.handleChange(ev)
                                    }}/>
                                    <FormHelperText
                                        id="password-error-text">{this.props.errors.password}</FormHelperText>
                                </FormControl>
                            </Col>

                            <Col md={12} className="default-margin">
                                <FormControl fullWidth aria-describedby="rPassword-error-text">
                                    <InputLabel htmlFor="rPassword">Repetir contraseña</InputLabel>
                                    <Input id="rPassword" value={this.state.rPassword} onChange={(ev) => {
                                        this.handleChange(ev)
                                    }}/>
                                </FormControl>
                            </Col>


                            <Row center="xs" className="default-margin">
                                <Col md={12}>
                                    <Divider/>
                                </Col>
                                <Col md={7} className="default-margin">
                                    <Button size="small" color="secondary" variant="raised"
                                            disabled={!this.state.formValid} fullWidth onClick={this.registerUser}>
                                        Registrarse
                                    </Button>
                                </Col>
                                <Col md={12}>
                                    <Link to={`${process.env.PUBLIC_URL}/`} className="default-link">Volver</Link>
                                </Col>
                            </Row>
                        </CardContent>
                    </Card>
                </Col>
            </Row>
        </Grid>;
    }

    handleChange(e) {
        let change = {};
        change[e.target.id] = e.target.value;

        this.setState(change, () => {
            this.validForm(this.state);
        });
    }

    validForm(state) {
        let inputs = ['nickname', 'email', 'password', 'rPassword'];
        let count = 0;

        inputs.forEach((value) => {
            count += state[value].trim().length > 0 ? 1 : 0;
        });


        let equals = state.password === state.rPassword;

        if (count === inputs.length && this.auth.validateEmail(state.email) && equals) {
            this.setState({formValid: true});
        }
    }
}

const stateToProps = ({user, errors}) => ({user, errors: errors.errors ? errors.errors : {}});

const conn = connect(stateToProps, null);

export default withRouter(conn(Register));
