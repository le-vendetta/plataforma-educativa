import React, {Component} from 'react';
import {Col, Grid, Row} from "react-flexbox-grid";
import {
    Button, Card, CardContent, CardHeader, FormControl, FormHelperText, Input, InputLabel
} from "material-ui";
import AuthHelper from '../../../../app/core/helpers/AuthHelper';
import Toast from "../../../../app/core/helpers/Toast";
import {withRouter} from "react-router";
import {connect} from "react-redux";

class PasswordRecover extends Component {
    constructor() {
        super();
        this.state = {email: '', formValid: false};
        document.body.style.backgroundImage = `url(${process.env.PUBLIC_URL + '/assets/images/login-bg.jpg'})`;
        this.sendRecover = this.sendRecover.bind(this);
    }

    componentDidMount() {
        if (Object.keys(this.props.user).length !== 0) {
            Toast("Ya tienes una sesion activa", 'error');
            this.props.history.push('home');
        }

        this.validForm(this.state);
        this.auth = new AuthHelper();
    }

    handleEmail(e) {
        if (e.target.value.trim().length > 0) {
            this.setState({email: e.target.value}, () => {
                this.validForm(this.state);
            });
        }
    }

    validForm(state) {
        if (state.email.trim().length > 0 && this.auth.validateEmail(state.email)) {
            this.setState({formValid: true});
        }
    }

    sendRecover() {
        this.auth.sendRecoverPassMail(this.state.email).then(response => {
            Toast("Te hemos enviado un correo de recuperacion!");
            this.props.history.push('/');
        });
    }

    componentWillReceiveProps(props) {
        if (props.errors.error) {
            Toast(props.errors.error, 'error');
        }
    }

    render() {
        return (
            <Grid fluid>
                <Row middle="xs" center="xs" style={{height: "100vh"}} className="center">
                    <Col md={3}>
                        <Card>

                            <CardHeader
                                title="Eldventir"
                                subheader="Recuperar contraseña"
                            />

                            <CardContent>
                                <Row>
                                    <Col md={12}>
                                        <FormControl fullWidth aria-describedby="email-error-text"
                                                     error={this.props.errors.email ? true : false}>
                                            <InputLabel htmlFor="email">Correo</InputLabel>
                                            <Input id="email" value={this.state.email} onChange={(ev) => {
                                                this.handleEmail(ev)
                                            }}/>
                                            <FormHelperText
                                                id="email-error-text">{this.props.errors.email}</FormHelperText>
                                        </FormControl>
                                    </Col>

                                    <Col md={12} className="big-margin-top">
                                        <Button color="secondary" variant="raised" fullWidth
                                                disabled={!this.state.formValid} onClick={this.sendRecover}>
                                            Enviar correo de recuperacion
                                        </Button>
                                    </Col>
                                </Row>
                            </CardContent>

                        </Card>
                    </Col>
                </Row>
            </Grid>
        );
    }
}

const stateToProps = ({user, errors}) => ({user, errors: errors.errors ? errors.errors : {}});

const conn = connect(stateToProps, null);
export default withRouter(conn(PasswordRecover));
