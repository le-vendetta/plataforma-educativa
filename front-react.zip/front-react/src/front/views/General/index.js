import ChangePassword from "./ChangePassword";
import Login from "./Login";
import Register from "./Register";
import PasswordRecover from "./PasswordRecover";
import NotFound from "./NotFound";

export {
    ChangePassword,
    Login,
    Register,
    PasswordRecover,
    NotFound,
}