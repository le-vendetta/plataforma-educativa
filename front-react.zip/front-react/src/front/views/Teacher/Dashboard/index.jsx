import React from "react";
import {
    withStyles,
    CardContent,
    Typography,
    CardActions,
    Divider,
    List,
    ListItem, ListItemText, ListItemSecondaryAction
} from "material-ui";

import dashboardStyle from "../../../../variables/styles/dashboardStyle";
import Moment from 'moment';
import 'moment/locale/es';
import {connect} from "react-redux";
import {Link} from "react-router-dom";
import {translate} from "react-i18next";
import {Col, Row} from "react-flexbox-grid";
import {getSessions} from "../../../../app/rdx/actions/sessionActions";
import {getPresentation,getAdvances,getComparative} from "../../../../app/rdx/actions/coursesActions";
import Loading from "../../../components/Loading";
import ChartistGraph from "react-chartist";
import NewSessionModal from "../../../components/Modals/NewSessionModal";
import ContinueSessionModal from "../../../components/Modals/ContinueSessionModal";
import {genderChart,comparativeChart} from '../../../../variables/charts';
import Button from "../../../components/CustomButtons/Button";
import BackgroundCard from "../../../components/Cards/BackgroundCard";

Moment.locale('es');
class Dashboard extends React.Component {
    constructor() {
        super();

        this.state = {
            new_session_modal_open:false,
            continue_session_modal_open:false,
        };
    }

    componentDidMount() {
        this.props.getSessions();
        this.props.getPresentation();
        this.props.getAdvances();
        this.props.getComparative();
    }


    render() {
        let {classes,sessions,presentation} = this.props;
        let presentationItem = presentation?presentation[Math.floor(Math.random()*presentation.length)]:null;
        return (
            <div>
                <Row>

                    <Col md={12} >
                        <Row end="xs">
                            <Col md={3}>
                                <Button size="small" color="primary" onClick={()=>this.setState({new_session_modal_open:true})}>Nueva clase</Button>
                            </Col>
                        </Row>
                    </Col>

                    <Col xs={12} sm={12} md={6}>
                        {sessions ? <BackgroundCard >
                            <CardContent >
                                <Typography variant="headline" component="h2">
                                    Programas aplicados
                                </Typography>
                                <Typography color="textSecondary">
                                     {`Del ${Moment(sessions[sessions.length-1]?sessions[sessions.length-1].created_at:new Date()).format('DD [de] MMMM')} al
                                     ${Moment(sessions[0]?sessions[0].created_at: new Date()).format('DD [de] MMMM / YYYY')}`}
                                </Typography>

                                <List >
                                        {sessions.map((session,idx) => {
                                            return  <ListItem divider key={idx} >
                                                <ListItemText primary={session.course_info.name} secondary={`Leccion: ${session.lesson_info.name}`}/>
                                                <ListItemSecondaryAction>
                                                    {`${session.grade_group.grade_name} ${session.grade_group.group_name}`}
                                                </ListItemSecondaryAction>
                                            </ListItem>
                                        })}
                                </List>
                            </CardContent>
                            <CardActions>
                                <Button size="small" color="primary" onClick={()=>this.setState({continue_session_modal_open:true})}>Mis clases</Button>

                            </CardActions>
                        </BackgroundCard> :<Loading/>}
                    </Col>

                    <Col xs={12} sm={12} md={6}>
                        {presentationItem ? <BackgroundCard background={presentationItem.image} className={classes.presentationCard}>
                            <CardContent className={classes.presentationCardContent}>
                                {presentationItem ? <div>
                                    <img src={require('../../../../variables/images/presentation.png')} alt={presentationItem.name}/>

                                    <Typography variant="headline" component="h2" className={classes.presentationCardTitle}>
                                        {presentationItem.name}
                                    </Typography>
                                    <Typography variant="headline" component="h2" className={classes.presentationCardDescription}>
                                        {presentationItem.description}
                                    </Typography>
                                </div>:<Loading/>}

                            </CardContent>
                            <CardActions>
                                {presentationItem && <Button size="small" color="primary" className={classes.whiteText} component={Link}
                                        to={`${process.env.PUBLIC_URL}/curso/${presentationItem.slug}`}>Ver mas</Button>}

                            </CardActions>
                        </BackgroundCard>:<Loading/>}
                    </Col>
                </Row>
                <Divider className={classes.separator}/>
                <Row>
                    <Col xs={12} sm={12} md={4}>
                        <BackgroundCard >

                            <CardContent>
                             <img className={classes.headerImg} src={process.env.PUBLIC_URL + "/assets/images/icons/teacher-ipad.jpg"} />
                               <h4 className={classes.h4}>Notificaciones</h4>
                                <Typography color="textSecondary">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dignissimos eaque esse iusto obcaecati quia?
                                </Typography>
                            </CardContent>
                            <CardActions>
                                <Button size="small" color="primary">Ver mas</Button>
                            </CardActions>
                        </BackgroundCard>
                    </Col>

                    <Col xs={12} sm={12} md={4}>
                        <BackgroundCard>
                            <CardContent>
                            <div className={classes.headerContainer}>
                              <img className={classes.headerContainerImg} src={process.env.PUBLIC_URL + "/assets/images/icons/teacher-ideas.png"} />
                              <div>
                              <h4 className={classes.h4}>Comparativa de uso por habilidad</h4>
                              </div>
                            </div>
                                <div>
                                    {this.props.comparative && <ChartistGraph
                                        className={classes.comparativeChart+' line-chart'}
                                        data={this.getComparativeData()}
                                        type="Line"
                                        options={comparativeChart.options}
                                        listener={comparativeChart.animation}
                                    />}
                                </div>
                            </CardContent>

                        </BackgroundCard>
                    </Col>

                    <Col xs={12} sm={12} md={4}>
                        <BackgroundCard>
                            <CardContent>
                            <div className={classes.headerContainer}>
                              <img className={classes.headerContainerImg} src={process.env.PUBLIC_URL + "/assets/images/icons/teacher-gender.png"} />
                              <div>
                              <h4 className={classes.h4}>Comparativa de uso por genero</h4>
                              </div>
                            </div>
                                <div>
                                    {this.props.advances && <ChartistGraph
                                        className={classes.genderChart}
                                        data={this.getGenderData()}
                                        type="Bar"
                                        options={genderChart.options}
                                        listener={genderChart.animation}
                                    />}
                                </div>
                            </CardContent>
                        </BackgroundCard>

                    </Col>
                </Row>

                <NewSessionModal open={this.state.new_session_modal_open}
                              onClose={()=> this.setState({new_session_modal_open:false})}/>

                <ContinueSessionModal open={this.state.continue_session_modal_open}
                              onClose={()=> this.setState({continue_session_modal_open:false})}/>
            </div>
        );
    }

    getGenderData(){

        let labels  = {};
        let male    = {};
        let female  = {};

        this.props.advances.male.forEach(advance => {
            labels[advance.month] = true;
            male[advance.month] = {meta:`hombres ${advance.total} lecciones vistas`,value:advance.total};
            female[advance.month] = female[advance.month]?female[advance.month]:{meta:'hombres 0 lecciones vistas',value:0};
        });

        this.props.advances.female.forEach(advance => {
            labels[advance.month] = true;
            female[advance.month] = {meta:`mujeres ${advance.total} lecciones vistas`,value:advance.total};
            male[advance.month] = male[advance.month]?male[advance.month]:{meta:'mujeres 0 lecciones vistas',value:0};
        });

        return {
            labels: Object.keys(labels),
            series: [Object.values(male), Object.values(female)]
        };
    }

    getComparativeData(){
        let labels  = {};
        let data    = {};
        let names     = {};
        this.props.comparative.forEach(value=>{
            labels[value.month] = true;
            names[value.name]   = true;
        });

        Object.keys(labels).forEach(month => {
            Object.keys(names).forEach(name => {

                let out = this.props.comparative.filter(val=>{
                    return val.month === month && val.name === name;
                });
                data[name]  =  data[name]?data[name]:[];

                if(out.length>0){
                    data[name].push({meta:name,value:out[0].total});
                }else{
                    data[name].push({meta:name,value:0});
                }
            });
        });

        return {
            labels: Object.keys(labels),
            series: Object.values(data)
        };
    }
}


const stateToProps = ({sessions,presentation,advances,comparative, user}) => ({sessions,presentation,advances,comparative, user});
const dispatchToProps = (dispatch) => ({//custom props
    getSessions: () => dispatch(getSessions()),
    getPresentation: () => dispatch(getPresentation()),
    getAdvances: () => dispatch(getAdvances()),
    getComparative: () => dispatch(getComparative()),
});

const conn = connect(stateToProps, dispatchToProps);


export default withStyles(dashboardStyle)(conn(translate("translations")(Dashboard)));
