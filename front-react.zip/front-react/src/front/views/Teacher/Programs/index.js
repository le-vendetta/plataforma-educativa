import React from "react";
import {
    withStyles,
    Card,
    CardContent,
    Typography,
    CardActions,
    Button,
} from "material-ui";

import coursesStyle from "../../../../variables/styles/teacher/courses";

import {connect} from "react-redux";

import {translate} from "react-i18next";
import {Col, Row} from "react-flexbox-grid";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import {Link} from "react-router-dom";

class Programs extends React.Component {
    constructor() {
        super();

        this.state = {categories:[]};

        this.api    = new ApiHelper();
        this.token  = localStorage.getItem('token');
    }

    componentDidMount() {
        this.getCourses();
    }
    getColorText(value){
       if (value.search("light") < 0) {
         return "whiteColor";
       }
       else return "blueColor";
    }

    render() {
        const {classes} = this.props;
        const {categories} = this.state;
        let  v;
        return (
            <div>
                <Row>
                    {categories && categories.map((category, idx)=>(
                        <Col xs={12} sm={12} md={6} className={classes.cardContainer}>
                            <Card style={{backgroundImage:`url(${category.image})`}} className={classes.presentationCard}>
                                <CardContent className={classes.presentationCardContent}>
                                    <div>
                                        <img src={require('../../../../variables/images/presentation.png')} alt={category.title}/>
                                        <Typography variant="headline" component="h2" className={classes.presentationCardTitle}>

                                            {category.title}
                                        </Typography>
                                        <Typography variant="headline" component="h2" className={classes.presentationCardDescription + " " + this.getColorText(category.image)}>
                                            {category.description}
                                        </Typography>
                                    </div>
                                </CardContent>
                                <CardActions>
                                    <Button size="small" className={classes.btn + " " + this.getColorText(category.image)} component={Link} to={`${process.env.PUBLIC_URL}/programa/${category.slug}`}>Ir al programa</Button>
                                </CardActions>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </div>
        );
    }

    getCourses(){
        this.api.get('course-categories', this.token).then(({data}) => {
            let {categories} = data;
            this.setState({categories})
        });
    }
}

const stateToProps      = null;
const dispatchToProps   = null;

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(coursesStyle)(conn(translate("translations")(Programs)));
