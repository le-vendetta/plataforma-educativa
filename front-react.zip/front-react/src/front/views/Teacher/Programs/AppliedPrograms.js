import React from "react";
import {
    withStyles,
    TableCell, Tooltip, IconButton, Paper
} from "material-ui";

import programsStyle from "../../../../variables/styles/teacher/programs";

import {connect} from "react-redux";

import {translate} from "react-i18next";
import {Col, Row} from "react-flexbox-grid";
import SortTable from '../../../components/Tables/SortTable';
import {HighlightOff} from "material-ui-icons";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";

const columnData = [
    { id: 'id', numeric: true, disablePadding: true, label: '#' },
    { id: 'status', numeric: false, disablePadding: false, label: 'Activa' },
    { id: 'grade_group.grade_name', numeric: false, disablePadding: false, label: 'Grado' },
    { id: 'grade_group.group_name', numeric: false, disablePadding: false, label: 'Grupo' },
    { id: 'course_info.name', numeric: true, disablePadding: false, label: 'Curso' },
    { id: 'lesson_info.name', numeric: false, disablePadding: false, label: 'Leccion'},
    { id: 'actions', numeric: false, disablePadding: false, label: 'Acciones',sortable:false },

];

class AppliedPrograms extends React.Component {
    constructor() {
        super();

        this.state = {
            sessions:[]
        };
    }

    componentDidMount() {
        let api = new ApiHelper();
        let token = localStorage.getItem('token');

        api.get('sessions', token).then(({data}) => {
            let sessions = data.sessions;
            this.setState({sessions})
        });
    }


    render() {
        const {sessions} = this.state;

        return (
            <div>
                <Row>
                    <Col xs={12} sm={12} md={12}>
                        <Paper>
                            <SortTable enableCheck={false} headerStructure={columnData} items={sessions} id={'id'}
                                       rowStructure={(session) => {
                                           return <React.Fragment>
                                               <TableCell component="td" scope="row" padding="none" numeric>
                                                   {session.id}
                                               </TableCell>
                                               <TableCell>{session.status?'Activa':'Terminada'}</TableCell>
                                               <TableCell>{session.grade_group.grade_name}</TableCell>
                                               <TableCell>{session.grade_group.group_name}</TableCell>
                                               <TableCell >{session.course_info.name}</TableCell>
                                               <TableCell >{session.lesson_info.name}</TableCell>
                                               <TableCell>
                                                   {session.status &&
                                                   <Tooltip title="Terminar leccion" placement="top">
                                                       <IconButton aria-label="Terminar. leccion" color={'primary'} onClick={(event)=>{}} >
                                                           <HighlightOff />
                                                       </IconButton>
                                                   </Tooltip>
                                                   }
                                               </TableCell>
                                           </React.Fragment>
                                       }}
                            />
                        </Paper>
                    </Col>
                </Row>
            </div>
        );
    }

}

const stateToProps = null;
const dispatchToProps = null;

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(programsStyle)(conn(translate("translations")(AppliedPrograms)));