import React from "react";
import {
    withStyles,
    Paper,
    Card,
    CardContent,
    CardHeader,
    Typography,
    CardActions,
    Button,
    Divider,
    List,
    ListItem, ListItemText, ListItemSecondaryAction
} from "material-ui";

import courseStyle from "../../../../variables/styles/teacher/course";
import {Link} from "react-router-dom";

import {connect} from "react-redux";
import {getStats} from "../../../../app/rdx/actions";
import {translate} from "react-i18next";
import {Col, Row} from "react-flexbox-grid";

import ApiHelper from "../../../../app/core/helpers/ApiHelper";

class Program extends React.Component {
    constructor() {
        super();

        this.state = {
            category:{}
        };
    }

    componentWillMount() {
        let api = new ApiHelper();
        let token = localStorage.getItem('token');
        api.get('course-category/slug/'+this.props.match.params.slug, token).then(({data}) => {
            let category = data.category;
            this.setState({category})
        });
    }


    render() {
        const {category} = this.state;
        const {classes} = this.props;
        return (
            <div>
                <Row>
                    <Col xs={12} sm={12} md={12}>
                        <Card  className={classes.cardPrograms} >
                        <CardContent className={classes.cardContent}>
                            <Typography variant="title" component="h1" className={classes.programH1}>
                                {category.title}
                            </Typography>
                            <List>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/programs-lessons.png'}/>
                                <ListItemText primary={<Typography className={classes.programH4}>{"lecciones"}</Typography> } />
                              </ListItem>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/program-activities.png'}/>
                                <ListItemText primary={<Typography className={classes.programH4}>{category.total_courses + " actividades"}</Typography> } />
                              </ListItem>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/programs-games.png'}/>
                                <ListItemText primary={<Typography className={classes.programH4}>{category.total_courses + " minijuego"}</Typography> } />
                              </ListItem>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/programs-achievements.png'}/>
                                <ListItemText primary={<Typography className={classes.programH4}>{"logros"}</Typography> } />
                              </ListItem>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/programs-groups.png'}/>
                                <ListItemText primary={<Typography className={classes.programH4}> {category.max_users + " Limite de usuarios"} </Typography> } />
                              </ListItem>
                            </List>
                        </CardContent>
                        </Card>
                    </Col>
                </Row>
                <Row className={classes.separator}>
                    <Col xs={12} sm={12} md={8}>
                        <Card  className={classes.card} >
                        <CardContent className={classes.cardContent}>
                            <Typography variant="title" component="h4" className={classes.h4 +" " + classes.blueColor}>
                                Objetivo
                            </Typography>
                            <Typography variant="title" component="p" className={classes.body}>
                                {category.description}
                            </Typography>

                        </CardContent>
                        </Card>
                    </Col>
                    <Col xs={12} sm={12} md={4}>
                        <Card  className={classes.card} >
                        <CardContent className={classes.cardContent}>
                            <Typography variant="title" component="h4" className={classes.h4 +" " + classes.blueColor}>
                              Recursos disponibles
                            </Typography>
                            <List>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/program-data.png'}  className={classes.ListItemIconProgram} />
                                <ListItemText primary={<a href="https://www.facebook.com" className={classes.small}>Ficha técnica</a> } />
                              </ListItem>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/program-guide.png'}  className={classes.ListItemIconProgram} />
                                <ListItemText primary={<a href="https://www.facebook.com" className={classes.small}>Guía del Programa</a> } />
                              </ListItem>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/program-tutorial.png'}  className={classes.ListItemIconProgram} />
                                <ListItemText primary={<Typography className={classes.small}>Video tutorial</Typography> } />
                              </ListItem>
                              <ListItem className="ListItemTextTeacher">
                                <img src={process.env.PUBLIC_URL + '/assets/images/icons/program-metrics.png'}  className={classes.ListItemIconProgram} />
                                <ListItemText primary={<Typography className={classes.small}>Métricas de uso</Typography> } />
                              </ListItem>
                            </List>

                        </CardContent>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }

}

const stateToProps = ({stats, user}) => ({stats, user});
const dispatchToProps = (dispatch) => ({//custom props
    getStats: () => dispatch(getStats())
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(courseStyle)(conn(translate("translations")(Program)));
