import React from 'react';
import {
    withStyles,
    TableCell,
    Paper,
    Button,
    Tooltip, Icon,
} from 'material-ui';
import Delete from '@material-ui/icons/Delete';
import groupManageStyle from '../../../../variables/styles/teacher/groupManage.jsx';

import {connect} from "react-redux";
import {gradeGroupsHeader,usersHeader,studentsHeaderStructure} from "./tableHeaders";
import {translate} from "react-i18next";
import Toast from "../../../../app/core/helpers/Toast";
import ApiHelper from "../../../../app/core/helpers/ApiHelper";
import {Col, Row} from "react-flexbox-grid";
import {getUsers,setUsers} from "../../../../app/rdx/actions/usersActions";
import {getGradeGroups,setGradeGroups} from "../../../../app/rdx/actions/gradeGroupsActions";
import {EditStudent,AddStudents,
    Loading, SortTable,Button as CustomButton} from "../../../components";

class GradeGroupManager extends React.Component {
    constructor(){
        super();
        this.state = {categories:[],users:[],students:[],grade_group:false,open_modal_students:false,
            open_modal_grade_group:false,
            current_grade_group:{},
            grades_labels:[],
            groups_labels:[],
            open_modal_edit_student : false,
            current_user : {}
        };

        this.api    = new ApiHelper();
        this.token  = localStorage.getItem('token');
    }

    componentDidMount(){
        this.getCategories();
        this.props.getGradeGroups();
        this.props.getUsers();
    }

    render() {
        const {open_modal_students,open_modal_edit_student,
            current_user} = this.state;
        const {grade_groups} = this.props;
        return (
            <Row>
                <Col md={12}>
                    <Row end="xs">
                        <CustomButton color="primary" onClick={()=>this.setState({open_modal_students:true})}>Agregar alumnos</CustomButton>
                    </Row>
                </Col>

                <Col md={6}>
                    {this.renderGradeGroups()}
                </Col>
                <Col md={6}>
                    {this.renderUsers()}
                </Col>
                <Col md={6}>
                </Col>
                <Col md={12}>
                    {this.renderUsersGG()}
                </Col>
                {grade_groups && <AddStudents open={open_modal_students} onClose={()=>this.setState({open_modal_students:false})} gradeGroups={grade_groups}/>}
                <EditStudent open={open_modal_edit_student} onClose={(user)=>this.updateUser(user)} user={current_user}/>
            </Row>

        );
    }

    renderUsersGG(){
        let {students} = this.state;
        const {classes}     = this.props;

        return students.length > 0 && <Paper className={classes.cardContainer}>
            <SortTable enableCheck={false} headerStructure={studentsHeaderStructure} items={students} id={'id'}
                       rowStructure={(user) => {
                           return <React.Fragment >
                               <TableCell component="td" scope="row" padding="none" numeric style={{padding: '4px 30px 4px 24px'}}>
                                   {user.id}
                               </TableCell>
                               <TableCell>{user.name}</TableCell>
                               <TableCell>{user.email}</TableCell>
                               <TableCell>
                                   {user.created_at}
                               </TableCell>
                               <TableCell>
                                   {user.assigned_by}
                               </TableCell>
                               <TableCell>
                                   <Tooltip title="Quitar del grupo">
                                       <Button onClick={(e)=>this.removeFromGrade(e,user.id,user.grade_group)}>
                                           <Delete/>
                                       </Button>
                                   </Tooltip>
                               </TableCell>
                           </React.Fragment>
                       }}
            />

        </Paper>;
    }

    renderGradeGroups(){
        const {categories} = this.state;
        const {classes,grade_groups}     = this.props;

        return grade_groups ?
            <Paper className={classes.cardContainer}>
                <SortTable enableCheck={false} headerStructure={gradeGroupsHeader} items={grade_groups} id={'id'} onRowClick={idx => this.getGradeStudents(idx)}
                           rowStructure={(gradeGroup) => {
                               return <React.Fragment >
                                   <TableCell component="td" scope="row" padding="none" numeric style={{padding: '4px 10px 4px 24px'}}>
                                       {gradeGroup.id}
                                   </TableCell>
                                   <TableCell style={{padding: '4px 10px 4px 24px'}}>{gradeGroup.grade_name}</TableCell>
                                   <TableCell  style={{padding: '4px 10px 4px 24px'}}>{gradeGroup.group_name}</TableCell>
                                   <TableCell>
                                       {categories.filter(c=>(c.id === gradeGroup.category_id))[0] && categories.filter(c=>(c.id === gradeGroup.category_id))[0].title}
                                   </TableCell>
                                   <TableCell >
                                       <div style={{display:'flex'}}>
                                           {!gradeGroup.deleted_at && <Tooltip title="Suelta aqui al alumno que hayas seleccionado">
                                               <div onDrop={(e) => this.dropUser(e,gradeGroup.id)} onDragOver={e=>e.preventDefault()} className={[classes.droppable,classes.flex10].join(' ')}>
                                                   Suelta aqui
                                               </div>
                                           </Tooltip>}
                                       </div>

                                   </TableCell>
                               </React.Fragment>
                           }}
                />

            </Paper> :<Loading/>
    }

    renderUsers(){

        const {classes,users,grade_groups}     = this.props;
        return users ?
            <Paper className={classes.cardContainer}>

                <SortTable enableCheck={false} headerStructure={usersHeader} items={users} id={'id'}
                           rowStructure={(user) => {
                               let user_grade   = user.grade_group?user.grade_group.split(','):[];
                               let gradeGroup   =  user_grade[0]? grade_groups.filter(c=>(c.id === parseInt(user_grade[0])))[0]:{};

                               return <React.Fragment >
                                   <TableCell component="td" scope="row" numeric style={{padding: '4px 30px 4px 24px'}}>
                                       <Tooltip title="Arrastra para agregar o eliminar de un grupo">
                                           <div draggable={true} onDragStart={(e)=>this.dragUser(e,user.id)} className={classes.draggable}>
                                               {user.id}
                                           </div>
                                       </Tooltip>
                                   </TableCell >
                                   <TableCell style={{padding: '4px 2% 4px 24px'}}>{user.name}</TableCell>
                                   <TableCell style={{padding: '4px 2% 4px 24px'}}>{user.email}</TableCell>
                                   <TableCell style={{padding: '4px 2% 4px 24px'}}>{gradeGroup && gradeGroup.grade_name}</TableCell>
                                   <TableCell style={{padding: '4px 2% 4px 24px'}}>{gradeGroup && gradeGroup.group_name}</TableCell>
                                   <TableCell style={{padding: '4px 2% 4px 24px'}}>
                                       <div style={{display:'flex'}}>
                                       {!user.deleted_at && <Tooltip title="Desactivar"><Button onClick={()=>this.changeStatus(user.id)} style={{padding:'0 5px',minWidth:10}}><Icon>delete</Icon></Button></Tooltip>}
                                       {!user.deleted_at && <Tooltip title="Editar"><Button onClick={()=>this.editUser(user)} style={{padding:'0 5px',minWidth:10}}><Icon>edit</Icon></Button></Tooltip>}
                                       {user.deleted_at && <Tooltip title="Activar"><Button onClick={()=>this.changeStatus(user.id)} style={{padding:'0 5px',minWidth:10}}><Icon>autorenew</Icon></Button></Tooltip>}
                                       </div>
                                   </TableCell>
                               </React.Fragment>
                           }}
                />

            </Paper> :<Loading/>
    }

    dragUser(e,id){
        e.dataTransfer.setData("user", id);
    }

    dropUser(e,grade_group){
        var user = e.dataTransfer.getData("user");
        this.api.put('user/grade-group',{user,grade_group},this.token).then(({data}) => {
            if(!data.spaces){
                Toast('Ya se alcanzo el numero maximo de usuarios para esta habilidad','error');
            }else{
                let message = data.new?'Alumno asignado al grupo correctamente':'Alumno eliminado del grupo correctamente';
                Toast(message,data.new?'success':'warning');

                let {users} = this.props;
                let idx = users.findIndex(val => (val.id === parseInt(user)));

                if(data.new){
                    users[idx].grade_group = ""+grade_group;
                }else{
                    let grades = users[idx].grade_group.split(',');

                    users[idx].grade_group = this.cleanGrades(grades,grade_group);
                }

                this.props.setUsers(JSON.parse(JSON.stringify(users)));

                if(grade_group === this.state.grade_group){
                    this.getGradeStudents(grade_group);
                }
            }

        });
    }

    editUser(user){
        this.setState({open_modal_edit_student:true,current_user:user});
    }

    updateUser(user){
        let {users} = this.props;
        let idx = users.findIndex(val => (val.id === parseInt(user.id)));
        if(idx != null){
            users[idx] = user;
            this.props.setUsers(JSON.parse(JSON.stringify(users)));
        }


        this.setState({open_modal_edit_student:false})
    }

    changeStatus(user_id){
        this.api.put('user/'+user_id+'/status',{},this.token).then(({data}) => {
            let user = data.user;
            let {users} = this.props;
            let idx = users.findIndex(val => (val.id === parseInt(user_id)));
            users[idx]['deleted_at'] = data.user.deleted_at;

            this.props.setUsers(JSON.parse(JSON.stringify(users)));
        });
    }

    cleanGrades(grades,find){

        let index = grades.indexOf(''+find);

        if (index > -1) {
            grades.splice(index, 1);
        }

        return grades.join(',');
    }

    removeFromGrade(e,user,grade_group){
        e.preventDefault();
        let {users} = this.props;

        this.api.delete('user/grade-group/d',{user,grade_group},this.token).then(({data}) => {
            this.getGradeStudents(grade_group);

            let idx = users.findIndex(val => (val.id === parseInt(user)));
            let grades = users[idx].grade_group.split(',');


            users[idx].grade_group = this.cleanGrades(grades,grade_group);

            this.props.setUsers(JSON.parse(JSON.stringify(users)));
        });
    }

    getGradeStudents(grade_group){
        this.api.get('grade-group/'+grade_group+'/students',this.token).then(({data}) => {
            let {students} = data;
            this.setState({students,grade_group});
        });
    }

    getCategories(){
        this.api.get('course-categories/',this.token).then(({data}) => {
            let {categories} = data;
            this.setState({categories});
        });
    }

}

const stateToProps = ({users,grade_groups}) => ({users,grade_groups});
const dispatchToProps = (dispatch) => ({//custom props
    getUsers: () => dispatch(getUsers()),
    setUsers: (data) => dispatch(setUsers(data)),
    getGradeGroups: ()=>dispatch(getGradeGroups()),
    setGradeGroups: (data)=>dispatch(setGradeGroups(data)),
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(groupManageStyle)(conn(translate("translations")(GradeGroupManager)));
