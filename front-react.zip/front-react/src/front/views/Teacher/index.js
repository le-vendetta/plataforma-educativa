import Dashboard from "./Dashboard";
import GradeGroupManager from "./GradeGroupManager";
import Programs from "./Programs";
import Program from "./Programs/Program";
import AppliedPrograms from "./Programs/AppliedPrograms";
import Course from "./Course";
import Session from "./Session";
import Settings from "./Settings";

export {
    Dashboard,
    GradeGroupManager,
    Programs,
    Program,
    AppliedPrograms,
    Course,
    Session,
    Settings,
}