import React, {Component} from 'react';
import Loading from "./../../../components/Loading";
import Lessons from "./../../../components/Lessons";
import {Col, Row} from "react-flexbox-grid";
import {connect} from "react-redux";
import {getCourse, setLessons} from "../../../../app/rdx/actions/coursesActions";

class Course extends Component {

    componentDidMount() {
        this.props.getCourse(this.props.match.params.slug);
        this.props.setLessons(false);
    }

    render() {
        let course = this.props.course;

        return (course ? <Row>
                <Col md={12}>
                  <div className="lessons-content">
                    <p>{course.name}</p>
                    <div>
                        <Lessons course={course}/>
                    </div>
                  </div>
                </Col>
            </Row> : <Loading/>
        );
    }
}

const stateToProps = ({course}) => ({course});
const dispatchToProps = (dispatch) => ({
    getCourse: (slug) => dispatch(getCourse(slug)),
    setLessons: (value) => dispatch(setLessons(value))
});

const conn = connect(stateToProps, dispatchToProps);

export default conn(Course);
