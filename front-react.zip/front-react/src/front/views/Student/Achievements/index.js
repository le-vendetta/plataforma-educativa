import React, {Component} from 'react';
import Loading from "../../../components/Loading";
import {Col, Row} from "react-flexbox-grid";
import {Grow, Typography, withStyles} from "material-ui";
import {connect} from "react-redux";
import {getCourses} from "../../../../app/rdx/actions/coursesActions";

import courseStyle from '../../../../variables/styles/achievement.jsx';

class Achievements extends Component {
  constructor() {
      super();
      this.getCourses = this.getCourses.bind(this);
  }
    componentDidMount() {
        this.props.getCourses();
        document.getElementById('imageBg').style.opacity  = `1`;
      document.getElementById('imageBg').style.background  = `url(${process.env.PUBLIC_URL + '/assets/images/bricks.jpg'}) no-repeat center`;
    }
    getE(a,b){
        const {classes} = this.props;
      let list = [];

      for (let i = 1; i <= a; i++) {

        if (i<=b) {
          list.push(<i key={"imgStarActive"+i} className={classes.imgStarActive + " material-icons"}>star</i>);
        }
        else{
          list.push(<i key={"imgStarInactive"+i} className={classes.imgStarInactive + " material-icons"}>star_border</i>);
        }

      }
      return list;
    }

    getCourses() {
        let courses = [];
        const {classes} = this.props;
        this.props.courses.forEach((achievement, idx) => {
            courses.push(
                <Col lg={4} md={6} xs={12} sm={12} key={idx}>

                    <Grow in={true} style={{transformOrigin: '0 0 0'}}
                          {...({timeout: 1000 + (idx * 200)})}>

                          <div className={classes.cardContent + " achievement-card"}>
                          {achievement.advance === achievement.lessons ?
                              <img className={classes.imgCard} src={process.env.PUBLIC_URL + '/assets/images/student-star.png'} alt=""/>
                           :
                             <img className={classes.imgCard} src={process.env.PUBLIC_URL + '/assets/images/student-siluet.png'} alt=""/>
                          }
                          <div className={classes.imgStar}>  {this.getE(achievement.lessons, achievement.advance)}</div>

                          <Typography variant="title" className={classes.name}>
                              {achievement.name}
                          </Typography>
                          </div>
                    </Grow>
                </Col>
            );
        });

        return courses;

    }

    render() {
      const {classes} = this.props;
        return (<Row>
          <Col xs={12}>
            <Typography variant="title" className={classes.title}>
              Mis Logros
            </Typography>
            </Col>
            {this.props.courses ? this.getCourses() : <Loading/>}
        </Row>);
    }
}

const stateToProps = ({courses}) => ({courses});
const dispatchToProps = (dispatch) => ({//custom props
    getCourses: () => dispatch(getCourses())
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(courseStyle)(conn(Achievements));
