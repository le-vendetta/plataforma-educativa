import React from "react";
import PropTypes from "prop-types";
// react plugin for creating charts

import {withStyles} from "material-ui";


import dashboardStyle from "../../../../variables/styles/dashboardStyle";
import {connect} from "react-redux";
import {getStats} from "../../../../app/rdx/actions";
import {translate} from "react-i18next";
import {Col, Row} from "react-flexbox-grid";

class Dashboard extends React.Component {
    constructor() {
        super();
        this.state = {
            week_advance: {labels: ['Sin datos'], series: [[0]]},
            months_advance: {labels: ['Sin datos'], series: [[0]]},
            total_week: 0,
            total_month: 0
        };
        document.getElementById('imageBg').style.opacity  = `0.4`;
        document.getElementById('imageBg').style.background  = `url(${process.env.PUBLIC_URL + '/assets/images/login-bg.jpg'}) no-repeat center`;
    }

    componentDidMount() {
        this.props.getStats();
    }


    componentWillReceiveProps(props) {
        /* if(props.stats && props.stats.months_advance){
               this.setStatsMonths(props);
         }

         if(props.stats && props.stats.week_advance){
             this.setStatsWeek(props);
         }*/
    }

    render() {
        const {stats} = this.props;
        const {classes} = this.props;
        return (
            <Row>
                <Col md={12}>
                        <Row>
                            <Col md={3} sm={12}>
                                <Row center='xs' middle="xs">
                                  <img className={classes.characterPosition} src={process.env.PUBLIC_URL + '/assets/images/student-character.png'} alt=""/>
                                  <img className={classes.paperPosition} src={process.env.PUBLIC_URL + '/assets/images/student-paper.png'} alt=""/>
                                </Row>
                            </Col>
                            <Col md={9} sm={12} className={classes.textPosition}>
                                <Col xs={12}>
                                    <Row center="xs">
                                        <Col xs={10} >
                                            <h1 className={classes.h1}>BIENVENIDO A ELDVENTIR</h1>
                                            <p className={classes.p}>Esperamos que disfrutes la aventura que aquí encontrarás.</p>
                                            <p className={classes.p}>Recuerda que aquí puedes ver tus logros y el avance de cada lección. </p>
                                            <p className={classes.p}>{/*En cualquier momento puedes mandar un mensaje a tu profesor a través del chat.*/}</p>                                
                                        </Col>
                                    </Row>
                                </Col>
                                <Col xs={12}>
                                    <Row center="xs">
                                        <Col xs={10} >
                                            <Row>
                                            <Col  xs={6} style={{textAlign:'center'}}>
                                              <a href={process.env.PUBLIC_URL + '/cursos'}>
                                                <div className={classes.detailCourses}>
                                                  <img className={classes.imgDetail} src={process.env.PUBLIC_URL + '/assets/images/student-trophy.png'} alt=""/>
                                                  <p className={classes.txtDetail}>Avance de mis cursos</p>
                                                  <h2 className={classes.advDetail}>{stats.advance_percent||0}%</h2>
                                                  <p className={classes.linkDetail}>Ver detalle</p>
                                                </div>
                                              </a>
                                            </Col>
                                              <Col  xs={6} style={{textAlign:'center'}}>
                                              <a href={process.env.PUBLIC_URL + '/logros'}>
                                                <div className={classes.detailGoal}>
                                                  <img className={classes.imgDetail} src={process.env.PUBLIC_URL + '/assets/images/student-star.png'} alt=""/>
                                                  <p className={classes.txtDetail}>Mis Logros</p>
                                                  <h2 className={classes.advDetail}>{stats.total_achievements || 0}</h2>
                                                  <p className={classes.linkDetail}>Ver detalle</p>
                                                </div>
                                              </a>
                                              </Col>
                                            </Row>
                                        </Col>
                                    </Row>
                                </Col>
                            </Col>
                        </Row>
                </Col>

            </Row>
        );
    }

}

Dashboard.propTypes = {
    classes: PropTypes.object.isRequired
};

const stateToProps = ({stats, user}) => ({stats, user});
const dispatchToProps = (dispatch) => ({//custom props
    getStats: () => dispatch(getStats())
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(dashboardStyle)(conn(translate("translations")(Dashboard)));
