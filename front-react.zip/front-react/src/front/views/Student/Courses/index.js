import React, {Component} from 'react';
import {Col, Row} from "react-flexbox-grid";
import {
    Tooltip,
    Typography, withStyles
} from "material-ui";
import courseStyle from '../../../../variables/styles/courses.jsx';

import Loading from "../../../components/Loading/index";
import {Link} from "react-router-dom";
import Grow from 'material-ui/transitions/Grow';
import {connect} from "react-redux";
import {getCourses, setCourse, setLesson, setLessons} from "../../../../app/rdx/actions/coursesActions";
import {translate} from "react-i18next";
import { Progress } from 'react-sweet-progress';
import "react-sweet-progress/lib/style.css";

class Courses extends Component {
    constructor() {
        super();
        this.getCourses = this.getCourses.bind(this);
          document.getElementById('imageBg').style.opacity  = `1`;
          document.getElementById('imageBg').style.background  = `url(${process.env.PUBLIC_URL + '/assets/images/bricks.jpg'}) no-repeat center`;
    }

    componentDidMount() {
        this.props.getCourses();
        this.props.setCourse(false);
        this.props.setLessons(false);
        this.props.setLesson(false);
    }

    getCourses() {
        let courses = [];
        const {classes, t} = this.props;

        this.props.courses.forEach((course, idx) => {
            let percent = Math.round((parseInt(course.advance, 10) / parseInt(course.lessons, 10)) * 100);
            courses.push(
              <Col lg={4} md={6} xs={12} key={idx} sm={12} >

                        <Link to={!course.locked ? {
                                  pathname: `${process.env.PUBLIC_URL}/curso/${course.slug}`,
                                  params: course
                                } : {
                                  pathname: `${process.env.PUBLIC_URL}/cursos`,
                                }}
                         disabled={course.locked ? true : false}
                         className={course.locked ? classes.buttonDisabled : classes.button}
                         >
                         <Grow in={true} style={{transformOrigin: '0 0 0'}}
                               {...({timeout: 1000 + (idx * 200)})}>
                        <div className={classes.cardContent + " achievement-card"}>

                        <img className={classes.imgCard} src={process.env.PUBLIC_URL + "/assets/images/student-trophy.png"} alt=""/>
                        {course.course_type === 'open' &&
                        <Tooltip title={t('open_course') + "!!"} placement="top"
                                 classes={{tooltip: classes.tooltip}}>
                            <img className={classes.imgCard} src={process.env.PUBLIC_URL + "/assets/images/student-trophy.png"} alt=""/>
                        </Tooltip>}
                        <Typography variant="title" className={classes.name}>
                            {course.name}
                        </Typography>
                        <Typography variant="body2" className={classes.description}>
                            {course.advance}/{course.lessons} Lecciones completadas
                        </Typography>
                        <Typography variant="body2" className={classes.description}>
                            {course.advance} Logros Obtenidos
                        </Typography>
                        <div className={classes.progressContainer}>
                            {percent>=0 &&
                            <Progress width={100}
                                      style={{}}
                                      strokeWidth={1}
                                      percent={percent}
                                      status={percent === 100 ?"success":"active"}
                                      symbolClassName={'progressText'}
                                      theme={{
                                           active: {
                                            symbol: ' ',
                                             color: '#FFFDEE',
                                           },
                                           success: {
                                            symbol: ' ',
                                             color: '#FFFDEE',
                                           },
                                           default: {
                                              symbol: ' ',
                                            }
                                         }}
                            />}
                          <Typography variant="body1" className={classes.percent}>
                            {percent} % completado
                          </Typography>
                        </div>
                        </div>
                        </Grow>
                        </Link>
                    </Col>

            );
        });

        return courses;
    }

    render() {
        const {classes, t} = this.props;
        return (


            this.props.courses ?
                <Row>
                <Col xs={12}>
                  <Typography variant="title" className={classes.title}>
                    Mi avance
                  </Typography>
                  </Col>
                    {this.getCourses()}
                </Row> : <Loading/>
        );
    }
}

const stateToProps = ({courses}) => ({courses});
const dispatchToProps = (dispatch) => ({//custom props
    getCourses: () => dispatch(getCourses()),
    setCourse: (value) => dispatch(setCourse(value)),
    setLessons: (value) => dispatch(setLessons(value)),
    setLesson: (value) => dispatch(setLesson(value)),
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(courseStyle)(conn(translate("translations")(Courses)));
