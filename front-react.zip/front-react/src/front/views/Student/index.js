import Dashboard from "./Dashboard";
import Courses from "./Courses";
import Achievements from "./Achievements";
import Settings from "./Settings";
import Lesson from "./Lesson";
import Course from "./Course";


export {
    Dashboard,
    Courses,
    Achievements,
    Settings,
    Lesson,
    Course,
}