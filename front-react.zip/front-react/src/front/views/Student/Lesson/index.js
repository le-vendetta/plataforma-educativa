import React, {Component} from 'react';
import Loading from "./../../../components/Loading";
import {Col, Row} from "react-flexbox-grid";
import {Button, Divider,withStyles} from "material-ui";
import {connect} from "react-redux";
import {getLesson, viewLesson,getCourse} from "../../../../app/rdx/actions/coursesActions";
import {Slider,BackgroundPaper} from './../../../components';
import courseStyle from "../../../../variables/styles/courses";
import Toast from "../../../../app/core/helpers/Toast";
let check = false;
class Lesson extends Component {

    constructor() {
        super();
        this.viewLesson = this.viewLesson.bind(this);
        this.state = {socket_checked:false,session:{information:{slider:0}}};
        document.getElementById('imageBg').style.opacity  = `1`;
        document.getElementById('imageBg').style.background  = `url(${process.env.PUBLIC_URL + '/assets/images/bricks.jpg'}) no-repeat center`;
    }

    componentDidMount() {
        this.props.getLesson(this.props.match.params.course, this.props.match.params.lesson);
    }

    componentWillReceiveProps(props){
        if(props.sessions && props.sessions.length > 0 && !this.state.socket_checked && props.lesson.type_slug === 'sliders'){
            this.setState({session:props.sessions[0]},()=>{
                this.check_socket();
            });
        }
        if(props.lesson && !props.course && !check){
            this.props.getCourse(this.props.match.params.course);
            check = true;
        }
    }

    viewLesson() {
        this.props.viewLesson(this.props.lesson.id);
    }

    render() {
        let {session}        = this.state;
        let {lesson,classes} = this.props;
        return (!lesson ? <Loading/> :
                <Row>

                <Col md={12}>
                    <div className="paper-main">
                        <div  className="paper-content">
                            {lesson.type_slug === 'game' && <iframe src={lesson.content} frameBorder="0" className="gameFrame" title={lesson.name}>Game content</iframe> }
                            {lesson.type_slug === 'sliders' && <Slider onEnd={()=>this.viewLesson()} selected={session.information.slider} onChange={(idx) => this.updateStep(idx)}/> }
                            {lesson.type_slug === 'text' && <div>{lesson.content}</div>}
                        </div>
                        <Col md={12} className="paper-actions">
                            <Row end="xs" middle="xs">
                                <Col md={4} className="no-padding">
                                    {!lesson.viewed ? (lesson.type_slug !== 'sliders' && <Button className={classes.button} onClick={this.viewLesson}>Marcar como
                                        visto</Button> ): ''}
                                </Col>
                            </Row>

                        </Col>
                    </div>
                </Col>
            </Row>);
    }

    updateStep(idx){
        let {session} = this.state;
        session.information.slider = idx;
        this.setState({session:JSON.parse(JSON.stringify(session))});
    }

    check_socket(){
        let {session,socket_checked} = this.state;
        if(!socket_checked){
            this.setState({socket_checked:true},()=>{
                if(window.io){
                    this.socket = window.io.connect('https://brodcast.eldventir.com:3001');

                    this.socket.emit('subscribe', 'session-'+session.grade_group_id+'-sliders');

                    this.socket.on('change_page', (data) => {

                        session.information.slider = data.page;

                        this.setState({session:JSON.parse(JSON.stringify(session))});

                        Toast("El profesor cambio de pagina")
                    });
                }

            })



        }

    }
}

const stateToProps = ({lesson,course,sessions}) => ({lesson,course,sessions});
const dispatchToProps = (dispatch) => ({
    getLesson: (course, lesson) => dispatch(getLesson(course, lesson)),
    viewLesson: (lesson) => dispatch(viewLesson(lesson)),
    getCourse: (lesson) => dispatch(getCourse(lesson)),
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(courseStyle)(conn(Lesson));
