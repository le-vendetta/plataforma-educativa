// ##############################
// // // Tasks styles
// #############################
import {whiteColor} from '../styles';

const achivementStyle = {
    cardContent:{
        backgroundImage:'url(assets/images/achivement-card.png)',
        backgroundRepeat:"no-repeat",
        backgroundSize:"cover",
        width: "51%",
        padding:"7px 35px 63px 35px",
        minWidth: "171px",
        minHeight: "82px",
        maxWidth: "171px",
        maxHeight: "82px",
        position:"relative",
        textAlign:'center',
        left: "50%",
        marginLeft: "-35%",
        '@media (max-width: 320px)': {
          left: "0%",
          marginLeft: "0%",
        },
    },
    imgCard:{
      width:"63%",
      display:"block",
      marginLeft:"19%",
      marginTop: "-10px",
    },
    name:{
      color:whiteColor,
      fontFamily:'"Montserrat", san-serif',
      textTransform:'uppercase',
      fontSize:"10pt",
      marginTop:"-1px",
    },
    imgStar:{
      marginTop: "-10px",
    },
    imgStarActive:{
      color:"#F0C842",
    },
    imgStarInactive:{
      color:"#fffbf52b",
    },
    title:{
      color:whiteColor,
      fontFamily:'"Montserrat", san-serif',
      textTransform:'uppercase',
      fontSize:"26pt",
      fontWeight:700,
      margin:'32px 47px',
      '@media (max-width: 320px)': {
        margin: "32px 0px",
      },
    }
};
export default achivementStyle;
