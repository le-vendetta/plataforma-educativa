const cardStyle = {
        cardWitBackground:{
            backgroundSize: '100% 100%'
        },
};

export default cardStyle;
