// ##############################
// // // Tasks styles
// #############################
import {button, whiteColor} from '../styles';

const courseStyle = {

    tooltip: {
        padding: "10px 15px",
        minWidth: "130px",
        color: "#555555",
        lineHeight: "1.7em",
        background: "#FFFFFF",
        border: "none",
        borderRadius: "3px",
        boxShadow:
            "0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12), 0 5px 5px -3px rgba(0, 0, 0, 0.2)",
        maxWidth: "200px",
        textAlign: "center",
        fontFamily: '"Helvetica Neue",Helvetica,Arial,sans-serif',
        fontSize: "12px",
        fontStyle: "normal",
        fontWeight: "400",
        textShadow: "none",
        textTransform: "none",
        letterSpacing: "normal",
        wordBreak: "normal",
        wordSpacing: "normal",
        wordWrap: "normal",
        whiteSpace: "normal",
        lineBreak: "auto"
    },
    button:{
        ...button
    },
    buttonDisabled:{
      cursor:"not-allowed"
    },

    progressContainer:{
        position:'absolute',
        width:'88%',
    },
    courseContent:{
        paddingTop:50,
    },
    cardContent:{
        backgroundImage:'url(assets/images/student-card.png)',
        backgroundRepeat:"no-repeat",
        backgroundSize:"cover",
        width: "51%",
        padding:"28px 35px 42px 35px",
        minWidth: "171px",
        minHeight: "82px",
        maxWidth: "171px",
        maxHeight: "82px",
        position:"relative",
        textAlign:'justify',
        left: "50%",
        marginLeft: "-35%",
        '@media (max-width: 320px)': {
          left: "0%",
          marginLeft: "0%",
        },

    },
    cardAchivement:{
      backgroundImage:'url(assets/images/achivement-card.png)',
    },
    imgCard:{
      position: "absolute",
      width: "32%",
      top: "-13px",
      left: "-32px",
    },
    name:{
      color:whiteColor,
      fontFamily:'"Montserrat", san-serif',
      textTransform:'uppercase',
      fontSize:"10pt",
      marginTop:"8px",
    },
    description:{
      color:whiteColor,
      fontFamily:'"Montserrat", san-serif',
      fontSize:"9pt"
    },
    percent:{
      color:whiteColor,
       fontFamily:'"Montserrat", san-serif',
       fontSize:"7pt",
       marginTop:'-5px',
    },
    title:{
      color:whiteColor,
      fontFamily:'"Montserrat", san-serif',
      textTransform:'uppercase',
      fontSize:"26pt",
      fontWeight:700,
      margin:'32px 47px',
      '@media (max-width: 320px)': {
        margin: "32px 0px",
      },
    
    }
};
export default courseStyle;
