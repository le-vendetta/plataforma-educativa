const modalStyle = {
    input: {
        marginTop: 10,
        marginBottom:10
    },
    droppable:{
        border:'2px dotted #42a7f4',
        minHeight:500,

    },
    details:{
        marginTop: 10,
        background: 'rgba(200,200,150,.1)',
    },
    editor:{
        height: '65vh',
        overflow:'scroll',
        overflowX:'hidden'
    },
    sortableItem:{
        backgroundColor:'#3c3c3c',
        border:'3px solid #DCDCDC',
        borderRadius:10,
        height:100,
        alignItems:'center',
        textAlign:'center',
        display:'flex',
        '&:hover':{
            backgroundColor:'#565656',
        }
    },
    sortableItemHover:{
        backgroundColor:'#565656',
    },
    sortableItemText:{
        margin: '0px auto',
        fontSize: 50,
        color: 'rgba(250,250,250,.4)',
    },
    relative:{
        position:'relative'
    },
    btnRemove:{
        top: -10,
        right: 15,
        position: 'absolute',
        background: '#000',
        color: 'white',
        borderRadius: 33,
        border: '1px solid #ccc',
    },
};

export default modalStyle;