// ##############################
// // // Dashboard styles
// #############################

import {successColor, warningColor, blueColor, brownColor, orangeColor, whiteColor} from "../../variables/styles";

const dashboardStyle = {
    card:{
        backgroundColor:"#E2E9F3",
        height:'100%',
    },
    successText: {
        color: successColor
    },
    warningText: {
        color: warningColor
    },
    upArrowCardCategory: {
        width: 14,
        height: 14
    },
    separator:{
        marginTop: 20,
        marginBottom: 20,
        height: 4,
        background: '#f77070',
    },
    presentationCard:{
        backgroundRepeat:'no-repeat',
        backgroundPosition:'center center',
        height:'100%',
        color:'white',
        backgroundSize: '100% 100%'

    },

    presentationCardTitle:{
        marginTop: 20,
        fontSize: "27pt",
        fontWeight: 700,
        color: '#F06522',
        fontFamily: "'Montserrat', sans-serif",
    },
    presentationCardDescription:{
        marginTop: 10,
        color: whiteColor,
        fontSize:"12pt",
        fontFamily: "'Montserrat', sans-serif",
        textAlign:"justify",
    },
    presentationCardContent:{
        color: whiteColor,
    },
    presentationCardImg:{
        width: "50%",
    },
    genderChart:{
        background:'rebeccapurple',
        position:'relative'
    },
    comparativeChart:{
        background:'#2c8276',
        position:'relative',
    },
    characterPosition:{
      position: "absolute",
      left: "16%",
      top: "19%",
      width: "21%",
      zIndex: "1",
      '@media (max-width: 425px)': {
        display:'none',
      },
      '@media (min-width: 426px) and (max-width: 768px)': {
        top: '22%',
        width: "32%",
        left: "6%",
      },
      '@media (min-width: 768px) and (max-width: 1024px)': {
        top: '21%',
        width: "29%",
        left: "8%",
      },
    },
    paperPosition:{
      position: "absolute",
      left: "23%",
      top: "18%",
      width: "61%",
      zIndex: "-1",
      '@media (max-width: 425px)': {
        display:'none',
      },
      '@media (min-width: 426px) and (max-width: 768px)': {
        top: '20%',
        width: "83%",
        left: "12%",
      },
      '@media (min-width: 768px) and (max-width: 1024px)': {
        top: '18%',
        width: "80%",
        left: "15%",
      },
    },
    textPosition:{
      position: "absolute",
      width: "50%",
      left: "32%",
      top: "29%",
      '@media (max-width: 425px)': {
        top: '19%',
        width: "100%",
        left: "0%",
      },
      '@media (min-width: 426px) and (max-width: 768px)': {
        top: '22%',
        width: "69%",
        left: "25%",
      },
      '@media (min-width: 799px) and (max-width: 800px) and (max-height: 1280px)': {
        top: '21%',
        width: "59%",
        left: "29%",
      },
    },
    h1:{
      color: blueColor,
      fontSize:"1.6rem",
      fontWeight:"700",
      '@media (max-width: 425px)': {
        lineHeight:1,
      },
      '@media (min-width: 768px) and (max-height: 1024)': {
          fontSize:"1.7rem",
      },
    },
    p:{
      color:brownColor,
      fontSize:".975rem",
      fontWeight:"600",
      '@media (min-width: 426px) and (max-width: 768px)': {
        lineHeight:1,
      },
      '@media (min-width: 768px) and (max-height: 1024)': {
          fontSize:"1rem",
      },
    },
    detailGoal:{
      color:orangeColor,
      '@media (min-width: 620px)': {
        /*marginTop:'-5px',*/
      },
    },
    detailCourses:{
      color:blueColor,
      '@media (min-width: 620px)': {
        /*marginTop:'-9px',*/
      },
    },
    imgDetail:{
      width:'32%',
      '@media (max-width: 425px)': {
        width:'70%',
        marginTop:'0px',
      },
    },
    txtDetail:{
      textTransform:'uppercase',
      fontWeight:'bold',
      fontSize:'9pt',
      margin:5,
      '@media (max-width: 425px)': {
        fontSize:'9pt',
        lineHeight:'1',
        marginTop:'-7px',
      },
      '@media (min-width: 426px) and (max-width: 768px)': {
        marginTop:"-8px",
      },
    },
    advDetail:{
      fontSize:'45pt',
      fontWeight:'bold',
      margin:0,
      lineHeight:'3rem',
      '@media (max-width: 425px)': {
        fontSize:'29pt',
        marginTop:'-10px',
      },

    },
    linkDetail:{
      margin:0,
      color:"#000",
      fontSize:".890rem",
      textTransform:"lowercase",
      fontWeight:"700",
      '@media (max-width: 425px)': {
        fontSize:'10pt',
        marginTop:'-10px',
      },
    },
    h2:{
      fontFamily: "'Montserrat', sans-serif",
      fontWeight:700,
      fontSize:"19pt",
      color:blueColor,
    },
    h4:{
      fontSize:"12pt",
      fontWeight:"700",
      margin:0,
      color:blueColor,
    },
    headerContainer:{
      display:"flex",
    },
    headerContainerImg:{
      height: "31px",
      padding: "6px 12px 0 5px",
    },
    headerImg:{
      width:"100%",
      height:"auto",
    },
    ListItemIcon:{
      fontWeight:700,
      color:blueColor,
      fontSize:17,
    },
    textSecondary:{
      margin:0,
      color:blueColor,
      lineHeight: 1,
      fontSize: "10pt",
    },
    btn:{
      fontFamily: "'Montserrat', sans-serif",
      fontWeight:700,
      fontSize:"9pt",
      textTransform:"initial",
    },
    btnBlue:{
      color:blueColor,
    },
    btnWhite:{
      color: whiteColor,
    },
    btnIcon:{
      fontWeight:700,
      fontSize:"9pt",
    },
    divider:{
      margin:"auto",
      width:"85%",
      borderBottom: "1.5px solid #7FA0AF",
    },
    cardPrograms:{
      backgroundSize:"cover",
      backgroundImage:"url(../assets/images/bg-programs.jpg)",
    },
    programH1:{
      marginTop: 20,
      fontSize: "27pt",
      fontWeight: 700,
      color: orangeColor,
      fontFamily: "'Montserrat', sans-serif",
    },
    programH4:{
      fontSize:"12pt",
      fontWeight:"700",
      margin:0,
      color:blueColor,
    },
    separator:{
      marginTop:30,
    },
    body:{
      fontSize:"11pt",
      fontWeight:"300",
      marginTop:20,
      color:blueColor,
      fontFamily: "'Montserrat', sans-serif",
    },
    ListItemIconProgram:{
      width:"15%",
    },
    small:{
      fontSize:"10pt",
      fontWeight:"300",
      color:blueColor,
      fontFamily: "'Montserrat', sans-serif",
    },
    ListItemTextTeacher:{
      padding: "0 10px",
    }
};

export default dashboardStyle;
