// ##############################
// // // Tasks styles
// #############################
import {blueColor, brownColor, orangeColor, whiteColor} from "../../../variables/styles";

const programsStyle = {

};
export default programsStyle;
