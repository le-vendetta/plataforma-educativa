import {blueColor, brownColor, orangeColor, whiteColor} from "../../../variables/styles";
const defaultFont = {
    fontFamily: '"Montserrat", sans-serif',
    lineHeight: "1.5em"
};
const sessionStyle = {
  changeLesson:{
    marginTop: "-46px",
    left: "100%",
    marginLeft: "-190px",
    color: whiteColor,
    backgroundColor: orangeColor,
    ...defaultFont,

  },

};
export default sessionStyle;
