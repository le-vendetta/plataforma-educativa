import {blueColor, brownColor, orangeColor, whiteColor} from "../../../variables/styles";

const coursesStyle = {
    cardContainer:{
        marginBottom:15
    },
    presentationCard:{
        backgroundRepeat:'no-repeat',
        backgroundPosition:'center center',
        backgroundSize:'cover',
        height:'100%',
        color:'white',
        minHeight: "360px",
      },
    presentationCardTitle:{
      marginTop: 20,
      fontSize: "27pt",
      fontWeight: 700,
      color: orangeColor,
      fontFamily: "'Montserrat', sans-serif",
    },
    presentationCardDescription:{
      marginTop: 15,
      color: whiteColor,
      fontSize:"10pt",
      width: "65%",
      fontFamily: "'Montserrat', sans-serif",
      textAlign:"justify",
    },
    presentationCardContent:{
        color:whiteColor
    },
    btn:{
      fontFamily: "'Montserrat', sans-serif",
      fontWeight:700,
      fontSize:"9pt",
      textTransform:"initial",
      color: whiteColor,
    },
    actions:{
      bottom: 0,
    }

};
export default coursesStyle;
