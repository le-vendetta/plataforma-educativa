const groupManageStyle = {
    cardContainer:{
        marginBottom:15
    },
    draggable:{
        padding: '6px 8px',
        maxWidth: 20,
        textAlign: 'center',
        borderRadius:20,
        backgroundColor:'#8e8e8e',
        boxShadow:'0 0 2px #666',
        color:'white'
    },
    droppable:{
        minHeight:20,
        minWidth:20,
        backgroundColor:'#fff',
        border:'1px dotted #0963CC',
        textAlign:'center',
        justifyContent: 'center',
        alignSelf: 'center',
    },
    flex10:{
        flex:1
    }
};
export default groupManageStyle;
