const buttonStyle = {
    loginButton: {
        marginTop: 20,
    },
}

export default buttonStyle;