const modalStyle = {
    input: {
        marginTop: 10,
        marginBottom:10
    },
    inputContainer:{
        marginTop: 10,
        marginBottom:10
    },
    percent48:{
        width:'48%',
    },
    marginR2:{
        marginRight:'2%'
    },
    appBar: {
        position: 'relative',
    },
    flex: {
        flex: 1,
    },
    paddingTop:{
        paddingTop:25,
    },
    card:{
        backgroundColor:"#E2E9F3",
        color: '#0b3f51',
        fontFamily: "'Montserrat', sans-serif",
    },
    btnClose:{
      margin: "0px",
      padding:"8px 4px"
    },
    iconColor:{
      color: '#0b3f51',
      "&:hover": {
        color: '#F06522',
      }
    },
    draggableBig:{
        width:'100%',
        minHeight:200,
        border:'1px dotted #2379CC',
    },
    center:{
        alignItems:'center',
        justifyContent:'center',
        display:'flex'
    },
    draggableTextBig:{
        alignSelf: 'center',
        fontSize: 22,
        color: '#9bbdce',
    }
}

export default modalStyle;
