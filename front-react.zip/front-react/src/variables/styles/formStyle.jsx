import {defaultFont, container, orangeColor} from "../../variables/styles";

const footerStyle = theme => ({
    container: {
        position:"relative"
    },
    absolute: {
        position: "absolute"
    },
    title_instructions:{
    height:"175px !important",
    width:"90% !important",
    marginTop:"21px",
    marginLeft:"70px",
    display:"inherit",
        [theme.breakpoints.down("xs")]: {
          display:"none !important",
        },
        [theme.breakpoints.down("sm")]: {
          width: "90% !important",
          height: "135px !important",
          marginTop: "3px",
        }
    },
    title_image:{
      width:"190px !important",
      height: "190px !important",
      left: "30px",
      position: "absolute",
      [theme.breakpoints.down("xs")]: {
        display:"none !important",
      },
      [theme.breakpoints.down("sm")]: {
        width:"150px !important",
        height: "150px !important",
        left: "24px",
      }
    },
    label_instructions:{
        position: "absolute",
        top: "45px",
        left: "220px",
        fontWeight: "800",
        fontSize: "16px",
        fontFamily: 'trattatelloregular',
        [theme.breakpoints.down("xs")]: {
          top: "8px",
          left: "53px",
          fontSize: "14px",
        },
        [theme.breakpoints.down("sm")]: {
          top: "20px",
          left: "180px",
        },
        [theme.breakpoints.up("lg")]: {
          fontSize: "22px",
        },
    },
    text_instructions:{
      textAlign: "justify",
      position: "absolute",
      width: "70%",
      top: "58px",
      fontWeight:"600",
      left: "220px",
      lineHeight: "1",
      margin: "8px 0px",
      fontWeight:"600",
      fontFamily: 'cinnamon_cakeregular',
      [theme.breakpoints.down("xs")]: {
          top: "25px",
          left: "54px",
          width: "64%",
          margin: "0px 0",
      },
      [theme.breakpoints.down("sm")]: {
          top: "41px",
          left: "180px",
          width: "63%",
      },
    },
    psbutton:{
      textAlign: "right",
      paddingRight: "7%",
    },

});
export default footerStyle;
