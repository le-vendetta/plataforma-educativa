// ##############################
// // // Header styles
// #############################

import {
    container,
    defaultFont,
    orangeColor,
    defaultBoxShadow,
    infoColor,
    successColor,
    warningColor,
    dangerColor,
    whiteColor,
    skinColor
} from "../../variables/styles";

const headerStyle = theme => ({

    appBar: {
        top: "-30px",
        [theme.breakpoints.down("md")]: {
            top: "-15px"
        },
        boxShadow: "none",
        borderBottom: "0",
        marginBottom: "0",
        position: "absolute",
        width: "100%",
        zIndex: "1029",
        flex:1,
        border: "0",
        transition: "all 150ms ease 0s",
        minHeight: "50px",
        display: "block",
        padding: "10px 0 5px 0",
        color:whiteColor,
        backgroundColor:whiteColor,
        boxShadow:
            "0 12px 20px -10px rgba(0,0,0,.12), 0 4px 20px 0 rgba(0,0,0,.12), 0 7px 8px -5px rgba(0, 0, 0, 0.2)",
    },
    appBarKids:{

    },
    toolbarCenter:{

    },
    title: {
        ...defaultFont,
        top: "10px",
        "&:hover,&:focus": {
            background: "transparent"
        }
    },
    titleimg:{
      height: 45,
      marginTop: 12,
      marginBottom: 12,
    },
    appResponsive: {
        color:orangeColor,
        position: "absolute",
        right: "3%",
        top: "50%",
        marginTop: "-22px",
    },
    primary: {
        backgroundColor: orangeColor,
        color: "#FFFFFF",
        ...defaultBoxShadow
    },
    info: {
        backgroundColor: infoColor,
        color: "#FFFFFF",
        ...defaultBoxShadow
    },
    success: {
        backgroundColor: successColor,
        color: "#FFFFFF",
        ...defaultBoxShadow
    },
    warning: {
        backgroundColor: warningColor,
        color: "#FFFFFF",
        ...defaultBoxShadow
    },
    danger: {
        backgroundColor: dangerColor,
        color: "#FFFFFF",
        ...defaultBoxShadow
    }
});

export default headerStyle;
