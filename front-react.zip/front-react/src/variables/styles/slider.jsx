const slider = theme => ({
    slider:{
        backgroundColor:'transparent',
        [theme.breakpoints.down("xs")]: {
          height:"20px",
        },
        [theme.breakpoints.down("sm")]: {
          height:"20px",
        },
        [theme.breakpoints.down("md")]: {
          height:"20px",
        },
        [theme.breakpoints.down("lg")]: {
          height:"20px",
        },
        [theme.breakpoints.down("xl")]: {
          height:"20px",
        },

    },
    sliderItem:{
        minHeight:"100%",
        position:'relative',
    },
});

export default slider;
