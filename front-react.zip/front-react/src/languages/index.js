import i18n from "i18next";
import LanguageDetector from "i18next-browser-languagedetector";

i18n.use(LanguageDetector).init({
    // we init with resources
    resources: {
        en: {
            translations: {
                "courses": "Courses",
                "achievements": "Achievements",
                "diary": "Diary",
                "settings": "Settings",
                "profile": "Profile",
                "lessons": "Lessons",
                "viewed": "Viewed",
                "viewed_lessons": "Viewed lessons",
                "open_course": "Open course",
                "open": "Open",
                "save": "Save",
                "diary_of": "The {{name}}'s diary",
                "new_page": "New page",
                "images": "Images",
                "set_background_menu": "Set background image (menu)",
                "set_background_image": "Set background image",
                "last_achievement": "Last achievement won",
                "no_achievement": "You haven't earned any achievement",
                "last_viewed_lesson": "Last viewed lesson",
                "no_viewed_lesson": "You haven't seen any lessons yet",
                "this_week": "This week",
                "this_week_message": "you have seen {{total}} lessons this week",
                "view_achievements": "View achievements",
                "go_to_course": "Go to course",
                "viewed_lessons_week": "Viewed lessons in this week",
                "total": "Total",
                "monthly_advance": "Monthly advance",
                "logout": "Log out",
                "mark_all_as_viewed": "Mark all as viewed",

            }
        },
        es: {
            translations: {
                "courses": "Cursos",
                "achievements": "Logros",
                "diary": "Diario",
                "settings": "Ajustes",
                "profile": "Perfil",
                "lessons": "Lecciones",
                "viewed": "Visto",
                "viewed_lessons": "Lecciones vistas",
                "open_course": "Curso abierto",
                "open": "Abrir",
                "save": "Guardar",
                "diary_of": "El diario de {{name}}",
                "new_page": "Nueva pagina",
                "images": "Imagenes",
                "set_background_menu": "Elegir imagen de fondo (menu)",
                "set_background_image": "Elegir imagen de fondo",
                "last_achievement": "Ultimo logro ganado",
                "no_achievement": "No has ganado ningun logro",
                "last_viewed_lesson": "Ultima leccion vista",
                "no_viewed_lesson": "No has visto ninguna leccion",
                "this_week": "Esta semana",
                "this_week_message": "Has visto {{total}} lecciones esta semana",
                "view_achievements": "Ver logros",
                "go_to_course": "Ir al curso",
                "viewed_lessons_week": "Lecciones vistas en la semana",
                "total": "En total",
                "monthly_advance": "Avance mensual",
                "logout": "Cerrar sesion",
                "mark_all_as_viewed": "Marcar todos como vistos",

            }
        }
    },
    fallbackLng: "en",
    debug: true,

    // have a common namespace used around the full app
    ns: ["translations"],
    defaultNS: "translations",

    keySeparator: false, // we use content as keys

    interpolation: {
        escapeValue: false, // not needed for react!!
        formatSeparator: ","
    },

    react: {
        wait: true
    }
});

export default i18n;
