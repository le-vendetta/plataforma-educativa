export default class LangHelper {
    menuTranslate(t) {
        return {
            courses: t('courses'),
            achievements: t('achievements'),
            diary: t('diary'),
            settings: t('settings'),
            profile: t('profile'),
        }
    }
}