import {SET_USERS} from "../actions/defaultActions";

export function users(state = [], action) {
    switch (action.type) {
        case SET_USERS:
            return action.value;
        default:
            return state;
    }
}
