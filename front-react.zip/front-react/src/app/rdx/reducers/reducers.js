import {combineReducers} from 'redux';
import {errors, user, bgImage, notifications, stats, bgMenuImage} from './defaultReducers';
import {courses, course, lessons, lesson,presentation,advances,comparative,
    course_categories,lesson_types} from './coursesReducers';
import {pages, diary} from './diaryReducers';
import {achievement, achievements} from './achievementReducers';
import {sessions} from './sessionsReducers';
import {users} from './usersReducers';
import {grade_groups} from './gradeGroupsReducers';


export default combineReducers({
    errors,
    user,
    users,
    bgImage,
    bgMenuImage,
    courses,
    course,
    lessons,
    lesson,
    diary,
    pages,
    achievements,
    achievement,
    notifications,
    stats,
    sessions,
    presentation,
    advances,
    comparative,
    course_categories,
    lesson_types,
    grade_groups
})