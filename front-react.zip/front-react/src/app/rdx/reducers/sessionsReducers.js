import {SET_SESSIONS} from "../actions/defaultActions";

export function sessions(state = null, action) {
    switch (action.type) {
        case SET_SESSIONS:
            return action.value;
        default:
            return state;
    }
}
