import {SET_COURSE, SET_COURSES, SET_LESSON, SET_LESSONS,SET_PRESENTATION,SET_ADVANCES,
    SET_COMPARATIVE,SET_COURSE_CATEGORIES,SET_LESSON_TYPES} from "../actions/defaultActions";

export function courses(state = false, action) {
    switch (action.type) {
        case SET_COURSES:
            return action.value;
        default:
            return state;
    }
}

export function course(state = false, action) {
    switch (action.type) {
        case SET_COURSE:
            return action.value;
        default:
            return state;
    }
}

export function course_categories(state = null, action) {
    switch (action.type) {
        case SET_COURSE_CATEGORIES:
            return action.value;
        default:
            return state;
    }
}

export function presentation(state = null, action) {
    switch (action.type) {
        case SET_PRESENTATION:
            return action.value;
        default:
            return state;
    }
}
export function advances(state = null, action) {
    switch (action.type) {
        case SET_ADVANCES:
            return action.value;
        default:
            return state;
    }
}

export function comparative(state = null, action) {
    switch (action.type) {
        case SET_COMPARATIVE:
            return action.value;
        default:
            return state;
    }
}

export function lessons(state = false, action) {
    switch (action.type) {
        case SET_LESSONS:
            return action.value;
        default:
            return state;
    }
}

export function lesson_types(state = [], action) {
    switch (action.type) {
        case SET_LESSON_TYPES:
            return action.value;
        default:
            return state;
    }
}

export function lesson(state = false, action) {
    switch (action.type) {
        case SET_LESSON:
            return action.value;
        default:
            return state;
    }
}