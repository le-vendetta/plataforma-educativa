import {SET_GRADE_GROUPS} from "../actions/defaultActions";

export function grade_groups(state = [], action) {
    switch (action.type) {
        case SET_GRADE_GROUPS:
            return action.value;
        default:
            return state;
    }
}
