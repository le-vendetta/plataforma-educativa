import ApiHelper from '../../core/helpers/ApiHelper';
import {SET_SESSIONS} from "./defaultActions";

const helper = new ApiHelper();
helper.resource = 'sessions';

const setSessions = value => ({type: SET_SESSIONS, value});

export const getSessions = () => {
    let token = localStorage.getItem('token');

    return dispatch => {
        return helper.get('last', token).then(data => {
            dispatch(setSessions(data.data.sessions));
        });
    };
};



