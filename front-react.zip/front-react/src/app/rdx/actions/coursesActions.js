import ApiHelper from '../../core/helpers/ApiHelper';
import {SET_COURSES, SET_COURSE, SET_LESSONS, SET_LESSON,SET_PRESENTATION,SET_ADVANCES,
    SET_COMPARATIVE,SET_COURSE_CATEGORIES,SET_LESSON_TYPES, setAchievement} from "./defaultActions";
import Toast from "../../core/helpers/Toast";
import {store} from "../store";

const helper = new ApiHelper();

helper.resource = 'courses';

export const setCourses = value => ({type: SET_COURSES, value});
export const setCourse = value => ({type: SET_COURSE, value});
export const setLessons = value => ({type: SET_LESSONS, value});
export const setLesson = value => ({type: SET_LESSON, value});
export const setPresentation = value => ({type: SET_PRESENTATION, value});
export const setAdvances = value => ({type: SET_ADVANCES, value});
export const setComparative = value => ({type: SET_COMPARATIVE, value});
export const setCourseCategories = value => ({type: SET_COURSE_CATEGORIES, value});
export const setLessonTypes = value => ({type: SET_LESSON_TYPES, value});

/**
 * Obtener cursos
 * @returns {function(*)}
 */
export const getCourses = () => {
    let token = localStorage.getItem('token');

    return dispatch => {
        return helper.get('', token).then(data => {
            dispatch(setCourses(data.data.courses));
        });
    };
};

export const getCourseCategories = () => {
    let token = localStorage.getItem('token');
    return dispatch => {
        return helper.get('categories', token).then(data => {
            dispatch(setCourseCategories(data.data.categories));
        });
    };
};

export const updateCourse = (data) => {
    let token = localStorage.getItem('token');
    const {id,name,course_type,category_id,description,image} = data;
    return dispatch => {
        return helper.put(id,{name,course_type,category_id,description,image}, token).then(data => {
            let course = data.data.course;
            let courses = store.getState().courses;

            courses = courses.map(val=>{
                if(val.id === course.id){
                    return course;
                }
                return val;
            });
            dispatch(setCourses(JSON.parse(JSON.stringify(courses))));
            Toast('Curso modificado correctamente');

        });
    };
};

export const newCourse = (data) => {
    let token = localStorage.getItem('token');
    const {name,course_type,category_id,description,image} = data;
    return dispatch => {
        return helper.post('',{name,course_type,category_id,description,image}, token).then(data => {
            let course = data.data.course;
            let courses = store.getState().courses;
            courses.push(course);

            dispatch(setCourses(JSON.parse(JSON.stringify(courses))));
            Toast('Curso agregado correctamente');

        });
    };
};

export const removeCourses = (data) => {
    let token = localStorage.getItem('token');
    return dispatch => {
        return helper.delete('d',{courses:data}, token).then(response => {
            let courses = store.getState().courses;

            courses = courses.filter((course) => (data.indexOf(course.id) === -1 ));

            dispatch(setCourses(JSON.parse(JSON.stringify(courses))));

            Toast('Curso(s) eliminado(s) correctamente');
        });
    };
};

export const removeLessons = (data) => {
    let token = localStorage.getItem('token');
    return dispatch => {
        return helper.delete('lessons/d',{lessons:data}, token).then(response => {
            let lessons = store.getState().lessons;

            lessons = lessons.filter((lesson) => (data.indexOf(lesson.id) === -1 ));

            dispatch(setLessons(JSON.parse(JSON.stringify(lessons))));

            Toast('leccion(s) eliminada(s) correctamente');
        });
    };
};

/**
 * Obtener presentacion
 * @returns {function(*)}
 */
export const getPresentation = () => {
    let token = localStorage.getItem('token');

    return dispatch => {
        return helper.get('presentation', token).then(data => {
            dispatch(setPresentation(data.data.courses));
        });
    };
};

export const getComparative = () => {
    let token = localStorage.getItem('token');

    return dispatch => {
        return helper.get('comparative', token).then(data => {
            dispatch(setComparative(data.data.comparative));
        });
    };
};

/**
 * Obtener avances
 * @returns {function(*)}
 */
export const getAdvances = () => {
    let token = localStorage.getItem('token');

    return dispatch => {
        return helper.get('advances', token).then(data => {
            dispatch(setAdvances(data.data.advances));
        });
    };
};

/**
 * Obtener un curso
 * @param slug
 * @returns {function(*)}
 */
export const getCourse = (slug) => {
    let token = localStorage.getItem('token');

    return dispatch => {
        return helper.get('slug/' + slug, token).then(data => {
            dispatch(setCourse(data.data.course));
        });
    };
};

/**
 * Obtener lecciones de un curso
 * @param course
 * @returns {function(*)}
 */
export const getLessons = (course) => {
    let token = localStorage.getItem('token');

    return dispatch => {

        return helper.get(course + '/lessons', token).then(data => {
            dispatch(setLessons(data.data.lessons));
        });
    };
};

export const saveLesson = (course,data) => {
    let token = localStorage.getItem('token');

    return dispatch => {
        return helper.post(course + '/lessons',data, token).then(data => {
            Toast('Leccion guardada correctamente');
        });
    };
};

export const getLessonTypes = () => {
    let token = localStorage.getItem('token');

    return dispatch => {

        return helper.get( 'lessons/types', token).then(data => {
            dispatch(setLessonTypes(data.data.types));
        });
    };
};


/**
 * Obtener una leccion (es necesario el curso y la leccion en slug)
 * @param course
 * @param lesson
 * @returns {function(*)}
 */
export const getLesson = (course, lesson) => {
    let token = localStorage.getItem('token');
    return dispatch => {
        return helper.get('slug/' + course + '/lesson/' + lesson, token).then(({data}) => {
            dispatch(setLesson(data.lesson));
        });
    };
};

/**
 * Obtener una leccion (es necesario el curso y la leccion en slug)
 * @param course
 * @param lesson
 * @returns {function(*)}
 */
export const viewLesson = (lesson) => {
    let token = localStorage.getItem('token');

    return dispatch => {

        return helper.put('lessons/' + lesson, [], token).then(data => {
            dispatch(setLesson(data.data.lesson));
            if (data.data.achievement.length > 0) {
                dispatch(setAchievement(data.data.achievement));
            }
            Toast("Felicidades! completaste otra leccion.");
        });
    };
};
