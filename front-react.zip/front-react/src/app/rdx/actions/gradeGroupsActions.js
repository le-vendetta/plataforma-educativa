import ApiHelper from '../../core/helpers/ApiHelper';
import {SET_GRADE_GROUPS, } from "./defaultActions";


const helper = new ApiHelper();

//helper.resource = 'courses';

export const setGradeGroups = value => ({type: SET_GRADE_GROUPS, value});



export const getGradeGroups = () => {
    let token = localStorage.getItem('token');

    return dispatch => {

        return helper.get('grade-groups/', token).then(({data}) => {
            dispatch(setGradeGroups(data.grade_groups));
        });
    };
};
