import ApiHelper from '../../core/helpers/ApiHelper';
import {SET_BG_IMAGE, SET_BG_MENU_IMAGE} from "./defaultActions";
import Toast from "../../core/helpers/Toast";
import {store} from "../store";

const helper = new ApiHelper();
helper.resource = 'user/space';
const setBgImage = value => ({type: SET_BG_IMAGE, value});
const setMenuImage = value => ({type: SET_BG_MENU_IMAGE, value});

/**
 * Obtener cursos
 * @returns {function(*)}
 */
export const getSpace = () => {
    let token = localStorage.getItem('token');

    return dispatch => {
        if (!store.getState().image) {
            if (!token) {
                let timer = setInterval(() => {
                    if (token) {
                        space(dispatch);
                        clearInterval(timer);
                    } else {
                        token = localStorage.getItem('token');
                    }
                }, 100)
            } else {
                space(dispatch);
            }

        }
    };
};

const space = (dispatch) => {
    let token = localStorage.getItem('token');

    return helper.get('', token).then(data => {
        let space = data.data.space;

        dispatch(setMenuImage(space.bg_menu_image || false));
        dispatch(setBgImage(space.bg_image || false));
    });
};

/**
 * Obtener cursos
 * @returns {function(*)}
 */
export const setSpace = (space) => {
    let token = localStorage.getItem('token');
    let send = {};
    if (space.bgImage) {
        send['bg_image'] = space.bgImage;
    }
    if (space.bgMenuImage) {
        send['bg_menu_image'] = space.bgMenuImage;
    }

    return dispatch => {
        return helper.put('u', send, token).then(data => {
            let space = data.data.space;
            dispatch(setMenuImage(space.bg_menu_image));
            dispatch(setBgImage(space.bg_image));

            Toast('Espacio actualizado');
        });
    };
};

