import {allNotifications,
    getNotifications,
    viewNotification,
    updateUser,
    updateUserAvatar,
    updateUserPassword,
    getStats,
} from "./UserActions";


import {
    setErrors,
    setUser,
    setAchievement,
} from './defaultActions';

export {
    //user actions
    allNotifications,
    getNotifications,
    viewNotification,
    updateUser,
    updateUserAvatar,
    updateUserPassword,
    getStats,
    //default actions
    setErrors,
    setUser,
    setAchievement,
}