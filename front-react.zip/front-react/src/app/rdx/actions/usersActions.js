import ApiHelper from '../../core/helpers/ApiHelper';
import {SET_USERS} from "./defaultActions";


const helper = new ApiHelper();

helper.resource = 'users';

export const setUsers = value => ({type: SET_USERS, value});



export const getUsers = ()=>{
    let token = localStorage.getItem('token');
    return dispatch => {
        return helper.get('students/',token).then(({data}) => {
            let {users} = data;
            dispatch(setUsers(users))
        });
    };
};