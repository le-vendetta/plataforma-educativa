import React, {Component} from 'react';
import Loading from "./../../../components/Loading";
import {Col, Row} from "react-flexbox-grid";
import {Button, Divider, Paper, Typography,withStyles} from "material-ui";
import {connect} from "react-redux";
import {Slider} from './../../../components';
import sessionStyle from "../../../variables/styles/teacher/session";
import {setLesson} from "../../../rdx/actions/coursesActions";
import ApiHelper from "../../../core/helpers/ApiHelper";
import LessonsListModal from "../../../components/Modals/LessonsListModal";
import {withRouter} from "react-router-dom";
import Toast from "../../../core/helpers/Toast";

class Lesson extends Component {
    constructor() {
        super();
        this.state  = {session:null,lesson:null,modal_open:false,change_lesson:false};
        this.api    = new ApiHelper();
        this.token  = localStorage.getItem('token');

    }


    componentWillMount(){
        this.getLesson(this.props.match.params.session);
    }

    render() {
        let {lesson, classes} = this.props;
        let {session,modal_open,change_lesson} = this.state;

        return (!lesson || !session? <Loading/> :
            <Row>

                <Col md={12}>
                {change_lesson && <Button className={classes.changeLesson} onClick={()=>this.nextLesson()}>Cambiar de leccion</Button>}

                    <Paper elevation={4} className="paper-main">

                        <Typography component="div" className="paper-content">
                            {lesson.type_slug === 'game' && <iframe src={lesson.content} frameBorder="0" className="gameFrame" title={lesson.name}>Game content</iframe> }
                            {lesson.type_slug === 'sliders' && <Slider onEnd={()=>this.setState({change_lesson:true})} onChange={(index)=>this.updateSlider(index)} selected={session.information.slider}/> }
                            {lesson.type_slug === 'text' && <div>{lesson.content}</div>}
                        </Typography>
                        <Divider/>

                    </Paper>
                </Col>

                {session && <LessonsListModal open={modal_open} session={session} onReload={lesson => this.getLesson(session.id)}/>}
            </Row>);
    }

    getLesson(session){
        this.api.get('session/'+session, this.token).then(({data}) => {
            let {session} = data;
            this.setState({session});
            if(session.status){
                this._getLesson(session);
            }else{
                Toast('Esta sesion ya fue terminada','error');
                this.props.history.push(process.env.PUBLIC_URL + '/home');
            }
        });
    }

    _getLesson(session){
        this.api.get('courses/slug/'+session.course_info.slug+'/lesson/'+session.lesson_info.slug, this.token).then(({data}) => {
            let {lesson} = data;
            let change_lesson = lesson.type_slug !== 'sliders';

            this.props.setLesson(lesson);

            if(lesson.type_slug === 'sliders'){
                let sliders = JSON.parse(lesson.content);

                change_lesson = session.information.slider === sliders.length;
            }

            this.setState({change_lesson});

            this.setState({modal_open:false});
        });
    }
    nextLesson(){
        this.setState({modal_open:true})
    }

    updateSlider(idx){

        let {session} = this.state;

        session.information.slider = idx;

        this.setState({session:JSON.parse(JSON.stringify(session))},()=>{
            this.api.put('session/'+this.props.match.params.session+'/slider',{slider:idx}, this.token);
        });

    }

}

const stateToProps = ({lesson,user}) => ({lesson,user});
const dispatchToProps = (dispatch) => ({
    setLesson: (lesson) => dispatch(setLesson(lesson)),
});

const conn = connect(stateToProps, dispatchToProps);

export default withStyles(sessionStyle)(conn(withRouter(Lesson)));
