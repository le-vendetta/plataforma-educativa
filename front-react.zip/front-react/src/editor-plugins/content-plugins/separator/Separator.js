import React, {Component} from 'react'
import {withStyles} from 'material-ui';
import separatorStyle from './styles';

class Separator extends Component{

    render() {
        const {classes} = this.props;
        return <div className={classes.main}></div>
    }

}

export default withStyles(separatorStyle)(Separator);