import React from 'react'

import Icon from '@material-ui/core/Icon';
import Separator from './Separator';

export default {
    Component: Separator,
    IconComponent: <Icon>drag_handle</Icon>,
    name: 'separator',
    version: '0.0.1',
    text: 'Separador',
    description: 'Diseñado para dibujar una linea horizontal.',
}