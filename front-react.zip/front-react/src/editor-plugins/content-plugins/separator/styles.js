const separatorStyle = theme => ({
    main:{
        width:'100%',
        marginTop:5,
        marginBottom:5,
        height:1,
        backgroundColor:'#8c8c8c',
        display:'flex',
        alignSelf:'center',
        justifyContent:'center'
    }
});

export default separatorStyle;
