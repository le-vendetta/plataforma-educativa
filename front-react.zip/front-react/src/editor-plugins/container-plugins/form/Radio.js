import React, {Component} from 'react'
import {Radio as UIRadio} from "material-ui";

class Radio extends Component{
    render() {
        const {onChange,label,empty,name,id} = this.props;
        if(empty){
            return <UIRadio
                checked={false}
                color="primary"
                disabled
            />;
        }

        return <div className="input-container">
                  <input className="option-button" type="radio" id={'radio-'+id} onChange={(e)=>onChange(e.target.checked)} value={label} name={name} />
                  <div className="option-answer">
                    <div className="icon">
                      <img src={process.env.PUBLIC_URL + '/assets/images/icons/radio.png'} />
                    </div>
                    <label  htmlFor={id} className="option-answer-label">{label}</label>
                  </div>
                </div>


    }
}

export default Radio;
