import React, {Component} from 'react'
import {Checkbox as UICheckbox, FormControlLabel} from "material-ui";

class Checkbox extends Component{
    render() {
        const {onChange,checked,label,empty,name} = this.props;
        if(empty){
            return <UICheckbox
                checked={false}
                color="primary"
                disabled
                defaultValue={''}
            />;
        }

        return  <div className="input-container">
                   <input checked={checked} className="option-button" type="checkbox" onChange={(e)=>onChange(e.target.checked)} value={label} name={name} />
                   <div className="option-answer">
                     <div className="icon">
                       <img src={process.env.PUBLIC_URL + '/assets/images/icons/checkbox.png'} />
                     </div>
                     <label className="option-answer-label">{label}</label>
                   </div>
                 </div>

    }
}

export default Checkbox;
