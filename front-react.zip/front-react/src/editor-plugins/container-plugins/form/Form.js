import React, {Component} from 'react'
import Checkbox from './Checkbox';
import BottomToolbar from 'ory-editor-ui/lib/BottomToolbar'
import CustomButton from "../../../front/components/CustomButtons/Button";
import {
    Icon,
    IconButton,
    MenuItem,
    TextField,
    Toolbar,
    Tooltip,
    Typography,
    withStyles
} from "material-ui";
import {CheckBox,RadioButtonChecked,Title,FontDownload} from '@material-ui/icons';

import './styles.css';
import formStyle from "../../../variables/styles/formStyle";
import Radio from "./Radio";
import {Col, Row} from "react-flexbox-grid";
import InputControl from "./InputControl";

let checkboxNames = 0;
let radioNames = 0;
let inputNames = 0;

class Form extends Component{
    state = {title:'Mi formulario',items:[],clear_visible:[],columns:3};//items structure {type:'',label:'',checked:false}

    constructor(props){
        super(props);
        if(props.state.value){
            let items = props.state.value.items.filter(function(e){return e});
            props.state.value.items = items;
            this.state = {...props.state.value,clear_visible:[]};
        }
    }

    onChange(){
        const {title,items,columns} = this.state;
        this.props.onChange({
            value: {title,items,columns}
        })
    }

    render() {
        const {readOnly} = this.props;
        if (!readOnly) {
            return this.showEditable();
        }else{
            return this.showItems();
        }
    }

    getGroupItems(items){
        let data = [];
        items.forEach((item,idx) => {
            item.original_id = idx;
            if(items[idx-1] && (item.type === items[idx-1].type || items[idx-1].type === 'text')){
                data[data.length-1].push(item);
            }else{
                data.push([item])
            }
        });
        return data;
    }

    showEditable(){
        const {title,columns,clear_visible} = this.state;
        const {focused}     = this.props;
        let items = this.getGroupItems(this.state.items);

        return (
            <div >

                <Row className="form-plugin">
                    <Col md={12}>
                        <Col md={12}><h3>{title}</h3></Col>
                        <Row>
                            {items.map((group,idx) => {
                                return <Col md={12/columns} key={'group-items'+idx} className='relative form-plugin-group'>

                                        {group.map(item =>{
                                            return <div key={'input'+item.original_id} onMouseOver={()=>this.clearVisible(true,item.original_id)} onMouseLeave={()=>this.clearVisible(false,item.original_id)} className='form-plugin-input-container'>
                                                {item.type === 'checkbox' && <Checkbox empty={true}/>}
                                                {item.type === 'radio' && <Radio empty={true}/>}

                                                <input type="text" className="form-plugin-input" placeholder='Titulo' value={item.label} onChange={(e) => this.changeInputLabel(item.original_id,e)}/>
                                                {item.type === 'textfield' && <InputControl disabled={true}/>}
                                                <span style={{display: clear_visible[item.original_id]?'block':'none'}} className="form-plugin-clear" onClick={()=>this.removeElement(item.original_id)}>
                                                     <Tooltip id="tooltip-fab" title="Quitar elemento">
                                                        <Icon>clear</Icon>
                                                     </Tooltip>
                                                </span>
                                            </div>
                                        })}

                                        <span className="form-plugin-clear-group" onClick={()=>this.removeGroup(idx,items)}>
                                             <Tooltip id="tooltip-fab" title="Quitar grupo de elementos">
                                                <Icon>clear</Icon>
                                             </Tooltip>
                                        </span>
                                </Col>
                            })}
                        </Row>
                    </Col>

                </Row>

                <BottomToolbar open={focused}>
                    <Row>
                        <Col md={12}>
                            <Row>
                                <Col md={6}>
                                    <TextField value={title} onChange={(e)=> this.titleChange(e)} margin="normal" className="form-plugin-input-white" label="Elige un titilo"/>
                                </Col>

                                <Col md={6}>
                                    <TextField
                                        className="form-plugin-select"
                                        select
                                        label="Columnas"
                                        value={columns}
                                        onChange={(e)=> this.columnsChange(e)}
                                        fullWidth
                                    >

                                        <MenuItem value={1}>Una</MenuItem>
                                        <MenuItem value={2}>Dos</MenuItem>
                                        <MenuItem value={3}>Tres</MenuItem>
                                        <MenuItem value={4}>Cuatro</MenuItem>
                                        <MenuItem value={6}>Seis</MenuItem>
                                    </TextField>

                                </Col>
                            </Row>
                        </Col>
                        <Col md={12}>
                            <Row center="xs">
                                <Toolbar>
                                    <Tooltip id="tooltip-fab" title="Agregar texto/pregunta">
                                        <IconButton aria-label="Menu" onClick={()=>this.addItem('text')}>
                                            <Title className='form-plugin-toolbar-icon'/>
                                        </IconButton>
                                    </Tooltip>

                                    <Tooltip id="tooltip-fab" title="Agregar chekbox">
                                        <IconButton aria-label="Menu" onClick={()=>this.addItem('checkbox')}>
                                            <CheckBox className='form-plugin-toolbar-icon'/>
                                        </IconButton>
                                    </Tooltip>

                                    <Tooltip id="tooltip-fab" title="Agregar radio">
                                        <IconButton aria-label="Menu" onClick={()=>this.addItem('radio')}>
                                            <RadioButtonChecked className='form-plugin-toolbar-icon'/>
                                        </IconButton>
                                    </Tooltip>

                                    <Tooltip id="tooltip-fab" title="Agregar pregunta abierta">
                                        <IconButton aria-label="Menu" onClick={()=>this.addItem('textfield')}>
                                            <FontDownload className='form-plugin-toolbar-icon'/>
                                        </IconButton>
                                    </Tooltip>
                                </Toolbar>
                            </Row>
                        </Col>
                    </Row>
                </BottomToolbar>
            </div>

        )
    }

    showItems(){
        const {title,columns} = this.state;
        const {classes} = this.props;

        let items = this.getGroupItems(this.state.items);
        return (
            <div>
                <Row className="form-plugin text">
                    <Col md={12}>
                        <Col md={12}>
                         <Row center="xs" className={classes.container}>
                         <img className={classes.title_instructions} src={process.env.PUBLIC_URL + "/assets/images/plugins/title_instructions.png"} alt="background"/>
                         <img className={classes.title_image} src={process.env.PUBLIC_URL + "/assets/images/plugins/title_image.png"} alt="background"/>
                            <span className={classes.label_instructions}>INSTRUCCIONES</span>
                            <h3 className={classes.text_instructions}>{title}</h3>
                         </Row>

                        </Col>
                        <Row>
                            {items.map((group,idx) => {
                                return <Col md={12/columns} key={'group-items'+idx} >{/*className="form-plugin-label-text"*/}
                                  <div className="option-answer-group">
                                    {group.map(item =>{
                                        return <div key={'input'+item.original_id} className={item.type}>
                                            {item.type === 'checkbox' && <Checkbox label={item.label} name={this.getCheckboxName(item.original_id)}
                                                                                   checked={item.checked}
                                                                                   onChange={(checked) => this.check(item.original_id,checked)}/>}

                                            {item.type === 'radio' &&  <Radio label={item.label} name={this.getRadioName(item.original_id)}
                                                                             checked={item.checked}
                                                                             id={item.original_id}
                                                                             onChange={(checked) => this.check(item.original_id,checked)}/>}


                                            {item.type === 'textfield' && <InputControl label={item.label} name={this.getInputName(item.original_id)}
                                                                             id={item.original_id}
                                                                             value={item.text}
                                                                             disabled={false}
                                                                             onChange={(text) => this.setText(item.original_id,text)}/>}

                                            {item.type === 'text' &&  <Typography variant="subheading">
                                                {item.label}
                                            </Typography>}
                                        </div>
                                    })}
                                    </div>
                                </Col>
                            })}

                        </Row>
                    </Col>
                </Row>
                <Row>
                  {/* <Col md={12} className={classes.psbutton}><CustomButton color="primary" size="small">Terminar</CustomButton></Col> */}
                  </Row>
            </div>

        )
    }

    check(id,checked){
        let {items} = this.state;
        items[id].checked = checked;
        this.setState({items},()=>{
            this.onChange();
        });
    }

    setText(current,text){
        let {items} = this.state;
        items[current].text = text;

        this.setState({items},()=>{
            this.onChange();
        });
    }

    changeInputLabel(id,e){
        let {items} = this.state;
        items[id].label = e.target.value;
        this.setState({items},()=>{
            this.onChange();
        });
    }

    titleChange(e){
        let title = e.target.value;
        if(title.length === 0){
            title = 'Mi formulario';
        }
        this.setState({title},()=>{
            this.onChange();
        });
    }

    columnsChange(e){
        let columns = e.target.value;
        this.setState({columns},()=>{
            this.onChange();
        });
    }

    addItem(type){
        let item = {type,label:''};
        let items = this.state.items;

        if(type === 'text'){
            item.label = 'Texto o pregunta';
        }

        if(type === 'checkbox'){
            item.label      = 'Etiqueta del checkbox';
            item.checked    = false;
        }

        if(type === 'radio'){
            item.label      = 'Etiqueta del radio';
            item.checked    = false;
        }

        if(type === 'text-field'){
            item.label      = 'Etiqueta de la pregunta';
        }

        items.push(item);

        this.setState({items},()=>{
            this.onChange();
        });

    }

    getCheckboxName(current){
        const {items} = this.state;

        if(items[current-1]){
            if(items[current-1].type !== 'checkbox'){
                checkboxNames += 1;
            }
        }
        return 'checkbox-'+checkboxNames;
    }

    getRadioName(current){
        const {items} = this.state;

        if(items[current-1]){
            if(items[current-1].type !== 'radio'){
                radioNames += 1;
            }
        }
        return 'radio-'+radioNames;
    }

    getInputName(current){
        inputNames += 1;
        return 'input-'+inputNames;
    }

    removeElement(id){
        let {items} = this.state;
        delete items[id];
        items = items.filter(function(e){return e});
        this.setState({items},()=>{
            this.onChange();
        });
    }

    removeGroup(id,groups){
        let {items} = this.state;

        groups[id].forEach(item =>{
            delete items[item.original_id];
        });
        items = items.filter(function(e){return e});

        this.setState({items},()=>{
            this.onChange();
        });
    }

    clearVisible(is,id){
        let {clear_visible} = this.state;
        clear_visible[id] = is;
        this.setState({clear_visible})
    }
}

export default  withStyles(formStyle)(Form) ;
