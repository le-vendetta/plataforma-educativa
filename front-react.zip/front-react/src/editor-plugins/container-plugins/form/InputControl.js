import React, {Component} from 'react'
import {TextField, FormControlLabel} from "material-ui";

class InputControl extends Component{
    render() {
        const {name,label,disabled} = this.props;

        // return <FormControlLabel
        //           disabled={disabled}
        //           control={
        //               <TextField
        //                   value={label}
        //                   color="primary"
        //                   onChange={(e) => this.props.onChange(e.target.value)}
        //                   name={name}
        //               />
        //           }
        //           label={label}
        //       />

        return <div id="notebook-paper">
                <div id="content">
                  <div className="hipsum" contentEditable="true"  onChange={(e) => this.props.onChange(e.target.value)}>
                    {label}?
                    </div>
                  </div>
                </div>

    }
}

export default InputControl;
