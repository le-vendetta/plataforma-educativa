import React from 'react'

import Icon from '@material-ui/core/Icon';
import Form from './Form';

export default {
    Component: Form,
    IconComponent: <Icon>ballot</Icon>,
    name: 'form',
    version: '0.0.1',
    text: 'Formulario',
    description: 'Diseñado para hacer pequeños cuestionarios.',
}