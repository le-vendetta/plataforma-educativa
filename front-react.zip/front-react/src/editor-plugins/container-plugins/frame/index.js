import React from 'react'

import Icon from '@material-ui/core/Icon';
import Frame from './Frame';

export default {
    Component: Frame,
    IconComponent: <Icon>web</Icon>,
    name: 'frame',
    version: '0.0.1',
    text: 'Embebido',
    description: 'Embebe cualquier url.',
}