import {orangeColor} from "../../../variables/styles";

const frameStyles = theme => ({
    frameContainer:{
        width:'100%',
        marginTop:5,
        marginBottom:5,
        height:20,
        backgroundColor:'#dfdfdf',
        display:'flex',
        alignSelf:'center',
        justifyContent:'center'
    },
    icon:{
        color:'white'
    },
    droppable:{
        border:'1px dotted #2660DF',
        width:'100%',
        minHeight:50
    },
    droppableOver:{
        backgroundColor:'#d7d7d7',
    },

    droppableOverText:{
        fontSize:20,
        color:'rgba(0,0,0,.4)'
    },
    draggableContainer:{
        border:'1px dotted #ccc',
        paddingTop:7,
        position:'relative'
    },
    draggableText:{
        alignSelf:'center',
        color:'rgba(250,250,250,.3)',
        fontSize:10,
        zIndex:0,
    },
});

export default frameStyles;
