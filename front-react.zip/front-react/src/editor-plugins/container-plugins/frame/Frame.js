import React, {Component} from 'react'
import BottomToolbar from 'ory-editor-ui/lib/BottomToolbar'
import {
    TextField, Tooltip,
    withStyles, Button,
} from "material-ui";

import frameStyles from "./styles";
import {Col, Row} from "react-flexbox-grid";
import Icon from '@material-ui/core/Icon';
import ApiHelper from "../../../app/core/helpers/ApiHelper";
import EmbebModal from "../../../front/components/Modals/EmbebModal";
import CustomButton from "../../../front/components/CustomButtons/Button";

class Frame extends Component{
    state = {url:'',width:500,height:400,plugins:[],dragStart:false,modal_open:false};//items structure {type:'',label:'',checked:false}

    constructor(props){
        super(props);
        if(props.state.value){
            this.state = {url:  props.state.value.url,width:props.state.value.width,height:props.state.value.height};
        }
    }

    componentWillMount(){
        let api = new ApiHelper();
        let token = localStorage.getItem('token');

        api.get('plugins', token).then(({data}) => {
            let plugins = data.plugins;
            plugins.push({url:'',icon:'music_video',description:'Video/Audio'});
            this.setState({plugins})
        });

    }

    onChange(){
        const {url,width,height} = this.state;
        this.props.onChange({
            value: {url,width,height}
        })
    }

    render() {
        const {readOnly} = this.props;
        if (!readOnly) {
            return this.showEditable();
        }else{
            return this.showItems();
        }
    }

    showEditable(){
        const {url,width,height,plugins,dragStart,modal_open} = this.state;
        const {focused,classes}     = this.props;

        return (
            <div>
                <Row className={["form-plugin",classes.iframeContainer].join(' ')}>
                    <Col md={12} >
                        <Row center="xs">
                            <div onDragOver={(e) =>this.dragOver(e)} onDrop={(e) => this.onDrop(e) }  className={[classes.droppable,dragStart?classes.droppableOver:''].join(' ')}>
                                <Col md={12}><Icon>web</Icon></Col>
                                {url.length>0 && <iframe src={url} frameBorder="0" width={width} height={height}></iframe>}
                                {dragStart && <span className={classes.droppableOverText}>Arrastra aqui!</span>}
                            </div>
                        </Row>
                    </Col>
                </Row>

                <BottomToolbar open={focused}>
                    <Row style={{maxWidth:500}}>
                        <Col md={12}>
                            <span className={classes.draggableText}>Arrastra los items al recuadro azul</span>

                            <Row center="xs" middle="xs" className={classes.draggableContainer}>

                                {plugins && plugins.map((val,idx)=>(
                                    <Tooltip title={val.description} key={idx} >
                                        <div draggable={true} onDragStart={(e)=>this.onDrag(e,val.url)}
                                             onDragEnd={(e)=>this.onDragEnd(e)}
                                             style={{zIndex:1}}>
                                            <Icon className={classes.icon}>{val.icon}</Icon>
                                        </div>
                                    </Tooltip>
                                ))};

                            </Row>
                        </Col>

                        <Col md={6}>
                            <TextField value={width} onChange={(e)=> this.widthChange(e)} margin="normal" className="form-plugin-input-white" label="Ancho" fullWidth/>
                        </Col>
                        <Col md={6}>
                            <TextField value={height} onChange={(e)=> this.heightChange(e)} margin="normal" className="form-plugin-input-white" label="Alto" fullWidth/>
                        </Col>

                    </Row>
                </BottomToolbar>

                <EmbebModal open={modal_open} onUrl={url=>this.processUrl(url)} onClose={()=>this.setState({modal_open:false})}/>
            </div>

        )
    }
    showItems(){
        const {url,width,height} = this.state;
        const {classes} = this.props;

        return (
            <div>
                <Row className={["form-plugin",classes.iframeContainer].join(' ')}>
                    <Col md={12} >
                        <Row center="xs">
                            {url.length>0 ? <iframe src={url} frameBorder="0" width={width} height={height} title={url}></iframe>:<Icon>web</Icon>}
                        </Row>
                    </Col>
                </Row>
              
            </div>

        )
    }

    onDrag(ev,url) {
        ev.dataTransfer.setData("url", url);
        this.setState({dragStart:true});
    }

    onDragEnd(){
        this.setState({dragStart:false});
    }

    dragOver(ev){
        ev.stopPropagation();
        ev.preventDefault();
    }

    onDrop(ev) {
        ev.preventDefault();
        let url = ev.dataTransfer.getData("url");
        if(url.length > 0){
            this.processUrl(url);
        }else{
            this.setState({modal_open:true})
        }
    }

    processUrl(url){
        if(url.length > 10 && this.validURL(url)){
            if(url.indexOf('you')>-1){
                url = 'https://www.youtube.com/v/'+this.id_youtube(url);
            }

            this.setState({url},()=>{
                this.onChange();
            });
        }
        this.setState({dragStart:false});
    }

    widthChange(e){
        let width = e.target.value;
        this.setState({width},()=>{
            this.onChange();
        });
    }

    heightChange(e){
        let height = e.target.value;
        this.setState({height},()=>{
            this.onChange();
        });
    }

    validURL(str) {
        let regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
        return regex.test(str);
    }

    id_youtube(url){
        let regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
        let match = url.match(regExp);
        return (match&&match[7].length ===11)? match[7] : false;
    }

}

export default withStyles(frameStyles)(Frame);
