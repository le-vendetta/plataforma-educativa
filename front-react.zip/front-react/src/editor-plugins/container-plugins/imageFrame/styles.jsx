const imageFrameStyles = theme => ({
    imageFrameContainer:{
        width:'100%',
        marginTop:5,
        marginBottom:5,
        display:'flex',
        alignSelf:'center',
        justifyContent:'center'
    },
    icon:{
        color:'white'
    },
    droppable:{
        border:'1px dotted #2660DF',
        width:'100%',
        minHeight:20
    },
    droppableOver:{
        backgroundColor:'#d7d7d7',
    },

    droppableOverText:{
        fontSize:20,
        color:'rgba(0,0,0,.4)'
    },
    draggableContainer:{
        border:'1px dotted #ccc',
        paddingTop:7,
        position:'relative'
    },
    text:{
        alignSelf:'center',
        color:'#fff',
        fontSize:14,
        zIndex:0,
    },
    responsiveImage:{
        width:'100%'
    }
});

export default imageFrameStyles;
