import React, {Component} from 'react'
import BottomToolbar from 'ory-editor-ui/lib/BottomToolbar'
import {
    TextField,
    withStyles
} from "material-ui";

import imageFrameStyles from "./styles";
import {Col, Row} from "react-flexbox-grid";
import Icon from '@material-ui/core/Icon';
import ApiHelper from "../../../app/core/helpers/ApiHelper";
import Toast from "../../../app/core/helpers/Toast";

class ImageFrame extends Component{
    state = {url:'',width:500,height:400,plugins:[],dragOver:false,modal_open:false};//items structure {type:'',label:'',checked:false}

    constructor(props){
        super(props);
        if(props.state.value){
            this.state = {url:  props.state.value.url,width:props.state.value.width,height:props.state.value.height};
        }
    }

    onChange(){
        const {url,width,height} = this.state;
        this.props.onChange({
            value: {url,width,height}
        })
    }

    render() {
        const {readOnly} = this.props;
        if (!readOnly) {
            return this.showEditable();
        }else{
            return this.showItems();
        }
    }

    showEditable(){
        const {url,dragOver,width,height} = this.state;
        const {focused,classes}     = this.props;

        return (
            <div >
                <Row className={["form-plugin",classes.imageFrameContainer].join(' ')}>
                    <Col md={12} >
                        <Row center="xs">
                            <div onDragOver={(e) =>this.dragOver(e)} onDrop={(e) => this.onDrop(e) }  className={[classes.droppable,dragOver?classes.droppableOver:''].join(' ')}>
                                <Col md={12}><Icon>web</Icon></Col>
                                {url.length>0 && this.validURL(url)&& <img src={url} width={width} height={height} alt={url}/>}

                                {dragOver && <span className={classes.droppableOverText}>Arrastra aqui!</span>}
                            </div>
                        </Row>
                    </Col>
                </Row>

                <BottomToolbar open={focused}>
                    <Row style={{maxWidth:500}}>
                        <Col md={6}>
                            <TextField value={width} onChange={(e)=> this.widthChange(e)} margin="normal" className="form-plugin-input-white" label="Ancho" fullWidth/>
                        </Col>
                        <Col md={6}>
                            <TextField value={height} onChange={(e)=> this.heightChange(e)} margin="normal" className="form-plugin-input-white" label="Alto" fullWidth/>
                        </Col>
                        <Col md={12}>
                            <span className={classes.text}>Arrastra una imagen al recuadro azul</span>
                        </Col>
                        <Col md={12}>
                            <span className={classes.text}>ó</span>
                        </Col>
                        <Col md={12}>
                            <span className={classes.text}>Usa una url</span>
                        </Col>

                        <Col md={12}>
                            <TextField value={url} onChange={(e)=> this.processUrl(e.target.value)} margin="normal" className="form-plugin-input-white" label="Url de la imagen" fullWidth/>
                        </Col>

                    </Row>
                </BottomToolbar>
            </div>

        )
    }
    showItems(){
        const {url,width,height} = this.state;
        const {classes} = this.props;
        return (
            <div>
                <Row className={["form-plugin",classes.imageFrameContainer].join(' ')}>
                    <Col md={12} >
                        <Row center="xs">
                            {url.length>0 && this.validURL(url) ? <img src={url} width={width} height={height} alt={url}/>:<Icon>web</Icon>}
                        </Row>
                    </Col>
                </Row>
            </div>

        )
    }


    onDragEnd(){
        this.setState({dragOver:false});
    }

    dragOver(ev){
        ev.stopPropagation();
        ev.preventDefault();
        this.setState({dragOver:true})
    }

    onDrop(ev) {
        ev.preventDefault();
        let image = ev.dataTransfer.files[0];

        if(image && image.type.indexOf('image') > -1){
            let api = new ApiHelper();
            let token = localStorage.getItem('token');
            api.post('lesson/images',{image:image}, token).then(({data}) => {
                this.processUrl(data.url);
            });
        }else{
            Toast('Algo salio mal, vuelve a intentarlo','error');
        }
    }

    widthChange(e){
        let width = e.target.value;
        this.setState({width},()=>{
            this.onChange();
        });
    }

    heightChange(e){
        let height = e.target.value;
        this.setState({height},()=>{
            this.onChange();
        });
    }

    processUrl(url){

        this.setState({url},()=>{
            this.onChange();
        });

        this.setState({dragOver:false});
    }


    validURL(str) {
        let regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;
        return regex.test(str);
    }

}

export default withStyles(imageFrameStyles)(ImageFrame);
