import React from 'react'

import Icon from '@material-ui/core/Icon';
import ImageFrame from "./ImageFrame";

export default {
    Component: ImageFrame,
    IconComponent: <Icon>add_photo_alternate</Icon>,
    name: 'imageFrame',
    version: '0.0.1',
    text: 'Imagen',
    description: 'Agrega una imagen.',
}