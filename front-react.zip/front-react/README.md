**Instrucciones**

Ejecutar el comando:

**npm install**
**npm run build**

Este ultimo comando genera una carpeta llamada build que contiene todo el html y assets para produccion.

Para testear la aplicacion en un entorno de desarrollo (local) usar el comando:

**npm start**

Este comando iniciara automaticamente un servidor, la aplicacion (core) esta dentro de la carpeta src.


En el archivo package.json se encuentran todas las dependencias de la aplicacion.
una vez se tenga el dominio hay que cambiar la linea que dice "homepage":"aqui poner el dominio con subcarpetas si es que las hay"