<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::group(['prefix' => 'user'],function (){
    Route::post('/login', 'Api\PassportController@login')->name('user.login');
    Route::post('/register', 'Api\PassportController@register')->name('user.register');
    Route::post('/password/email', 'Api\ForgotPasswordController@sendResetLinkEmail')->name('send.mail');
    Route::post('/password', 'Api\ResetPasswordController@reset')->name('user.password.reset');
    Route::post('/facebook/login','Api\FacebookController@login');
    Route::post('/google/login','Api\GoogleController@login');
});



Route::group(['middleware' => ['auth:api','permissions','methods']], function(){
    Route::post('lesson/images','Api\LessonController@uploadImage')->name('lesson.image.upload');
    Route::get('/achievements', 'Api\AchievementController@index')->name('achievement.index');
    Route::get('/achievements/won', 'Api\AchievementController@won')->name('achievement.won.index');
    Route::get('/achievements/{achievement}', 'Api\AchievementController@show')->name('achievement.show');

    Route::group(['prefix' => 'user'],function (){

        Route::put('{user}/status','Api\UserController@changeStatus')->name('user.update.status');
        Route::put('/u','Api\UserController@update')->name('user.update');
        Route::put('/notifications/token','Api\UserController@updateDevice')->name('user.updateDevice');
        Route::get('/', 'Api\UserController@show')->name('user.show');

        Route::get('/stats','Api\UserController@stats')->name('user.stats');

        Route::put('/password/u','Api\UserController@changePassword')->name('user.update.password');
        Route::post('/password/a', 'Api\ResetPasswordController@reset')->name('user.password.reset.first');

        Route::put('/image','Api\UserController@uploadImage')->name('user.update.image');

        Route::put('/space/u','Api\SpaceController@update')->name('space.update');
        Route::get('/space','Api\SpaceController@index')->name('space.index');


        Route::get('/achievements', 'Api\UserAchievementController@index')->name('achievements.index');
        Route::get('/notifications', 'Api\NotificationController@index')->name('notifications.index');
        Route::put('/notification/{notification}', 'Api\NotificationController@update')->name('notifications.update');
        Route::put('/notifications/', 'Api\NotificationController@updateAll')->name('notifications.updateAll');
        Route::put('/grade-group/', 'Api\GradeGroupsController@assign')->name('user.grade_group.assign');
        Route::delete('/grade-group/d', 'Api\GradeGroupsController@remove')->name('user.grade_group.remove');
    });


    Route::apiResource('/courses','Api\CourseController');
    Route::delete('/courses/d','Api\CourseController@massiveDelete')->name('courses.delete.massive');
    Route::apiResource('/plugins','Api\ExternalPluginController');

    Route::get('course-categories','Api\CourseCategoriesController@index')->name('course.categories.index');
    Route::get('course-category/slug/{category}','Api\CourseCategoriesController@showSlug')->name('course.categories.show');

    Route::get('/lessons/{lesson}','Api\LessonController@show')->name('course.lesson.show');
    Route::put('/lessons/{lesson}/u','Api\LessonController@update')->name('course.lesson.update');

    Route::group(['prefix' => 'courses'],function (){

        Route::get('/slug/{courseSlug}/lesson/{lessonSlug}','Api\LessonController@getByCourse')->name('course.slug.lesson.show');
        Route::get('/slug/{slug}','Api\CourseController@getBySlug')->name('course.slug.show');
        Route::apiResource('categories','Api\CategoryController',['only' => ['show','index']]);
        Route::apiResource('{course}/lessons','Api\LessonController',['only' => ['show','index','store']]);
        Route::get('/presentation','Api\CourseController@presentation')->name('courses.presentation');
        Route::get('/advances','Api\CourseController@advances')->name('courses.advances');
        Route::get('/comparative','Api\CourseController@comparative')->name('courses.comparative');

        Route::apiResource('/categories','Api\CourseCategoriesController');

        Route::group(['prefix' => 'lessons','as' => 'lessons.'],function () {
            Route::put('/{lesson}','Api\LessonController@viewLesson')->name('lesson.view');
            Route::delete('/d','Api\LessonController@massiveDelete')->name('delete.massive');
            Route::apiResource('/types', 'Api\LessonTypesController');
        });
    });

    Route::get('/sessions/last','Api\SessionController@last')->name('sessions.last');
    Route::get('/sessions','Api\SessionController@index')->name('sessions.index');
    Route::post('/session','Api\SessionController@store')->name('sessions.store');
    Route::get('/session/{session}','Api\SessionController@show')->name('sessions.show');
    Route::get('/session/{session}/lessons','Api\SessionController@lessons')->name('sessions.lessons.index');

    Route::put('/session/{session}/slider','Api\SessionController@setSlider')->name('sessions.update.slider');
    Route::put('/session/{session}/lesson','Api\SessionController@setLesson')->name('sessions.update.lesson');
    Route::put('/session/{session}','Api\SessionController@changeStatus')->name('sessions.status');

    Route::get('/grade-groups','Api\GradeGroupsController@index')->name('gradegroups.index');
    Route::get('/grades','Api\GradeGroupsController@grades')->name('grades.index');
    Route::get('/groups','Api\GradeGroupsController@groups')->name('groups.index');
    Route::post('/grade-group','Api\GradeGroupsController@store')->name('gradegroups.store');
    Route::post('/grade-group/{grade_group}','Api\GradeGroupsController@update')->name('gradegroups.update');
    Route::get('/grade-group/{grade_group}/students','Api\GradeGroupsController@students')->name('gradegroups.students.index');
    Route::delete('/grade-group/{grade_group}','Api\GradeGroupsController@delete')->name('gradegroups.delete');
    Route::post('/grade-group/{grade_group}/r','Api\GradeGroupsController@restore')->name('gradegroups.restore');

    Route::get('/courses-sessions','Api\CourseController@coursesSessions')->name('sessions.courses.index');
    Route::get('/sessions/available/{course}/{grade_group}','Api\SessionController@available')->name('sessions.available');
    Route::get('/users/students','Api\UserController@index')->name('users.students.index');
    Route::put('/users/students/{user}','Api\UserController@updateStudent')->name('users.students.update');
    Route::post('/users/students/excel','Api\UserController@uploadFromExcel')->name('users.students.excel');


});

