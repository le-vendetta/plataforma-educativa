//creación de app express y socketio
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
 //creación de cliente de redis
var redis = require('redis');
var r 	  = redis.createClient();
//conectarse al canal de redis
r.subscribe('visionaria');

io.sockets.on('connection', function(socket){
	console.log('User connection');

	//subscribirse a una sala
    socket.on('subscribe', function(room) { 
        console.log('joining room', room);//messages|action
        socket.join(room); 
    })
    //salir de una sala
    socket.on('unsubscribe', function(room) {  
        console.log('leaving room', room);
        socket.leave(room); 
    })

    
});

//cuando llega un mensaje
r.on('message', function(channel,data) {
		data = JSON.parse(data);
		let {type,room} = data;
		console.log('receiving data:', data)

        if(type === 'message'){
        	let {message,user_id,name} = data;
        	io.sockets.in(room).emit('message', {message,user_id,name});//enviar datos a una sala especifica (ver codigo de on connection)
        }

        if(type === 'action'){
        	if(data.action === 'change_page'){
	        	let {page} = data;
	        	io.sockets.in(room).emit('change_page', {page});//enviar datos a una sala especifica (ver codigo de on connection)
        	}
        }
});



http.listen(3001, function(){
  console.log('listening on *:3001');
});