**Api platform back**

Ejecutar

- composer install
- cp .env.example .env
- php artisan key:generate
- php artisan migrate --seed
- php artisan passport:install
- php artisan storage:link
- php artisan serve


php artisan crud:view courses --fields_from_file="/resources/crud-generator/crud/Courses.json" --view-path="admin" --route-group=admin --form-helper=laravelcollective
