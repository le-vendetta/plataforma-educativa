<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 27/02/2018
 * Time: 17:55
 */

namespace App\Models;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model as MasterModel;


class Model extends MasterModel
{



}