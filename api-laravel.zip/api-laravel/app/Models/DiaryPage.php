<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DiaryPage extends Model
{
    protected $fillable = ['title','content'];

    public function diary(){
        return $this->belongsTo(Diary::class);
    }

}
