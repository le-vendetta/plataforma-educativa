<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;

class UserGradeGroup extends Model
{
    protected $fillable = ['grade_group_id','user_id_created'];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function grade_group(){
        return $this->belongsTo(GradeGroup::class);
    }
}
