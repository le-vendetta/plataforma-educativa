<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LessonType extends Model
{
    protected $hidden = ['created_at','updated_at','user_id_created'];
}
