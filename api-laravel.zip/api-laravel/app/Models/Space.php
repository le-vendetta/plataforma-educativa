<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class Space extends Model
{
    protected $casts = ['settings' => 'array'];
    protected $fillable = ['settings'];

    public function getSettingsAttribute($settings){
        $settings = json_decode($settings,true);

        $settings['bg_image'] = Storage::disk('spaces')->url($settings['bg_image']);
        $settings['bg_menu_image'] = Storage::disk('spaces')->url($settings['bg_menu_image']);
        return $settings;
    }
}
