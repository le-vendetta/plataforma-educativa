<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Lesson extends Model
{
    use SoftDeletes;

    protected $appends = ['viewed','type_name','type_slug'];
    protected $hidden = ['type','created_at','updated_at','user_id_created'];
    protected $fillable = ['name','content','description'];

    public function getViewedAttribute(){
        return ViewedLesson::where('user_id',auth()->user()->id)->where('lesson_id',$this->id)->count()?true:false;
    }

    public function course(){
        return $this->belongsTo(Course::class);
    }

    public function getTypeNameAttribute(){
        return $this->type->name;
    }
    public function getTypeSlugAttribute(){
        return $this->type->slug;
    }

    public function type(){
        return $this->belongsTo(LessonType::class,'lesson_type_id');
    }
}
