<?php

namespace App\Models;

use App\CourseGradeGroup;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Storage;

class Course extends Model
{
    use SoftDeletes;

    protected $fillable = ['name','course_type','category_id','description','image','slug','user_id_created'];
    protected $hidden = ['created_at','user_id_created','category','lessons'];
    protected $appends = ['category_name','total_lessons'];
    public function getCategoryNameAttribute(){
        return $this->category->title;
    }

    public function getImageAttribute($image){
        return Storage::disk('courses')->url($image);
    }

    public function getTotalLessonsAttribute(){
        return $this->lessons()->count();
    }

    public function lessons(){
        return $this->hasMany(Lesson::class);
    }

    public function achievement(){
        return $this->hasOne(Achievement::class);
    }

    public function category(){
        return $this->belongsTo(CourseCategory::class,'category_id');
    }

}
