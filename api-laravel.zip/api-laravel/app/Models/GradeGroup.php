<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GradeGroup extends Model
{
    use SoftDeletes;

    protected $fillable = ['grade_id','group_id','category_id','user_id_created'];

    public function category()
    {
        return $this->hasOne(CourseCategory::class,'id','category_id');
    }
}
