<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;

class Session extends Model
{
    protected $hidden   = ['user'];
    protected $appends  = ['teacher','lesson_info','course_info','grade_group'];
    protected $fillable = ['user_id','grade_group_id','course_id','lesson_id','information'];
    protected $casts    = ['information' => 'array'];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function course(){
        return $this->belongsTo(Course::class);
    }

    public function lesson(){
        return $this->belongsTo(Lesson::class);
    }

    public function getTeacherAttribute(){
        $teacher = $this->user()->select('name','last_name','avatar' )->first();

        return ['name' => $teacher->name,'last_name' => $teacher->last_name,'avatar' => $teacher->avatar];
    }

    public function getLessonInfoAttribute(){
        $lesson = $this->lesson()->select('slug','name','deleted_at')->withTrashed()->first();

        return ['slug' => $lesson->slug,'name' => $lesson->name,'deleted_at' => $lesson->deleted_at];
    }

    public function getCourseInfoAttribute(){
        $course = $this->course()->select('slug','name')->first();
        return ['slug' => $course->slug,'name' => $course->name];
    }

    public function getGradeGroupAttribute(){
        $gradeGroup = $this->join('grade_groups','sessions.grade_group_id','=','grade_groups.id')
            ->join('grades','grade_groups.grade_id','=','grades.id')
            ->join('groups','grade_groups.group_id','=','groups.id')
            ->select('grades.name as grade_name','groups.name as group_name')->first();

        return ['grade_name' => $gradeGroup->grade_name,'group_name' => $gradeGroup->group_name];
    }
}
