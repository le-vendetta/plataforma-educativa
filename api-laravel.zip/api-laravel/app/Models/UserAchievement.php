<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;

class UserAchievement extends Model
{
    protected $appends = ['achievement_url'];
    protected $fillable = ['user_id','achievement_id'];

    public function achievement(){
        return $this->hasOne(Achievement::class);
    }

    public function user(){
        return $this->hasOne(User::class);
    }

    public function getAchievementUrlAttribute(){
        return route('achievement.show',$this->achievement_id);
    }
}
