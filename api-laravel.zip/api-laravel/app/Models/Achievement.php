<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Storage;

class Achievement extends Model
{
    protected $fillable = ['name','image','description'];
    public function getImageAttribute($image){
        return Storage::disk('achievement')->url($image);
    }
}
