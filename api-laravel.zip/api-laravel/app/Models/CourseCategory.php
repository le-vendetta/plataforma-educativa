<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Storage;

class CourseCategory extends Model
{
    protected $hidden = ['user_id_created','created_at','updated_at'];
    protected $appends = ['total_courses'];

    public function courses(){
        return $this->hasMany(Course::class,'category_id');
    }

    public function getImageAttribute($image){
        if($image){
            return Storage::disk('categories')->url($image);
        }
        return $image;
    }

    public function getTotalCoursesAttribute(){
        return $this->courses()->count();
    }
}
