<?php

namespace App\Http\Middleware;

use App\Models\ActionPermission;
use Closure;
use Illuminate\Support\Facades\Route;

class Permissions
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $route_name = $request->route()->getName();
        $user       = auth()->user();
        if(!$route_name){
            abort(401);
        }

        $permission = ActionPermission::where('role_id',$user->role_id)->where('route_name',$route_name)->where('status',true)->first();
        if(!$permission){
            abort(401);
        }

        return $next($request);
    }
}
