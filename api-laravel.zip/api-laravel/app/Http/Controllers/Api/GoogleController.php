<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 02/04/2018
 * Time: 10:04 AM
 */

namespace App\Http\Controllers\Api;
use App\Helpers\GoogleHelper;
use App\Http\Controllers\Controller;
use App\Models\Role;
use App\User;
use Illuminate\Http\Request;
use League\OAuth2\Server\Exception\OAuthServerException;


class GoogleController extends Controller
{



    public $key = "";
    public $helper;

    public function __construct(GoogleHelper $googleHelper)
    {
        $this->key = env('APP_KEY_TOKEN');
        $this->helper = $googleHelper;
    }

    /**
     * Logs a App\User in using a Facebook token via Passport
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     * @throws \League\OAuth2\Server\Exception\OAuthServerException
     */
    public function login(Request $request)
    {
        try {

            if ($request->get('gg_token')) {

                $client = $this->helper->get_client();
                $oauth = $this->helper->get_oauth();

                $client->fetchAccessTokenWithRefreshToken($request->get('gg_token'));
                $googleData = $oauth->userinfo->get();

                $user = User::where('uid', $googleData->id)->where('provider','google')->first();

                if (!$user) {

                    if(User::where('email',$googleData->email)->first()){
                        return $this->apiResponse([],401,['error' => 'Este correo ya esta registrado']);
                    }

                    $user = new User();
                    $user->provider     = 'google';
                    $user->uid          = $googleData->id;
                    $user->name         = $googleData->name;
                    $user->last_name    = $googleData->familyName;
                    $user->nickname     = $googleData->name;
                    $user->email        = $googleData->email;
                    $user->password     = bcrypt(uniqid('gg_', true)); // Random password.
                    $user->role_id      = Role::where('slug','user')->first()->id;
                    $user->save();
                }

                $token      = $user->createToken($this->key)->accessToken;

                return  $this->apiResponse(['token' => $token,'user' => $user]);;
            }
        } catch (\Exception $e) {
            return $this->apiResponse([],401,['error' => 'No estas autorizado para ver esto']);
        }
        return null;
    }

}