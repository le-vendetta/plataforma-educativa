<?php
/**
 * Created by Vendetta.
 * User: Vendetta
 * Date: 16/07/2018
 * Time: 07:01 PM
 * The best ;)
 */

namespace App\Http\Controllers\Api;


use App\Helpers\GradeGroupsHelper;
use App\Http\Controllers\Controller;
use App\Models\CourseCategory;
use App\Models\Grade;
use App\Models\GradeGroup;
use App\Models\Group;
use App\Models\UserGradeGroup;
use App\User;
use DB;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;

class GradeGroupsController extends Controller
{
    private $helper;
    public function __construct(GradeGroupsHelper $helper)
    {
        $this->helper = $helper;
    }


    public function index()
    {
        try{
            return $this->apiResponse(['grade_groups' => $this->helper->getGradeGroups()]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }

    public function store(Request $request)
    {
        $this->validate($request,['grade_name' => 'required','group_name' => 'required','category' => 'required']);
        $user = auth()->user();

        $category = CourseCategory::findOrFail($request->category);

        DB::beginTransaction();
        try{
            $grade          = Grade::firstOrCreate(['name' => $request->grade_name],['user_id_created' => $user->id]);
            $group          = Group::firstOrCreate(['name' => $request->group_name],['user_id_created' => $user->id]);

            $grade_group    = GradeGroup::create(['grade_id' => $grade->id,'group_id' => $group->id,'category_id' => $category->id,'user_id_created' => $user->id]);

            DB::commit();
            $gg = ['grade_name' => $grade->name,'group_name' => $group->name,'id' => $grade_group->id,'category_id' => $category->id];
            return $this->apiResponse(['grade_group' => $gg]);
        }catch (\Exception | QueryException $e){
            DB::rollBack();
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }

    public function update(Request $request,GradeGroup $grade_group)
    {
        $this->validate($request,['grade_name' => 'required','group_name' => 'required','category' => 'required']);

        DB::beginTransaction();

        try{
            $grade    = Grade::where(['name' => $request->grade_name])->first();

            if(!$grade){
                Grade::where(['id' => $grade_group->grade_id])->update(['name' => $request->grade_name]);
            }else{
                $grade_group->grade_id = $grade->id;
            }

            $group    = Group::where(['name' => $request->group_name])->first();

            if(!$group){
                Group::where(['id' => $grade_group->group_id])->update(['name' => $request->group_name]);
            }else{
                $grade_group->group_id = $group->id;
            }

            if($grade_group->category->id !== $request->category){
                $category = CourseCategory::findOrFail($request->category);

                $grade_group->category_id = $request->category;
            }

            $grade_group->save();

            DB::commit();

            $gg = ['grade_name' => $request->grade_name,'group_name' => $request->group_name,'id' => $grade_group->id,'category_id' => intval($request->category)];

            return $this->apiResponse(['grade_group' => $gg]);
        }catch (\Exception | QueryException $e){
            DB::rollBack();
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }


    public function assign(Request $request){
        $assign = $this->helper->assign($request->user,$request->grade_group);

        return $this->apiResponse(['message' => 'ok','new' => $assign['new'],'spaces' => $assign['spaces']]);
    }

    public function remove(Request $request){
        UserGradeGroup::where('user_id',$request->user)
            ->where('grade_group_id',$request->grade_group)->update(['status' => false]);

        return $this->apiResponse(['message' => 'ok']);
    }

    public function students(GradeGroup $grade_group){
        return $this->apiResponse(['students' => $this->helper->students($grade_group)]);
    }

    public function grades()
    {
        return $this->apiResponse(['grades' => Grade::all()]);
    }

    public function groups(){
        return $this->apiResponse(['groups' => Group::all()]);
    }

    public function delete(GradeGroup $grade_group){
        $grade_group->delete();

        return $this->apiResponse(['msg' => 'ok']);
    }

    public function restore(Request $request){
        $grade_group = GradeGroup::withTrashed()->where('id', $request->grade_group)->first();
        if($grade_group->trashed()){
            $grade_group->restore();
        }

        return $this->apiResponse(['msg' => 'ok']);

    }
}