<?php

namespace App\Http\Controllers\Api;

use App\Models\Space;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class SpaceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $space = auth()->user()->space;

        if(!$space){
            $space = auth()->user()->space()->save(
                new Space(['settings' =>
                    ['bg_mage'=>env('DEFAULT_BG_IMAGE')],
                    ['bg_menu_mage'=>env('DEFAULT_BG_IMAGE')]
                ])
            );
        }

        return $this->apiResponse(['space' => $space->settings]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        try{
            $space      = auth()->user()->space;
            $settings   = json_decode($space->getOriginal('settings'),true);

            $upImg = $this->updateBgImage($request,$space,$settings);

            if($upImg){
                return $upImg;
            }

            $upImg = $this->updateBgMenuImage($request,$space,$settings);

            if($upImg){
                return $upImg;
            }

            return $this->apiResponse(['space' => $space->settings]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],402,['error' => $e->getMessage()]);
        }

    }

    private function updateBgMenuImage($request,$space,$settings){

        if($request->has('bg_menu_image') && $request->bg_menu_image){

            $image = $this->updateImage($request->bg_menu_image);
            if($image['upload']){
                $this->deleteMenuImage($space);

                $settings['bg_menu_image'] = $image['name'];

                $space->settings = $settings;
                $space->save();

                return $this->apiResponse(['space' => $space->settings]);
            }

            return $this->apiResponse([],422,['error' => 'No ha sido posible subir la imagen']);
        }
    }

    private function updateBgImage($request,$space,$settings){

        if($request->has('bg_image') && $request->bg_image){
            $image = $this->updateImage($request->bg_image);
            if($image['upload']){
                $this->deleteImage($space);

                $settings['bg_image'] = $image['name'];

                $space->settings = $settings;

                $space->save();

                return $this->apiResponse(['space' => $space->settings]);
            }

            return $this->apiResponse([],422,['error' => 'No ha sido posible subir la imagen']);
        }
    }

    private function updateImage($image){
        $extension  = explode('.',$image->getClientOriginalName());
        $extension  = array_pop($extension);
        $name       = time().'.'.$extension;

        $done = Storage::disk('spaces')->put($name,file_get_contents($image -> getRealPath()));

        return ['name' => $name,'upload' => $done];
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    private function deleteImage(Space $space){
        $settings = json_decode($space->getOriginal('settings'),true);
        Storage::disk('spaces')->delete($settings['bg_image']);
    }

    private function deleteMenuImage(Space $space){
        $settings = json_decode($space->getOriginal('settings'),true);
        Storage::disk('spaces')->delete($settings['bg_menu_image']);
    }
}
