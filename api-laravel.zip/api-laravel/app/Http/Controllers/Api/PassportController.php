<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 28/02/2018
 * Time: 16:36
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Models\Role;
use App\User;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class PassportController extends Controller
{
    public $key = "";

    public function __construct()
    {
        $this->key = env('APP_KEY_TOKEN');
    }

    /**
     * login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(){

        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){

            $user               = Auth::user();

            $token              = $user->createToken($this->key)->accessToken;

            $user->{"token"}    = $token;
            return $this->apiResponse(['token' => $token,'user' => $user]);
        }
        return $this->apiResponse([],401,['error' => 'Datos incorrectos']);
    }

    /**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */
    public function register(UserRequest $request)
    {
        try{
            $input              = $request->validated();
            $input['password']  = bcrypt($input['password']);
            $user               = $this->getDefaultRole()->users()->save(new User($input));
            $token              = $user->createToken($this->key)->accessToken;

            return response()->json(['data' => compact('user','token')], 200);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],402,['error' => $e->getMessage()]);
        }

    }

    /**
     * details api
     *
     * @return \Illuminate\Http\Response
     */
    public function getUser()
    {
        $user = Auth::user();
        return $this->apiResponse(compact('user'));
    }

    private function getDefaultRole(){
        return Role::where('name','normal')->first();
    }
}