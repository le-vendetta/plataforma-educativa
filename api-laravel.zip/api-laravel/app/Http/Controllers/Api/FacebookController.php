<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 28/03/2018
 * Time: 02:36 PM
 */

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use App\Models\Role;
use App\User;
use Facebook\Facebook;
use Illuminate\Http\Request;
use League\OAuth2\Server\Exception\OAuthServerException;

class FacebookController extends Controller
{
    public $key = "";

    public function __construct()
    {
        $this->key = env('APP_KEY_TOKEN');
    }

    /**
     * Logs a App\User in using a Facebook token via Passport
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     * @throws \League\OAuth2\Server\Exception\OAuthServerException
     */
    public function login(Request $request)
    {
        try {

            if ($request->get('fb_token')) {

                $fb = new Facebook([
                    'app_id' => config('facebook.app.id'),
                    'app_secret' => config('facebook.app.secret'),
                    'default_graph_version' => 'v2.5',
                ]);

                $fb->setDefaultAccessToken($request->get('fb_token'));

                $response   = $fb->get('/me?locale=en_GB&fields=first_name,last_name,email,name');
                $fbUser     = $response->getDecodedBody();

                $user = User::where('uid', $fbUser['id'])->where('provider','facebook')->first();

                if (!$user) {

                    if(User::where('email',$fbUser['email'])->first()){
                        return $this->apiResponse([],401,['error' => 'Este correo ya esta registrado']);
                    }

                    $user = new User();
                    $user->provider     = 'facebook';
                    $user->uid          = $fbUser['id'];
                    $user->name         = $fbUser['first_name'];
                    $user->last_name    = $fbUser['last_name'];
                    $user->nickname     = $fbUser['name'];
                    $user->email        = $fbUser['email'];
                    $user->password     = bcrypt(uniqid('fb_', true)); // Random password.
                    $user->role_id      = Role::where('slug','user')->first()->id;
                    $user->save();
                }

                $token      = $user->createToken($this->key)->accessToken;

                return  $this->apiResponse(['token' => $token,'user' => $user]);;
            }
        } catch (\Exception $e) {
           return $this->apiResponse([],401,['error' => 'No estas autorizado para ver esto']);
        }
        return null;
    }
}