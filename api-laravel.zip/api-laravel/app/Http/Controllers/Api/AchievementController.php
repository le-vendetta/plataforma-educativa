<?php

namespace App\Http\Controllers\Api;

use App\Helpers\AchievementHelper;
use App\Models\Achievement;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

class AchievementController extends Controller
{
    private $helper;

    public function __construct(AchievementHelper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        return $this->apiResponse(['achievements' => $this->helper->getAchievements()]);
    }

    public function won()
    {
        return $this->apiResponse(['achievements' => $this->helper->getWonAchievements()]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Achievement $achievement)
    {
        return $this->apiResponse(['achievement' => $achievement]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
