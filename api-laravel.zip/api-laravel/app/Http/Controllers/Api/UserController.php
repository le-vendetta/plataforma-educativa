<?php

namespace App\Http\Controllers\Api;

use App\Helpers\StatsHelper;
use App\Helpers\UserHelper;
use App\Http\Requests\UpdateStudentRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\GradeGroup;
use App\Models\Role;
use App\Models\UserGradeGroup;
use App\User;
use DB;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Reader\Exception;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use Validator;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    private $stats,$helper;
    public function __construct(StatsHelper $statsHelper,UserHelper $userHelper)
    {
        $this->stats = $statsHelper;
        $this->helper = $userHelper;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        return $this->apiResponse(['users' => $this->helper->getUsers()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        $user = Auth::user();
        return $this->apiResponse(compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUserRequest $request)
    {
        auth()->user()->update($request->only('name','last_name','nickname'));

        return $this->apiResponse(['user' => auth()->user()]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateStudent(UpdateStudentRequest $request,User $user)
    {
        $this->authorize('updateStudent',$user);
        $data = $request->only('nickname','name','last_name','email');

        if($request->password){
            $data['password'] = bcrypt($request->password);
        }

        $user->update($data);
        unset($data['password']);
        return $this->apiResponse(['user' => $data]);
    }

    public function changePassword(Request $request){
        $request->validate([
            'password'                  => 'required|bail',
            'new_password'              => 'required|confirmed',
        ]);


        if(Hash::check($request->password, auth()->user()->password)) {

            auth()->user()->update(['password' => bcrypt($request->new_password)]);

            return $this->apiResponse(['user' => auth()->user()]);
        }

        return $this->apiResponse([],401,['password' => 'Contraseña incorrecta']);
    }

    public function uploadImage(Request $request){

        try{
            if ($request->has('avatar') && $request->avatar) {

                $image      = $request->avatar;
                $extension  = explode('.',$image->getClientOriginalName());
                $extension  = array_pop($extension);
                $name       = time().'.'.$extension;

                $done = Storage::disk('avatars')->put($name,file_get_contents($image -> getRealPath()));

                if($done){
                    auth()->user()->update(['avatar' => $name]);
                    return $this->apiResponse(['user' => auth()->user()]);
                }
                return $this->apiResponse([],422,['error' => 'No ha sido posible subir la imagen']);
            }

            return $this->apiResponse([],422,['error' => 'Ocurrio un error']);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],402,['error' => $e->getMessage()]);
        }
    }

    public function stats(){

        try{
            return $this->apiResponse(['stats' => $this->stats->getStats()]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],402,['error' => $e->getMessage()]);
        }

    }


    public function updateDevice(Request $request){
        $user = auth()->user();

        if($request->has('web_device') && $request->get('web_device') && $request->web_device != $user->web_device){
            $user->web_device = $request->get('web_device');
            $user->save();
            return $this->apiResponse(['message' => 'ok']);
        }

        if($request->has('mobile_device') && $request->get('mobile_device') && $request->mobile_device != $user->mobile_device){
            $user->mobile_device = $request->get('mobile_device');
            $user->save();

            return $this->apiResponse(['message' => 'ok']);
        }

        return $this->apiResponse([],402,['error' => 'Faltan datos']);
    }

    public function changeStatus(Request $request){
        $user = User::withTrashed()->find($request->user);
        if($user->trashed()){
            $user->restore();
        }else{
            try {
                $user->delete();
            } catch (\Exception $e) {
                return $this->apiResponse([],401,['error' => 'Algo salio mal']);
            }
        }

        return $this->apiResponse(['user' => $user]);
    }

    public function uploadFromExcel(Request $request)
    {
        $request->grade_group = 1;
        $grade_group    = GradeGroup::findOrFail($request->grade_group);
        $user           = auth()->user();
        $file           = Storage::disk('formats')->getDriver()->getAdapter()->getPathPrefix();
        $sex            = ['m' => 'masculino','f' => 'femenino'];

        $role   = Role::where('slug','student')->first();
        DB::beginTransaction();
        try {
            if($request->has('file') && $request->file){
                $filename = $this->uploadFileFormats($request->file);

                $filename = $file.'/'.$filename;

                $reader    = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($filename);

                $reader->setReadDataOnly(true);

                $spreadsheet  = $reader->load($filename);

                $students       = $spreadsheet->getActiveSheet()->toArray();

                array_shift($students);

                $students       = $this->helper->getNewUsers(/*$students*/[['pedrito','last_name','gender','email@email.com','password'],['name','last_name','gender','sss@sss.com','password']]);

                $check          = $this->helper->checkLimit($grade_group->id,count($students));

                if($check !== true){
                    return $this->apiResponse([],401,['error' => "Alcansaste el limite de usuarios por habilidad, quedan $check espacios"]);
                }

                $insert = [];

                foreach ($students as $student){

                    if(in_array($student['gender'],$sex)){
                        $student['gender'] = $sex[$student['gender']];
                    }else{
                        $student['gender'] = 'masculino';
                    }

                    $student['password']    = bcrypt($student['password']);
                    $student['role_id']     = $role->id;
                    $student['nickname']    = str_slug($student['name'].' '.$student['last_name']);
                    $student['provider']    = 'web';
                    $student['created_at']  = date('Y-m-d H:i:s');
                    $insert[]               = $student;
                }

                $u_insert = User::insert($insert);

                $users          = User::whereIn('email',array_column($insert,'email'))->select('id','email','name')->get();
                $grade_groups   = [];
                $result         = [];

                foreach ($users as $student){
                    $result[]       = ['id'=>$student->id,'email'=>$student->email,'name' => $student->name,'grade_group' => "".$grade_group->id,'deleted_at' => null];
                    $grade_groups[] = ['user_id' => $student->id,'grade_group_id' => $grade_group->id,'user_id_created' => $user->id,'created_at' => date('Y-m-d H:i:s')];
                }

                $ugg_insert = UserGradeGroup::insert($grade_groups);

                DB::commit();
                return $this->apiResponse(['users' => $result]);
            }
            return $this->apiResponse([],401,['error' => 'Archivo incorrecto.']);

        } catch (Exception | \PhpOffice\PhpSpreadsheet\Exception $e) {
            DB::rollback();
            return $this->apiResponse([],500,['error' => 'Ha ocurrido un error vuelve a intentarlo.']);
        }


    }

    private function uploadFileFormats($file)
    {
        $extension  = explode('.',$file->getClientOriginalName());
        $extension  = array_pop($extension);
        $filename   = uniqid().'.'.$extension;

        Storage::disk('formats')->put($filename,file_get_contents($file -> getRealPath()));

        return $filename;
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
