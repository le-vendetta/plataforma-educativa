<?php

namespace App\Http\Controllers\Api;

use App\Models\CourseCategory;
use App\Models\GradeGroup;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CourseCategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = auth()->user();
        if($user->role->slug == 'admin'){
            $categories = CourseCategory::all();
        }else{
            $categories = CourseCategory::find(GradeGroup::whereIn('id',$user->grade_group->pluck('grade_group_id'))->pluck('category_id'));
        }
        return $this->apiResponse(compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showSlug($category)
    {
        $category = CourseCategory::where('slug',$category)->firstOrFail();

        return $this->apiResponse(compact('category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
