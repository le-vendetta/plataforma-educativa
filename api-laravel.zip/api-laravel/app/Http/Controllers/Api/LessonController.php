<?php

namespace App\Http\Controllers\Api;

use App\Helpers\AchievementHelper;
use App\Http\Requests\LessonRequest;
use App\Models\Course;
use App\Models\Lesson;
use App\Models\Session;
use App\Models\ViewedLesson;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Storage;

class LessonController extends Controller
{
    private $achievements;

    public function __construct(AchievementHelper $achievementHelper)
    {
        $this->achievements = $achievementHelper;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Course $course)
    {

        $result = $course->lessons()->get();
        $result->transform(function($i) {
            unset($i->content);
            return $i;
        });
        return $this->apiResponse(['lessons' => $result]);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Lesson $lesson)
    {
        return $this->apiResponse(['lesson' => $lesson]);
    }

    public function store(Course $course, LessonRequest $request){
        $lesson                     = new Lesson($request->validated());
        $lesson->user_id_created    = auth()->user()->id;
        $lesson->slug               = str_slug($lesson->name);
        $lesson->lesson_type_id     = 1;

        $course->lessons()->save($lesson);

        return $this->apiResponse(['lesson' => $lesson]);
    }

    public function update(Lesson $lesson, LessonRequest $request){
        $data = $request->validated();
        if($lesson->name != $request->name){
            $data['slug'] = str_slug($lesson->name);
        }

        $data['user_id_created']    = auth()->user()->id;
        $data['lesson_type_id']     = 1;

        $lesson->update($data);

        return $this->apiResponse(['lesson' => $lesson]);
    }

    public function uploadImage(Request $request)
    {
        $request->validate([
            'image'                  => 'required|image',
        ]);
        try{
            if ($request->has('image') && $request->image) {

                $image      = $request->image;
                $extension  = explode('.',$image->getClientOriginalName());
                $extension  = array_pop($extension);
                $name       = time().'.'.$extension;

                $done = Storage::disk('lessons')->put($name,file_get_contents($image -> getRealPath()));

                if($done){
                    return $this->apiResponse(['url' => Storage::disk('lessons')->url($name)]);
                }

                return $this->apiResponse([],422,['error' => 'No ha sido posible subir la imagen']);
            }

            return $this->apiResponse([],422,['error' => 'Ocurrio un error']);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],402,['error' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getByCourse($course,$lesson)
    {
        $course = Course::where('slug',$course)->first();
        $this->authorize('show',$course);

        if(!$course){
            abort(404);
        }

        $lesson = Lesson::where('slug',$lesson)->first();

        if(!$lesson){
            abort(404);
        }

        if($lesson->course_id != $course->id){
            abort(400);
        }
        return $this->apiResponse(['lesson' => $lesson]);
    }

    public function viewLesson(Lesson $lesson){

        DB::beginTransaction();
        try{
            $viewdLesson = ViewedLesson::firstOrcreate(['user_id' => auth()->user()->id,'lesson_id' => $lesson->id]);
            $achievement = [];

            if($viewdLesson->wasRecentlyCreated){
                $achievement = $this->achievements->checkAchievement($lesson);
                DB::commit();
            }
            return $this->apiResponse(['lesson' => $lesson->fresh(),'achievement' => $achievement]);
        }catch (\Exception | QueryException $e){
            DB::rollback();
            return $this->apiResponse([],402,['error' => $e->getMessage()]);
        }

    }


    public function massiveDelete(Request $request){
        $ids = explode(',',$request->lessons);

        Lesson::whereIn('id',$ids)->delete();

        DB::table('sessions as ss')
            ->update(['lesson_id' => DB::raw('
            (
              CASE WHEN (SELECT ls.id FROM
                lessons AS ls 
            WHERE
                ls.course_id = ss.course_id
                AND ls.id > ss.lesson_id
                AND ls.deleted_at IS NULL 
                LIMIT 1 ) IS NULL 
                                        THEN ss.lesson_id
                                        ELSE (SELECT ls.id FROM
                lessons AS ls 
            WHERE
                ls.course_id = ss.course_id
                AND ls.id > ss.lesson_id
                AND ls.deleted_at IS NULL 
                LIMIT 1 ) END
                ) 
            ')])
            ->whereIn('lesson_id',$ids);


        Session::whereIn('lesson_id',$ids)->update(['status',false]);

        return $this->apiResponse(['msg' => 'ok']);

    }

}
