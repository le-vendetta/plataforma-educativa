<?php

namespace App\Http\Controllers\Api;

use App\Helpers\CourseHelper;
use App\Models\Course;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Storage;

class CourseController extends Controller
{
    private $helper;
    private $storage;

    public function __construct(CourseHelper $courseHelper)
    {
        $this->helper = $courseHelper;
        $this->storage = Storage::disk('courses');

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try{
            return $this->apiResponse(['courses' => $this->helper->getCourses()]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }

    public function presentation(){
        return $this->apiResponse(['courses' => Course::orderBy('created_at','desc')->take(1)->get()]);
    }

    public function advances(){
        return $this->apiResponse(['advances' => $this->helper->getAdvances()]);

    }

    public function comparative(){
        return $this->apiResponse(['comparative' => $this->helper->getComparative()]);

    }

    public function coursesSessions()
    {
        try{
            return $this->apiResponse(['courses' => $this->helper->getCousesSessions()]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Course $course)
    {
        return $this->apiResponse(['course' => $course]);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'name'          => 'required',
            'course_type'   => 'required',
            'category_id'   => 'required',
            'description'   => 'required'
        ]);

        $requestData                        = $request->all();
        $requestData['slug']                = str_slug($requestData['name']);
        $requestData['user_id_created']     = 1;

        $this->updateImage($request,$requestData);

        $course  = Course::create($requestData);

        return $this->apiResponse(['course' => $course]);
    }

    public function update(Course $course,Request $request)
    {
        $this->validate($request,[
            'name' => 'required',
            'course_type' => 'required',
            'category_id' => 'required',
            'description' => 'required'
        ]);

        $requestData = $request->all();

        $this->removePreviousImage($course);

        $this->updateImage($request,$requestData);

        $course->update($requestData);

        return $this->apiResponse(['course' => $course]);
    }

    public function massiveDelete(Request $request){
        $ids = explode(',',$request->courses);

        Course::whereIn('id',$ids)->delete();

        return $this->apiResponse(['msg' => 'ok']);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function getBySlug($slug)
    {
        $course = Course::where('slug',$slug)->first();

        if(!$course){
            abort(404);
        }

        return $this->apiResponse(['course' => $course]);
    }

    private function updateImage($request,&$data){
        if ($request->image && trim($request->image)) {

            $extension  = explode('.',$request->image->getClientOriginalName());
            $extension  = array_pop($extension);
            $filename   = uniqid().'.'.$extension;

            $file = $this->storage->put($filename,file_get_contents($request->image -> getRealPath()));
            $data['image'] = $filename;
        }else{
            unset($data['image']);
        }
    }

    private function removePreviousImage(Course $course){
        if($course->getOriginal('image') !== 'course.png'){
            $this->storage->delete($course->getOriginal('image'));
        }

    }
}
