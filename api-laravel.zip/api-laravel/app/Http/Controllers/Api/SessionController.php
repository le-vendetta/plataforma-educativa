<?php

namespace App\Http\Controllers\Api;

use App\Helpers\SessionHelper;
use App\Models\Course;
use App\Models\GradeGroup;
use App\Models\Lesson;
use App\Models\Session;
use App\Models\UserGradeGroup;
use DB;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redis;

class SessionController extends Controller
{
    private $helper;
    public function __construct(SessionHelper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try{
            return $this->apiResponse(['sessions' => $this->helper->getSessions()]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function last()
    {
        try{
            return $this->apiResponse(['sessions' => $this->helper->getSessions(4)]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }

    public function available(Course $course,GradeGroup $gradeGroup)
    {
        try{

            return $this->apiResponse(['available' => $this->helper->isAvailable($course->id,$gradeGroup->id)]);
        }catch (\Exception | QueryException $e){
            return $this->apiResponse([],400,['error' => $e->getMessage()]);
        }
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user           = auth()->user();
        $course         = Course::findOrFail($request->course);
        $grade_group    = GradeGroup::findOrFail($request->grade_group);

        $ugg            = UserGradeGroup::where('user_id',$user->id)
            ->where('grade_group_id',$grade_group->id)->first();

        if(!$ugg)
            abort(401);

        $lesson         = $course->lessons()->first();

        Session::where('grade_group_id',$grade_group->id)->update(['status' => false]);

        $session        = Session::firstOrCreate(
            ['user_id' => $user->id,'grade_group_id' => $grade_group->id,'course_id' => $course->id],
            ['lesson_id' => $lesson->id,'information' => ['slider' => 0]]);

        $session->status = true;

        $session->save();

        return $this->apiResponse(['session' => $session]);
    }

    public function setSlider(Session $session, Request $request)
    {
        $information            = $session->information;
        $information['slider']  = intval($request->slider);

        $session->information = $information;

        $session->save();

        $type = $session->lesson->type->slug;

        Redis::publish('visionaria', json_encode(['room' => "session-{$session->grade_group_id}-{$type}",'type' => 'action','action' => 'change_page','page' => intval($request->slider)]));

        return $this->apiResponse(['message' => 'ok']);
    }

    public function setLesson(Session $session, Request $request)
    {
        $lesson = Lesson::findOrFail($request->lesson);

        $session->lesson_id     = $lesson->id;
        $session->information   = ['slider' => 0];
        $session->save();

        return $this->apiResponse(['message' => 'ok']);
    }

    public function changeStatus(Session $session)
    {
        if(!$session->status){
            Session::where('grade_group_id',$session->grade_group_id)->update(['status' => false]);
        }

        $session->status = !$session->status;

        $session->save();

        return $this->apiResponse(['session' => $session]);
    }

    public function lessons(Session $session)
    {
        return $this->apiResponse(['lessons' => $this->helper->getLessons($session)]);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Session $session)
    {
        if($session->user_id !== auth()->user()->id){
            abort(401);
        }

        return $this->apiResponse(['session' => $session]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
