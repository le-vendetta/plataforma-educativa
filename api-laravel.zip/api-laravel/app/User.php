<?php

namespace App;

use App\Models\Notification;
use App\Models\Payment;
use App\Models\Role;
use App\Models\Session;
use App\Models\Space;
use App\Models\UserAchievement;
use App\Models\ViewedLesson;
use App\Models\UserGradeGroup;
use App\Notifications\ResetPasswordLinkNotification;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Storage;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use Notifiable,HasApiTokens,SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','uid', 'last_name','nickname','provider','avatar','role_id','provider'
    ];
    protected $appends = ['role_key'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token','created_at','updated_at','role'
    ];

    public function role(){
        return $this->belongsTo(Role::class);
    }

    public function getRoleKeyAttribute(){
        return $this->role->slug;
    }

    public function space(){
        return $this->hasOne(Space::class);
    }


    public function grade_group(){
        return $this->hasMany(UserGradeGroup::class);
    }

    public function achievements(){
        return $this->hasMany(UserAchievement::class);
    }

    public function getAvatarAttribute($avatar){
        return Storage::disk('avatars')->url($avatar);
    }

    public function getLessonsViewedAttribute($course_id){
        return ViewedLesson::where('user_id',$this->id)->where('course_id',$course_id)->count();
    }

    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }

    public function lessons(){
        return $this->hasMany(ViewedLesson::class);
    }

    public function sessions(){
        return $this->hasMany(Session::class);
    }


    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPasswordLinkNotification($token));
    }

    public function attachRole($role){
        $this->update(['provider' => $role]);
    }
}
