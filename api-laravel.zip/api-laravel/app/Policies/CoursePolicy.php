<?php

namespace App\Policies;

use App\Helpers\SettingsHelper;
use App\Models\Course;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class CoursePolicy
{
    use HandlesAuthorization;

    private $settings;
    public function __construct(SettingsHelper $helper)
    {
        $this->settings = $helper->get();
    }

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function show(User $user, Course $course){
        $result = true;

        if(in_array($user->role->slug,['admin','teacher'])){
            return true;
        }

        if($this->settings->have_grade_groups){//si hay grados y grupos
            if(!$user->grade_group){//si el usuario no tiene un grado y grupo
                return false;
            }

            $grade = $course->grade_groups()->where('grade_group_id',$user->grade_group->grade_group_id)->get();

            $result = $grade->count()?true:false;//si el curso fue hecho para ese grado y grupo
        }

        return $result;
    }
}
