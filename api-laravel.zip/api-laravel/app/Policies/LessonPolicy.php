<?php

namespace App\Policies;

use App\Models\Course;
use App\Models\Lesson;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class LessonPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function belongsTo(User $user,Lesson $lesson)
    {
        return true;
    }

    public function show(User $user,Lesson $lesson){
        return true;
    }
}
