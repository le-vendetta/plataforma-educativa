<?php

namespace App\Policies;

use App\Models\Notification;
use App\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class NotificationPolicy
{
    use HandlesAuthorization;

    /**
     * Create a new policy instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function view(User $user,Notification $notification){
        return $user->id == $notification->user_id;
    }

    public function send(User $user,Notification $notification){
        return session('current_token');
    }
}
