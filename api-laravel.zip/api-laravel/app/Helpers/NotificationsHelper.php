<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 09/04/2018
 * Time: 11:18 AM
 */

namespace App\Helpers;


use GuzzleHttp\Client;
use GuzzleHttp\RequestOptions;
use Illuminate\Support\Facades\DB;

class NotificationsHelper
{

    public function getAll(){
        return DB::table('users')->select('id','web_device','mobile_device')->whereNotNull('web_device')->orWhere(function($query){
            $query->whereNotNull('mobile_device');
        })->get();
    }

    public function save($users){

    }

    public function send($users,$title,$body){

        $token = session('current_token');
        foreach ($users as $user){
            if($user->web_device){
                $web = $this->sendNotification($user->web_device,$title,$body,$token);
            }

            if($user->mobile_device){
                $mobile = $this->sendNotification($user->mobile_device,$title,$body,$token);
            }

        }

    }

    private function sendNotification($device,$title,$body,$token){
        try{
            $client = new Client();

            $headers = [
                'Authorization' => 'Bearer '.$token,
                'content-type'  => 'application/json',
                'Accept'        => 'application/json',
            ];
            $body = ['message' => ['token' => $device,'notification' => ['title' => $title,'body' => $body]]];


            $res = $client->post('https://fcm.googleapis.com/v1/projects/mac-test-199915/messages:send', ['headers' => $headers,RequestOptions::JSON => $body]);

            return $res;

        }catch (\Exception $e){
            die('fail');
        }

    }
}