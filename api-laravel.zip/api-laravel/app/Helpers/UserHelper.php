<?php
/**
 * Created by Vendetta.
 * User: Vendetta
 * Date: 20/07/2018
 * Time: 04:35 PM
 * The best ;)
 */

namespace App\Helpers;


use App\Models\GradeGroup;
use App\Models\Role;
use App\User;
use DB;

class UserHelper
{
    public function getUsers()
    {

        $users = DB::table('users as us')
            ->select('us.id','us.nickname','us.name','us.last_name','us.email','us.deleted_at',DB::raw('array_to_string(array_agg(gg.id),\',\') as grade_group'))
            ->join('roles as rl','rl.id','=',DB::raw('us.role_id AND rl.slug = \'student\''))
            ->leftJoin('user_grade_groups as ugg','ugg.user_id','=',DB::raw('us.id AND ugg.status = true'))
            ->leftJoin('grade_groups as gg','gg.id','=','ugg.grade_group_id')
            ->groupBy('us.id')
            ->get();

        return $users;
    }

    public function getNewUsers($users){
        $headers    = ['name','last_name','gender','email','password'];
        $data       = [];

        foreach ($users as $user){
            $data[] = array_combine($headers,$user);
        }

        $exists = User::whereIn('email',array_column($data,'email'))->withTrashed()->pluck('email')->toArray();

        return array_filter($data,function($el) use($exists){ return !in_array($el['email'],$exists); });
    }

    public function checkLimit($grade_group,$total){
        $grade_group = GradeGroup::find($grade_group);
        $role        = Role::where('slug','teacher')->first();

        $category    = $grade_group->category;

        $grades_groups = DB::table('grade_groups as gg')
            ->selectRaw('COUNT(us.id) as places')
            ->join('user_grade_groups as ugg','ugg.grade_group_id','=','gg.id')
            ->join('users as us','us.id','=','ugg.user_id')
            ->whereNull('us.deleted_at')
            ->where('us.role_id','!=',$role->id)
            ->where('ugg.status',true)
            ->where('category_id',$category->id)->first();

        if($category->max_users >= $grades_groups->places + $total){
            return true;
        }

        return $category->max_users - $grades_groups->places;
    }
}