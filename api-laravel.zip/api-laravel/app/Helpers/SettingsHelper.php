<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 11/04/2018
 * Time: 04:46 PM
 */

namespace App\Helpers;


use App\Models\Settings;

class SettingsHelper
{

    public static function get(){
        return Settings::first();
    }
}