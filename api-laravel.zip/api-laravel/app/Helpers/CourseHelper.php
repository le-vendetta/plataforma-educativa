<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 08/03/2018
 * Time: 09:54 AM
 */

namespace App\Helpers;


use App\Models\Course;
use App\Models\UserGradeGroup;
use App\Models\ViewedLesson;
use DB;
use Storage;

class CourseHelper
{
    private $settings;

    public function __construct()
    {
        $this->settings = SettingsHelper::get();
    }

    public function getCourses(){
        $user       = auth()->user();
        $user_role  = $user->role->slug;

        switch ($user_role){
            case 'student':
                return $this->getStudentCourses($user);
            case 'admin':
            case 'super-admin':
                return $this->getAllCourses();
            case 'teacher':
                return $this->getTeacherCourses($user);
        }

    }

    private function getStudentCourses($user){
        $url = Storage::disk('courses')->url('/');
        $query =  DB::table('courses')->selectRaw("courses.id,courses.slug,courses.name,CONCAT('".$url."',courses.image) as image,courses.description,courses.course_type,
                                        CASE WHEN sessions.status = true AND courses.course_type = 'live'
                                            THEN false
                                            ELSE (CASE WHEN courses.course_type = 'open' THEN false ELSE true END)
                                        END as locked
                                        ,
                                        CASE WHEN count(lessons.course_id) = count(viewed_lessons.id)  
                                            THEN true 
                                            ELSE false
                                        END as viewed,
	                                   count(viewed_lessons.id) as advance,count(lessons.course_id) as lessons")
            ->join('course_categories as cc','cc.id','=','courses.category_id')
            ->leftJoin('lessons','lessons.course_id','=','courses.id')
            ->leftJoin('sessions','sessions.course_id','=',DB::raw('courses.id AND sessions.grade_group_id = '.$user->grade_group()->first()->grade_group_id))
            ->leftJoin('viewed_lessons','viewed_lessons.lesson_id','=',DB::raw('lessons.id AND viewed_lessons.user_id = '.auth()->user()->id))
            ->groupBy('lessons.course_id','courses.id','courses.slug','courses.name','courses.image','courses.description','sessions.status')
            ->orderBy('courses.id','DESC');
        $this->groupsQuery($query,$user);
        return $query->get();
    }


    private function getTeacherCourses($user){
        return $this->getAllCourses();
        $query =  Course::selectRaw("courses.id,courses.slug,courses.course_type,courses.name,courses.image,courses.description,cc.category_id,cc.title as category_name,
            count(lessons.course_id) as total_lessons")
             ->join('course_categories as cc','cc.id','=','courses.category_id ');
        $this->groupsQuery($query,$user);

        $query->leftJoin('lessons','lessons.course_id','=','courses.id')
            ->groupBy('lessons.course_id','courses.id','courses.slug','courses.name','courses.image','courses.description')
            ->orderBy('courses.id','DESC');
        return $query->get();
    }

    private function getAllCourses(){
        $query =  Course::selectRaw("courses.id,courses.slug,courses.name,courses.image,courses.description,
	                                  count(lessons.course_id) as total_lessons,courses.course_type, courses.category_id,course_categories.title as category_name")
                        ->join('course_categories','course_categories.id','=','courses.category_id')
                        ->leftJoin('lessons','lessons.course_id','=','courses.id')
                        ->groupBy('lessons.course_id','courses.id','courses.slug','courses.name','courses.image','courses.description','course_categories.title')
                        ->orderBy('courses.id','DESC');

        return $query->get();
    }

    private function groupsQuery($query,$user){
        if(!$user->grade_group->count()){
            abort(401);
        }

        if($user->role->slug == 'student'){
            $query->where('cc.id',$user->grade_group()->first()->grade_group->category_id);
        }else{
            $ids = [];
            foreach($user->grade_group() as $item){
                $ids[] = $item->grade_group->category_id;
            }

            $query->whereIn('cc.id',array_unique($ids));

        }

    }

    public function getAdvances(){

        $data = DB::table('viewed_lessons')
            ->join('users','viewed_lessons.user_id','=','users.id')
            ->selectRaw("
                COUNT(viewed_lessons.id) as total, 
                to_char(viewed_lessons.created_at, 'YYYY-MM') as month,
                users.gender as gender
            ")
            ->where('viewed_lessons.created_at','>' ,DB::raw("CURRENT_DATE - INTERVAL '6 months'"))
            ->groupBy(DB::raw("to_char(viewed_lessons.created_at, 'YYYY-MM')"),"users.gender")
            ->orderBy('month','ASC')
            ->get()->toArray();
        $result = [];
        foreach ($data as $datum){
            $gender = $datum->gender;
            unset($datum->gender);
            $result[$gender == 'masculino'?'male':'female'][] = $datum;
        }
        return $result;
    }

    public function getComparative(){
        $user           = auth()->user();
        $grade_groups   = $user->grade_group->pluck('id');

        $users = DB::table('user_grade_groups')
            ->select('user_id')
            ->whereIn('grade_group_id',$grade_groups)
            ->where('status',true)
            ->where('user_id','!=',$user->id)->get();

        $data = DB::table('sessions as ss')
            ->selectRaw('COUNT(vl.id) as total,cs.name,to_char( ss.created_at, \'YYYY-MM\' ) as month')
            ->join('courses as cs','ss.course_id','=','cs.id')
            ->join('lessons as ls','ls.course_id','=','cs.id')
            ->join('viewed_lessons as vl','ls.id','=','vl.lesson_id')
            ->whereIn('vl.user_id',$users->pluck('user_id'))
            ->where('ss.user_id',$user->id)
            ->groupBy('month','cs.name')
            ->orderBy('month','DESC')
            ->get()->toArray();

        return $data;
    }

    public function getCousesSessions()
    {
        $user = auth()->user();

        $data = DB::table('courses as c')
                ->select('c.name','c.id')
                ->join('course_categories as cc','c.category_id','=','cc.id')
                ->join('grade_groups as gg','cc.id','=','gg.category_id')
                ->join('user_grade_groups as ugg','gg.id','=','ugg.grade_group_id')
                ->where('ugg.user_id',$user->id)
                ->where('ugg.status',true)
                ->whereNull('c.deleted_at')
                ->orderBy('c.id','ASC');

        return $data->get();
    }
}

