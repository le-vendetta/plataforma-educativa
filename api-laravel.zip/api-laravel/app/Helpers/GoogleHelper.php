<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 02/04/2018
 * Time: 10:09 AM
 */

namespace App\Helpers;


class GoogleHelper
{
    private $client;
    private $oauth;

    public function __construct()
    {
        $this->client = new \Google_Client();
        $this->client->setApplicationName(config('google.app.name'));
        $this->client->setClientId(config('google.client.id'));
        $this->client->setClientSecret(config('google.client.secret'));
        //$gClient->setRedirectUri($google_redirect_url);
        $this->client->setDeveloperKey(config('google.api_key'));
        $this->client->setScopes(array(
            'https://www.googleapis.com/auth/plus.me',
            'https://www.googleapis.com/auth/userinfo.email',
            'https://www.googleapis.com/auth/userinfo.profile',
        ));
        $this->oauth = new \Google_Service_Oauth2($this->client);

    }

    /**
     * @return mixed
     */
    public function get_client()
    {
        return $this->client;
    }

    /**
     * @return mixed
     */
    public function get_oauth()
    {
        return $this->oauth;
    }


}