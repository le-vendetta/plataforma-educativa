<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 27/03/2018
 * Time: 01:59 PM
 */

namespace App\Helpers;

use App\Models\Achievement;
use App\Models\Course;
use DB;
use Illuminate\Support\Facades\Storage;

class StatsHelper
{

    public function getStats(){
        $user           = auth()->user();
        $role           = $user->role;
        $grade_group    = $user->grade_group()->first();



        switch ($role->slug){
            case 'student':
                if(!$grade_group){
                    return [];
                }

                $category_user  = $grade_group->grade_group->category_id;

                return [
                    'last_lesson'           => $this->getLastLesson($user),
                    'advance_percent'       => $this->getAdvance($user,$category_user),
                    'total_achievements'    => $this->getTotalAchievements($user,$category_user)];
            case 'teacher':
            case 'admin':
        }
    }

    public function getAdvance($user,$category_user)
    {
        $sub = DB::table('courses as cr')->select(DB::raw('count(ls.id)'))
            ->join('course_categories as cc','cc.id','=',DB::raw('cr.category_id AND cc.id='.$category_user))
            ->join('lessons as ls','ls.course_id','=','cr.id')->toSql();


        $data = DB::table('courses as cr')->select(DB::raw('('.$sub.')as total_cat, COUNT(ls.id) as total_viewed'))

                ->join('lessons as ls','cr.id','=','ls.course_id')
                ->join('course_categories as cc','cc.id','=',DB::raw('cr.category_id AND cc.id='.$category_user))
                ->join('viewed_lessons as vl','vl.lesson_id','=',DB::raw('ls.id AND vl.user_id='.$user->id))->first();
        return round(($data->total_viewed/$data->total_cat)*100);
    }

    public function getTotalAchievements($user,$category_user)
    {
        $courses = DB::table('courses')->select(DB::raw("string_agg ( courses.ID::text,',') AS courses, string_agg ( l.ID::text,',') AS lessons "))
            ->join('lessons as l','l.course_id','=','courses.id')
            ->join('course_categories as cc','cc.id','=','courses.category_id')
            ->where('cc.id',$category_user)->first();
        $course_ids = array_unique(explode(',',$courses->courses));
        $lesson_ids = array_unique(explode(',',$courses->lessons));
        //view_lesson, finish_course

        $course_achievements = $this->getAchievementsFrom('finish_course',$course_ids,$user)->toArray();
        $lesson_achievements = $this->getAchievementsFrom('view_lesson',$lesson_ids,$user)->toArray();
        return $course_achievements['total']+$lesson_achievements['total'];
    }

    public function getLastLesson($user){

        $result = DB::table('viewed_lessons as vl')
            ->select('cr.slug as course_slug','ls.name','ls.slug','cr.image as course_image')
            ->where('vl.user_id',$user->id)
            ->join('lessons as ls','ls.id' ,'=','vl.lesson_id')
            ->join('courses as cr','ls.course_id' ,'=','cr.id')
            ->orderBy('vl.created_at','DESC')
            ->first();
        if($result){
            $result->course_image = Storage::disk('courses')->url($result->course_image);
        }
        return $result;
    }

    public function getLastAchievement(){
        $user = auth()->user();

        $result = DB::table('user_achievements as ua')
            ->select('ac.name','ac.image')
            ->where('ua.user_id',$user->id)
            ->join('achievements as ac','ac.id' ,'=','ua.achievement_id')
            ->orderBy('ua.created_at','DESC')
            ->first();
        $result = json_decode(json_encode($result), true);

        if($result){
            $result = new Achievement($result);
        }

        return $result;
    }

    public function weakCount(){
        $user   = auth()->user();

        $result = DB::table('user_advances as ua')
            ->where('ua.user_id',$user->id)
            ->whereRaw("ua.created_at BETWEEN LOCALTIMESTAMP - INTERVAL '7 days' AND LOCALTIMESTAMP")
            ->count();

        return $result;
    }

    public function weakAdvance(){
        $user   = auth()->user();
        $result = DB::table('user_advances as ua')
            ->select(DB::raw("to_char(ua.created_at,'D') as day,to_char(ua.created_at,'YYYY-MM-DD') as created,count(*) as total"))
            ->where('ua.user_id',$user->id)
            ->whereRaw("ua.created_at BETWEEN LOCALTIMESTAMP - INTERVAL '7 days' AND LOCALTIMESTAMP")
            ->groupBy('day','created')
            ->get();

        return $result;
    }


    public function monthsAdvance(){
        $user   = auth()->user();

        $result = DB::table('user_advances as ua')
            ->select(DB::raw("to_char(ua.created_at,'YYYY-MM') as date,to_char(ua.created_at,'MM') as month,count(*) as total"))
            ->where('ua.user_id',$user->id)
            ->groupBy('date','month')
            ->get();

        return $result;
    }

    private function getAchievementsFrom($type,array $ids,$user){
        $query =  Achievement::
            join('user_achievements AS Uachievements','Uachievements.achievement_id','=',
            DB::raw('"achievements"."id" AND "Uachievements"."user_id" = '.$user->id))
            ->select(DB::raw('count(achievements.id) as total'))
            ->join('achievement_types as at','achievements.achievement_type_id','=','at.id')
            ->where('at.achievement_type',$type)
            ->whereIn('achievements.entity_id',$ids);
        return $query->first();
    }

}