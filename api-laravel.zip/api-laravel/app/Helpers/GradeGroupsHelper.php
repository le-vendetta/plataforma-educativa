<?php
/**
 * Created by Vendetta.
 * User: Vendetta
 * Date: 16/07/2018
 * Time: 07:02 PM
 * The best ;)
 */

namespace App\Helpers;

use App\Models\GradeGroup;
use App\Models\Role;
use App\Models\UserGradeGroup;
use App\User;
use DB;

class GradeGroupsHelper
{

    public function getGradeGroups()
    {
        $user = auth()->user();
        $role = $user->role;
        if($role->slug == 'teacher'){
            return $this->getTeacherGradeGroups($user);
        }elseif (strpos('admin',$role->slug) !== false){
            return $this->getAdminGradeGroups($user);
        }

        return [];

    }

    private function getAdminGradeGroups()
    {
        return GradeGroup::withTrashed()
            ->select('ges.name as grade_name', 'gps.name as group_name','grade_groups.id','grade_groups.category_id','grade_groups.deleted_at')
            ->join('grades as ges','grade_groups.grade_id','=','ges.id')
            ->join('groups as gps','grade_groups.group_id','=','gps.id')
            ->get();
    }

    private function getTeacherGradeGroups($user)
    {
        $data = DB::table('user_grade_groups as ugg')
            ->select('ges.name as grade_name', 'gps.name as group_name','gg.id','gg.category_id')
            ->join('grade_groups as gg', 'ugg.grade_group_id','=','gg.id')
            ->join('grades as ges','gg.grade_id','=','ges.id')
            ->join('groups as gps','gg.group_id','=','gps.id')
            ->where('ugg.user_id',$user->id)
            ->where('ugg.status',true)
            ->whereNull('gg.deleted_at')
            ->orderBy('gg.id','DESC')
            /*->whereRaw('NOT EXISTS (SELECT 1 FROM sessions as ss WHERE ss.grade_group_id = gg.id)')*/;
        return $data->get();
    }

    public function assign($user,$grade_group){
        $current_user   = auth()->user();
        $user           = User::findOrFail($user);
        $grade          = GradeGroup::findOrFail($grade_group);
        $new            = true;
        $spaces         = true;

        $user_grade = UserGradeGroup::where('user_id',$user->id)
            ->where('grade_group_id',$grade->id)
            ->first();

        if($user_grade){
            if($user_grade->status){
                $user_grade->status = false;
                $new                = false;
            }else{
                if($user->role->slug == 'student'){
                    $this->disableLastGradeGroup($user,$grade);
                }

                $spaces             = $this->checkLimits($grade);
                $user_grade->status = true;
            }

            $user_grade->user_id_created = $current_user->id;

            if($spaces){
                $user_grade->save();
            }
        }else{
            if($user->role->slug == 'student'){
                $this->disableLastGradeGroup($user,$grade);
            }

            $spaces = $this->checkLimits($grade);
            if($spaces){
                $user->grade_group()->save(new UserGradeGroup(['grade_group_id' => $grade->id,'user_id_created' => $current_user->id]));
            }
        }

        return compact('new','spaces');
    }

    public function students(GradeGroup $grade_group)
    {
        return DB::table('users as u')
            ->select('u.id','u.name','u.email','ugg.created_at','ugg.grade_group_id as grade_group',DB::raw("CONCAT(teacher.name,' ',teacher.last_name) AS assigned_by"))
            ->join('user_grade_groups as ugg','u.id','=',DB::raw('ugg.user_id AND ugg.status=true'))
            ->join('users as teacher','teacher.id','=','ugg.user_id_created')
            ->where('ugg.grade_group_id',$grade_group->id)
            ->where('u.role_id',Role::where('slug','student')->first()->id)->get();
    }


    public function checkLimits(GradeGroup $grade_group)
    {
        $category   = $grade_group->category;
        $limit      = $category->max_users;

        $inside = DB::table('user_grade_groups as ugg')
            ->select(DB::raw('COUNT(*) AS total'))
            ->join('grade_groups as gg','gg.id','=',DB::raw('ugg.grade_group_id AND ugg.status = true'))
            ->where('gg.category_id',$category->id)->first();

        return $limit >= $inside->total+1;
    }

    private function disableLastGradeGroup(User $user,GradeGroup $grade_group)
    {
        UserGradeGroup::where('user_id',$user->id)
                            ->where('grade_group_id','!=',$grade_group->id)->update(['status' => false]);
    }
}