<?php
/**
 * Created by Vendetta.
 * User: Vendetta
 * Date: 21/06/2018
 * Time: 02:29 AM
 * The best ;)
 */

namespace App\Helpers;


use App\Models\Session;
use DB;

class SessionHelper
{
    public function getSessions($limit = false){
        $user = auth()->user();
        $role = $user->role->slug;

        switch ($role){
            case 'student':
                return $this->getStudentSessions($user);
            case 'teacher':
                return $this->getTeacherSessions($user,$limit);
            case 'admin':
            case 'super-admin':
                return $this->getAllSessions();
        }

    }

    public function getLessons(Session $session){
        return DB::table('lessons as ls')->select('ls.id','ls.name','ls.description','lt.name as type_name',DB::raw('
                                                    CASE WHEN ls.id = '.$session->lesson_id.'
                                            THEN true
                                            ELSE false
                                        END as current
        '))
            ->join('lesson_types as lt','ls.lesson_type_id','=','lt.id')
            ->where('ls.course_id',$session->course_id)
            ->get();
    }


    public function isAvailable($course,$gradeGroup)
    {
        return Session::where('course_id',$course)->where('grade_group_id',$gradeGroup)->first()?false:true;
    }

    private function getStudentSessions($user){
        $session = Session::where('grade_group_id',$user->grade_group->first()->grade_group_id)->where('status',true)
            ->orderBy('created_at','ASC')->first();
        return $session?[$session]:[];
    }

    private function getTeacherSessions($user,$limit){
        $result = Session::whereIn('grade_group_id',$user->grade_group->pluck('grade_group_id'))
        ->where('user_id',$user->id);

        if($limit){
            $result->limit($limit);
        }

        return $result->get();
    }

    private function getAllSessions(){
        return Session::all();
    }
}