<?php
/**
 * Created by PhpStorm.
 * User: Administrador
 * Date: 07/03/2018
 * Time: 04:26 PM
 */

namespace App\Helpers;


use App\Models\Achievement;
use App\Models\AchievementType;
use App\Models\Course;
use App\Models\Lesson;
use App\Models\UserAchievement;
use DB;

class AchievementHelper
{
    public function getWonAchievements(){
        return Achievement::
        join('user_achievements AS Uachievements','Uachievements.achievement_id','=',
            DB::raw('"achievements"."id" AND "Uachievements"."user_id" = '.auth()->user()->id))
            ->orderBy('achievements','ASC')->get();
    }

    public function getAchievements(){
        $user = auth()->user();

        $courses = DB::table('courses')->select(DB::raw("string_agg ( courses.ID::text,',') AS courses, string_agg ( l.ID::text,',') AS lessons "))
            ->join('lessons as l','l.course_id','=','courses.id')
            ->join('course_categories as cc','cc.id','=','courses.category_id')
            ->where('cc.id',$user->grade_group()->first()->grade_group->category_id)
            ->first();

        $courses = collect($courses)->toArray();

        $course_ids = array_unique(explode(',',$courses['courses']));
        $lesson_ids = array_unique(explode(',',$courses['lessons']));
        //view_lesson, finish_course

        $course_achievements = $this->getAchievementsFrom('finish_course',$course_ids,$user)->toArray();
        $lesson_achievements = $this->getAchievementsFrom('view_lesson',$lesson_ids,$user)->toArray();
        return array_merge($course_achievements,$lesson_achievements);
    }

    private function getAchievementsFrom($type,array $ids,$user){
        $query =  Achievement::
        leftJoin('user_achievements AS Uachievements','Uachievements.achievement_id','=',
            DB::raw('"achievements"."id" AND "Uachievements"."user_id" = '.$user->id))
            ->select('name','description','image',DB::raw('
                     CASE 
                          WHEN "Uachievements"."id" is null 
                             THEN true
                          ELSE false
                     END as locked
             '))
            ->join('achievement_types','achievements.achievement_type_id','=','achievement_types.id')

            ->where('achievement_types.achievement_type',$type)
            ->whereIn('achievements.entity_id',$ids)
            ->orderBy('achievements.id','ASC');
        return $query->get();
    }

    public function checkAchievement(Lesson $lesson){
        $achievement = [];
        $is = DB::table('courses')
            ->selectRaw('CASE WHEN count(lessons.id) = count(viewed_lessons.id)
                            THEN true
                            ELSE false
                        END AS winner')
            ->leftJoin('lessons','lessons.course_id','=','courses.id')
            ->leftJoin('viewed_lessons','viewed_lessons.lesson_id','=',DB::raw('lessons.id AND viewed_lessons.user_id ='.auth()->user()->id))
            ->where('courses.id','=',$lesson->course_id)
            ->groupBy('lessons.course_id')->first();
        $achievement[] = $this->checkIfWinLesson($lesson);

        if($is->winner){
            $achievement[] = $this->checkIfWinCourse($lesson->course_id);
        }

        return array_filter($achievement);
    }

    private function checkIfWinLesson(Lesson $lesson){
        $type = AchievementType::where('achievement_type','view_lesson')->first();
        $achievement        = Achievement::where('entity_id',$lesson->id)
                                            ->where('achievement_type_id',$type->id)->first();

        if($achievement){
            UserAchievement::firstOrCreate(['user_id' => auth()->user()->id,'achievement_id' => $achievement->id]);
            return $achievement;
        }
    }

    private function checkIfWinCourse($course_id){
        $type = AchievementType::where('achievement_type','finish_course')->first();
        if($type){
            $achievement        = Achievement::where('entity_id',$course_id)
                ->where('achievement_type_id',$type->id)->first();

            if($achievement){
                UserAchievement::firstOrCreate(['user_id' => auth()->user()->id,'achievement_id' => $achievement->id]);
                return $achievement;
            }
        }

    }
}