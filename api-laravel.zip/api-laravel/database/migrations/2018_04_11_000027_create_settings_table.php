<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSettingsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('settings', function(Blueprint $table)
		{
			$table->increments('id');
			$table->boolean('have_achievements')->default(true);
			$table->boolean('have_notifications')->default(true);
			$table->integer('course_test_attemps')->default(3);
			$table->integer('lesson_test_attemps')->default(3);
			$table->string('license_expires', 100)->nullable();
			$table->string('licence_key', 100)->nullable();
			$table->integer('students_number')->default(0);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('settings');
	}

}
