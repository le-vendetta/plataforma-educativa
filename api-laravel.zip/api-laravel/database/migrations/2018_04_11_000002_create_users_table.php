<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function(Blueprint $table)
		{
			$table->increments('id');
			$table->unsignedInteger('role_id');
			$table->string('uid')->nullable();
			$table->string('email')->unique();
			$table->string('password');
			$table->string('name')->nullable();
			$table->string('last_name')->nullable();
			$table->string('nickname');
			$table->enum('gender',['masculino','femenino'])->default('masculino');
			$table->string('avatar')->default('avatar.png');
			$table->boolean('new_user')->default(true);
			$table->string('provider');
            $table->string('web_device')->nullable();
            $table->string('mobile_device')->nullable();
			$table->string('remember_token', 100)->nullable();

			$table->softDeletes();
			$table->timestamps();

			$table->foreign('role_id')->references('id')->on('roles');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
