<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCoursesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('courses', function(Blueprint $table)
		{
			$table->increments('id');
			$table->unsignedInteger('category_id');
			$table->enum('course_type',['open','live'])->default('live');
			$table->string('slug')->unique();
			$table->string('name');
            $table->string('image')->default('course.png');
			$table->text('description');
			$table->unsignedInteger('user_id_created');

            $table->softDeletes();
            $table->timestamps();

            $table->foreign('category_id')->references('id')->on('course_categories');

        });
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('courses');
	}

}
