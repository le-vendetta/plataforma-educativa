<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLessonsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('lessons', function(Blueprint $table)
		{
			$table->increments('id');
			$table->unsignedInteger('course_id');
			$table->unsignedInteger('lesson_type_id');
			$table->string('slug')->unique();
			$table->string('name');
			$table->text('content');
			$table->string('description');
			$table->unsignedInteger('user_id_created');

            $table->softDeletes();
            $table->timestamps();

            $table->foreign('course_id')->references('id')->on('courses');
            $table->foreign('lesson_type_id')->references('id')->on('lesson_types');

        });
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('lessons');
	}

}
