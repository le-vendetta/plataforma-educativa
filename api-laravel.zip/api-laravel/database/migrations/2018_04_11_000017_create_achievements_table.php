<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAchievementsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('achievements', function(Blueprint $table)
		{
			$table->increments('id');
			$table->unsignedInteger('achievement_type_id');
			$table->unsignedInteger('entity_id')->index();
			$table->string('name');
			$table->string('image')->default('achievement.png');
			$table->string('description');
			$table->unsignedInteger('user_id_created');

			$table->timestamps();

            $table->foreign('achievement_type_id')->references('id')->on('achievement_types');

        });
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('achievements');
	}

}
