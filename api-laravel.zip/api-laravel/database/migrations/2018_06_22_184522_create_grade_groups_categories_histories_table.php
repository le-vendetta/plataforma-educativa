<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGradeGroupsCategoriesHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('grade_groups_categories_histories', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('grade_group_id');
            $table->unsignedInteger('course_category_id');


            $table->foreign('grade_group_id')->references('id')->on('grade_groups');
            $table->foreign('course_category_id')->references('id')->on('course_categories');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('grade_groups_categories_histories');
    }
}
