<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateNotificationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('notifications', function(Blueprint $table)
		{
			$table->increments('id');
			$table->unsignedInteger('notification_type_id');
			$table->unsignedInteger('user_id');
			$table->string('title');
			$table->string('body');
			$table->string('link');
			$table->boolean('viewed')->default(false);
			$table->timestamps();

            $table->foreign('notification_type_id')->references('id')->on('notification_types');
            $table->foreign('user_id')->references('id')->on('users');

        });
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('notifications');
	}

}
