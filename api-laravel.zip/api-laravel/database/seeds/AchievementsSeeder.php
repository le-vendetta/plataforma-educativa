<?php

use App\Models\AchievementType;
use Illuminate\Database\Seeder;
use Faker\Generator as Faker;

class AchievementsSeeder extends Seeder
{
    private $faker;
    public function __construct(Faker $faker)
    {
        $this->faker = $faker;
    }
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $achievementType = AchievementType::create(['achievement_type' => 'view_lesson','user_id_created' => 1]);

        foreach (\App\Models\Lesson::all() as $achievement){
            \App\Models\Achievement::create([
                'achievement_type_id'   => $achievementType->id,
                'entity_id'             => $achievement->id,
                'name'                  => $this->faker->realText(50),
                'image'                 => 'achievement.png',
                'description'           => $this->faker->text(),
                'user_id_created'       => 1
            ]);
        }
    }
}
