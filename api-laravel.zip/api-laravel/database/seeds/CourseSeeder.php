<?php

use Illuminate\Database\Seeder;
use Faker\Generator as Faker;

class CourseSeeder extends Seeder
{
    private $faker;
    public function __construct(Faker $faker)
    {
        $this->faker = $faker;
    }

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $lessonType = \App\Models\LessonType::create([
            'name' => 'Sliders',
            'slug'=> 'sliders',
            'description' => $this->faker->text(),
            'user_id_created' => 1
        ]);

        foreach(range(1,10) as $course){
            $course = \App\Models\Course::create([
                'category_id'       => $course<5?1:rand(1,5),
                'slug'              => "curso-$course",
                'name'              => "Curso $course",
                'description'       => $this->faker->paragraph(),
                'user_id_created'   => 1
            ]);

            foreach (range(1,5) as $lesson){
                $title = $this->faker->realText(50);
                \App\Models\Lesson::create([
                    'course_id'         => $course->id,
                    'lesson_type_id'    => $lessonType->id,
                    'slug'              => str_slug($title),
                    'name'              => $title,
                    'content'           => '[{"content":{"id":"0c5489c7-670a-48b6-9180-d7264cd556b6","cells":[{"id":"8ce23f4e-16b8-47ea-a85d-49e334298acb","inline":null,"size":12,"content":{"plugin":{"name":"form","version":"0.0.1"},"state":{"value":{"title":"Formulario 1","items":[{"type":"text","label":"Texto o pregunta","original_id":0},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":1},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":2},{"type":"text","label":"Texto o pregunta","original_id":3},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":4},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":5},{"type":"text","label":"Texto o pregunta","original_id":6},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":7},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":8}],"columns":3}}}}]}},{"content":{"id":"84609cac-659f-4dbf-8f76-42f58dd944d3","cells":[{"id":"cc6b937f-d502-444c-a400-7195d87d6840","inline":null,"size":12,"content":{"plugin":{"name":"form","version":"0.0.1"},"state":{"value":{"title":"Formulario 2","items":[{"type":"text","label":"Texto o pregunta","original_id":0},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":1},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":2},{"type":"text","label":"Texto o pregunta","original_id":3},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":4},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":5},{"type":"text","label":"Texto o pregunta","original_id":6},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":7},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":8}],"columns":3}}}}]}},{"content":{"id":"2d60ba93-e547-4bfb-8626-46678630dd98","cells":[{"id":"0613bfe2-66f0-40fa-9d63-528ff8e5ebe4","inline":null,"size":12,"content":{"plugin":{"name":"form","version":"0.0.1"},"state":{"value":{"title":"Formulario 3","items":[{"type":"text","label":"Texto o pregunta","original_id":0},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":1},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":2},{"type":"text","label":"Texto o pregunta","original_id":3},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":4},{"type":"radio","label":"Etiqueta del radio","checked":false,"original_id":5},{"type":"text","label":"Texto o pregunta","original_id":6},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":7},{"type":"checkbox","label":"Etiqueta del checkbox","checked":false,"original_id":8}],"columns":3}}}}]}}]',
                    'description'       => $this->faker->text(),
                    'user_id_created'   => 1,
                ]);
            }
        }
    }
}
