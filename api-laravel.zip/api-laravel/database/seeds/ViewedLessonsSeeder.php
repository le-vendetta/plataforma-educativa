<?php

use App\Models\Role;
use Illuminate\Database\Seeder;

class ViewedLessonsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = \Faker\Factory::create();

        $role   = Role::where('slug','student')->first();

        foreach (range(1,50) as $item){
            $name = $faker->firstName();
            $user = \App\User::create([
                'role_id'   => $role->id,
                'name'      => $name,
                'nickname'  => str_slug($name,'_'),
                'last_name' => $faker->lastName,
                'email'     => $faker->email,
                'password'  => bcrypt(123456),
                'provider'  => 'web',
                'gender'    => $faker->randomElement(['masculino','femenino'])
            ]);

            foreach (range(1,rand(5,20)) as $item){
                \App\Models\ViewedLesson::create([
                    'user_id' => $user->id,
                    'lesson_id' => rand(1,50),
                    'created_at' => $faker->dateTimeBetween('-6 months')
                ]);
            }
        }
    }
}
