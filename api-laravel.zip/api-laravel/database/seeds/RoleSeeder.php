<?php

use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach (['Super Admin','Admin','Teacher','Student'] as $role_name){
            $role = \App\Models\Role::create([
                'name'              => $role_name,
                'slug'              => str_slug($role_name),
                'user_id_created'   => 1
            ]);
        }

    }
}
