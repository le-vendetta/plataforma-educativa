<?php

use Illuminate\Database\Seeder;

class GroupsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $grade = \App\Models\Grade::create(['name' => 'Primero','user_id_created' => 1]);
        $grade2 = \App\Models\Grade::create(['name' => 'Segundo','user_id_created' => 1]);
        $group = \App\Models\Group::create(['name' => 'B','turn' => 'matutino','user_id_created' => 1]);
        $group2 = \App\Models\Group::create(['name' => 'A','turn' => 'matutino','user_id_created' => 1]);

        $grade_group = \App\Models\GradeGroup::create(['grade_id' => $grade->id,'group_id' => $group->id,'user_id_created' => 1,'category_id' => 1]);
        \App\Models\GradeGroup::create(['grade_id' => $grade->id,'group_id' => $group2->id,'user_id_created' => 1,'category_id' => 2]);
        \App\Models\GradeGroup::create(['grade_id' => $grade2->id,'group_id' => $group->id,'user_id_created' => 1,'category_id' => 3]);
        \App\Models\GradeGroup::create(['grade_id' => $grade2->id,'group_id' => $group2->id,'user_id_created' => 1,'category_id' => 4]);

        $role           = \App\Models\Role::where('slug','student')->first();
        $roleTeacher    = \App\Models\Role::where('slug','teacher')->first();

        $student = \App\User::where('role_id',$role->id)->first();
        $teacher = \App\User::where('role_id',$roleTeacher->id)->first();

        \App\Models\UserGradeGroup::create(['user_id' => $student->id,'grade_group_id' => $grade_group->id,'user_id_created' => 1]);
        \App\Models\UserGradeGroup::create(['user_id' => $teacher->id,'grade_group_id' => $grade_group->id,'user_id_created' => 1]);

    }
}
