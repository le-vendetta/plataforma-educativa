<?php

use Illuminate\Database\Seeder;

class CourseCategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        foreach(range(1,5) as $category){
            \App\Models\CourseCategory::create([
                'slug'              => "categoria-$category",
                'title'             => "Categoria $category",
                'image'             => 'category.png',
                'description'       => 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
                'max_users'         => 100,
                'user_id_created'   => 1,
            ]);
        }

    }
}
