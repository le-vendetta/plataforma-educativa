<?php

use App\Models\Role;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        foreach (Role::all() as $role){
            $user = \App\User::create([
                'role_id'   => $role->id,
                'name'      => $role->name,
                'nickname'  => $role->name,
                'last_name' => $role->name,
                'email'     => str_slug($role->name)."@".str_slug($role->name).".com",
                'password'  => bcrypt(123456),
                'provider'  => 'web',
            ]);
        }
    }
}
