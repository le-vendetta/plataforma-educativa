<?php

use App\Models\Role;
use Illuminate\Database\Seeder;

class ActionPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        foreach (Role::all() as $role){
            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.courses.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.course.slug.show',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.lessons.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.course.slug.lesson.show',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.show',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.achievement.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.achievement.show',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.lessons.lesson.view',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.update.password',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.password.reset.first',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.stats',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.courses.presentation',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.courses.advances',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.courses.comparative',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.categories.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.courses.update',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.lessons.types.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.lessons.store',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.last',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.gradegroups.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.available',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.store',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.show',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.update.slider',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.lessons.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.update.lesson',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.status',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.course.categories.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.course.categories.show',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.users.students.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.grade_group.assign',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.grade_group.remove',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.plugins.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.lesson.image.upload',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.course.lesson.show',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.course.lesson.update',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.courses.store',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.courses.delete.massive',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.lessons.delete.massive',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.users.students.excel',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.update.status',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.sessions.courses.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.gradegroups.store',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.gradegroups.delete',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.gradegroups.restore',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.gradegroups.update',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.groups.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.grades.index',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.update',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.user.update.image',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

            \App\Models\ActionPermission::create([
                'role_id'           => $role->id,
                'route_name'        => 'api.users.students.update',
                'status'            => 1,
                'user_id_created'   => 1,
            ]);

        }
    }
}
