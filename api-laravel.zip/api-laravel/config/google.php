<?php
/**
 * Created by PhpStorm.
 * User=> Administrador
 * Date=> 02/04/2018
 * Time=> 10=>10 AM
 */

return [
    'app' => [
        'name'        => env('GOOGLE_APP_NAME',''),
    ],
    'client' => [
        'id'        => env('GOOGLE_CLIENT_ID',''),
        'secret'        => env('GOOGLE_CLIENT_SECRET',''),
    ],
    'api_key' => env('GOOGLE_API_KEY',''),

];